<?php
add_filter( 'woocommerce_checkout_fields', 'customize_woocommerce_checkout_fields' );

function customize_woocommerce_checkout_fields( $fields ) {
    // حذف فیلدهای اضافی بدون تغییر در تنظیمات پیش‌فرض سایت
   // unset( $fields['billing']['billing_email'] ); // حذف فیلد ایمیل
    //unset( $fields['billing']['billing_company'] ); // نام شرکت
  //  unset( $fields['billing']['billing_address_2'] ); // آدرس خط 2
   // unset( $fields['billing']['billing_country'] ); // کشور

    // تنظیم ترتیب فیلدها بدون تغییر در اجباری بودن
    $fields['billing']['billing_first_name']['priority'] = 10; // نام
    $fields['billing']['billing_last_name']['priority'] = 20; // نام خانوادگی
    $fields['billing']['billing_phone']['priority'] = 30; // شماره تماس
    $fields['billing']['billing_address_1']['priority'] = 40; // آدرس

    return $fields;
}




if ( ! class_exists( 'WC_Custom_Shipping_Method' ) ) {
    class WC_Custom_Shipping_Method extends WC_Shipping_Method {
        public function __construct() {
            $this->id                 = 'custom_shipping';
            $this->method_title       = __( 'روش حمل و نقل سفارشی', 'your-textdomain' );
            $this->method_description = __( 'یک روش سفارشی برای حمل و نقل در فروشگاه', 'your-textdomain' );

            $this->enabled            = "yes";
            $this->title              = __( 'حمل و نقل سفارشی', 'your-textdomain' );

            $this->init();
        }

        public function init() {
            $this->init_form_fields();
            $this->init_settings();

            $this->enabled = $this->get_option( 'enabled' );
            $this->title   = $this->get_option( 'title' );

            add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
        }

        public function init_form_fields() {
            $this->form_fields = array(
                'enabled' => array(
                    'title'   => __( 'فعال / غیرفعال', 'your-textdomain' ),
                    'type'    => 'checkbox',
                    'label'   => __( 'فعال / غیرفعال کنید', 'your-textdomain' ),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title'       => __( 'نام شیوه حمل و نقل', 'your-textdomain' ),
                    'type'        => 'text',
                    'description' => __( 'نامی که در صفحه صورتحساب نمایش داده میشود.', 'your-textdomain' ),
                    'default'     => __( 'حمل و نقل سفارشی', 'your-textdomain' ),
                    'desc_tip'    => true,
                ),
            );
        }

        public function calculate_shipping( $package = array() ) {
            $destination = $package['destination'] ?? array();

            $city  = isset( $destination['city'] ) ? sanitize_text_field( $destination['city'] ) : '';
            $state = isset( $destination['state'] ) ? $destination['state'] : '';

            // اگر آدرس حمل‌ونقل خالیه، از آدرس صورت‌حساب استفاده کن و آن را تنظیم کن
            if ( empty( $city ) || empty( $state ) ) {
                $billing_city  = WC()->customer->get_billing_city();
                $billing_state = WC()->customer->get_billing_state();

                if ( empty( $city ) && ! empty( $billing_city ) ) {
                    $city = sanitize_text_field( $billing_city );
                    WC()->customer->set_shipping_city( $city );
                }

                if ( empty( $state ) && ! empty( $billing_state ) ) {
                    $state = $billing_state;
                    WC()->customer->set_shipping_state( $state );
                }
            }

            // اگر همچنان هیچ آدرسی موجود نبود، متوقف شو
            if ( empty( $city ) && empty( $state ) ) {
                return;
            }

            $cart_total = WC()->cart->get_subtotal(); // بدون هزینه ارسال و تخفیف

            if ( $cart_total >= 3000000 ) {
                $this->add_rate( array(
                    'id'    => $this->id . '_free_shipping',
                    'label' => 'ارسال رایگان',
                    'cost'  => 0,
                ) );
                return;
            }


            if ( $state === 'FRS' && ( stripos( $city, 'شیراز' ) !== false || stripos( $city, 'shiraz' ) !== false ) ) {
                $this->add_rate( array(
                    'id'    => $this->id . '_pickup',
                    'label' => 'دریافت حضوری (رایگان)',
                    'cost'  => 0,
                ) );
                $this->add_rate( array(
                    'id'    => $this->id . '_shiraz_bike',
                    'label' => 'ارسال با پیک (هزینه به عهده مشتری)',
                    'cost'  => 0,
                ) );
            } elseif ( $state === 'FRS' ) {
                $this->add_rate( array(
                    'id'    => $this->id . '_fars_post',
                    'label' => 'پست پیشتاز',
                    'cost'  => 30000,
                ) );
            } else {
                $this->add_rate( array(
                    'id'    => $this->id . '_other_post',
                    'label' => 'پست پیشتاز',
                    'cost'  => 50000,
                ) );
            }
        }
    }
}

add_action( 'woocommerce_shipping_methods', 'register_custom_shipping_method' );
function register_custom_shipping_method( $methods ) {
    $methods['custom_shipping'] = 'WC_Custom_Shipping_Method';
    return $methods;
}
/**
 * وقتی کاربر در هر صفحه مرنبط با محصولات هست ایکون فروشگاه solid در فوتر موبایل اکتیو میشود
 * افزودن کلاس سفارشی به body وقتی کاربر در هر صفحه مرتبط با محصولات است
 */
function nb_add_shop_active_body_class($classes) {
    if (
        is_shop() ||
        is_product() ||
        is_product_category() ||
        is_product_tag() ||
        is_tax('car_brand') ||
        is_tax('car_model') ||
        is_tax('part_brand')
    ) {
        $classes[] = 'nb-shop-active';
    }
    return $classes;
}
add_filter('body_class', 'nb_add_shop_active_body_class');