<?php
/**
 * کنترل‌های سفارشی صفحه سبد خرید (Cart)
 * - افزودن دکمه‌های + و - کنار تعداد هر محصول
 * - جایگزینی آیکون × با آیکون سطل زباله برای حذف محصول
 *
 * محل قرارگیری پیشنهادی: nb-includes/nb-cart-page-controls.php
 * و افزودن این خط در functions.php:
 * require_once __DIR__ . "/nb-includes/nb-cart-page-controls.php";
 */

defined('ABSPATH') || exit;

/*----------------------------------------------
| ۱) بارگذاری استایل و اسکریپت فقط در صفحه سبد خرید
----------------------------------------------*/
add_action('wp_enqueue_scripts', function () {

    if (!is_cart()) {
        return;
    }

    $css_file = ASTRA_CHILD_DIR . '/assets/css/cart-page.css';
    wp_enqueue_style(
        'nb-cart-page',
        ASTRA_CHILD_URI . '/assets/css/cart-page.css',
        ['astra-child'],
        file_exists($css_file) ? filemtime($css_file) : ASTRA_CHILD_VERSION
    );

    $js_file = ASTRA_CHILD_DIR . '/assets/js/cart-page.js';
    wp_enqueue_script(
        'nb-cart-page',
        ASTRA_CHILD_URI . '/assets/js/cart-page.js',
        ['jquery'],
        file_exists($js_file) ? filemtime($js_file) : ASTRA_CHILD_VERSION,
        true
    );
}, 20);

/*----------------------------------------------
| ۲) افزودن دکمه‌های + و - کنار اینپوت تعداد
| نکته مهم: خودِ اینپوت تعداد ووکامرس (input.qty) دست‌نخورده باقی می‌ماند
| تا مکانیزم فعلی آپدیت خودکار (AJAX) سبد خرید بدون تغییر کار کند.
| ما فقط با کلیک روی + / - مقدار input رو عوض می‌کنیم و event
| «change» رو شلیک می‌کنیم که همون تریگر فعلی سایته.
----------------------------------------------*/
add_filter('woocommerce_cart_item_quantity', 'nb_cart_item_quantity_stepper', 10, 3);
function nb_cart_item_quantity_stepper($product_quantity, $cart_item_key, $cart_item)
{
    if (!is_cart()) {
        return $product_quantity;
    }

    $html  = '<div class="nb-cart-qty-stepper" data-cart-item-key="' . esc_attr($cart_item_key) . '">';
    $html .= '<button type="button" class="nb-qty-btn nb-qty-minus" aria-label="کاهش تعداد">−</button>';
    $html .= $product_quantity;
    $html .= '<button type="button" class="nb-qty-btn nb-qty-plus" aria-label="افزایش تعداد">+</button>';
    $html .= '</div>';

    return $html;
}

/*----------------------------------------------
| ۳) جایگزینی × (&times;) با آیکون سطل زباله
| href و data attribute های اصلی (data-cart_item_key و ...) دست‌نخورده
| باقی می‌مانند تا مکانیزم حذف AJAX داخلی خود ووکامرس همچنان کار کند.
----------------------------------------------*/
add_filter('woocommerce_cart_item_remove_link', 'nb_cart_item_remove_icon', 10, 2);
function nb_cart_item_remove_icon($remove_link, $cart_item_key)
{
    if (!is_cart()) {
        return $remove_link;
    }

    // خروجی پیش‌فرض ووکامرس شامل ">&times;<" است؛ آن را با آیکون سطل زباله عوض می‌کنیم
    $remove_link = str_replace('>&times;<', '><i class="fas fa-trash-alt"></i><', $remove_link);

    // افزودن کلاس اختصاصی برای استایل‌دهی جداگانه بدون تداخل با استایل‌های عمومی .remove
    $remove_link = str_replace('class="remove"', 'class="remove nb-cart-remove-icon"', $remove_link);

    return $remove_link;
}
/*----------------------------------------------
| ۴) حداقل تعداد در سبد خرید = ۱ (نه صفر)
| اگه کاربر بخواد از ۱ کمتر کنه، باید محصول رو دیلیت کنه.
----------------------------------------------*/
add_filter('woocommerce_quantity_input_args', function ($args, $product) {
    if (is_cart()) {
        $args['min_value'] = 1;
    }
    return $args;
}, 10, 2);
