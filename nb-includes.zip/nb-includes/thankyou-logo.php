<?php
defined('ABSPATH') || exit;

add_action('woocommerce_thankyou', 'razeghi_thankyou_logo', 5);
function razeghi_thankyou_logo($order_id) {

    // آیکون پرینت (بالاترین عنصر صفحه)
    echo '<div style="text-align:left; margin: 0 0 8px;" class="razeghi-print-btn-wrap">
        <button onclick="window.print()" title="پرینت سفارش" style="background:#fff; border:1px solid #E5DFD3; border-radius:8px; cursor:pointer; font-size:20px; padding:6px 10px;">
            🖨️
        </button>
    </div>';

    // لوگوی سایت
    if (has_custom_logo()) {
        echo '<div id="razeghi-thankyou-logo" style="text-align:center; margin:0 0 20px;">';
        the_custom_logo();
        echo '</div>';
    }

    echo '<script>
    document.addEventListener("DOMContentLoaded", function() {

        // ۱) جابه‌جایی لوگو + دکمه پرینت به بالای صفحه
        var logo = document.getElementById("razeghi-thankyou-logo");
        var printBtn = document.querySelector(".razeghi-print-btn-wrap");
        var wrapper = document.querySelector(".woocommerce-order")
                    ? document.querySelector(".woocommerce-order").parentNode
                    : null;
        if (wrapper) {
            if (logo) wrapper.insertBefore(logo, wrapper.firstChild);
            if (printBtn) wrapper.insertBefore(printBtn, wrapper.firstChild);
        }

        // ۲) حذف ردیف "شماره تماس"
        document.querySelectorAll("th").forEach(function(th) {
            if (th.textContent.trim() === "شماره تماس:") {
                var row = th.closest("tr");
                if (row) row.remove();
            }
        });

        // ۳) حذف متن توضیح روش پرداخت (مثل "پرداخت نقدی پس از تحویل")
        document.querySelectorAll("p").forEach(function(p) {
            if (p.textContent.trim().indexOf("پرداخت نقدی پس از تحویل") !== -1) {
                p.remove();
            }
        });

        // ۴) جابه‌جایی آدرس صورتحساب به بالای جزئیات سفارش
        var customerDetails = document.querySelector(".woocommerce-customer-details");
        var orderDetailsTitle = document.querySelector(".woocommerce-order-details__title");
        if (customerDetails && orderDetailsTitle && orderDetailsTitle.parentNode) {
            orderDetailsTitle.parentNode.insertBefore(customerDetails, orderDetailsTitle);
        }

        // ۵) پیچیدن "جزئیات سفارش" (عنوان + جدول) در یک باکس مشترک
        //     این کار باید بعد از مرحله ۴ انجام شود، چون مرحله ۴ محل عنوان را تغییر می‌دهد
        var orderTitle = document.querySelector(".woocommerce-order-details__title");
        var orderTable = document.querySelector(".shop_table.order_details");
        if (orderTitle && orderTable && orderTitle.parentNode) {
            var wrapDiv = document.createElement("div");
            wrapDiv.className = "razeghi-order-details-box";
            orderTitle.parentNode.insertBefore(wrapDiv, orderTitle);
            wrapDiv.appendChild(orderTitle);
            wrapDiv.appendChild(orderTable);
        }

    });
    </script>';
}