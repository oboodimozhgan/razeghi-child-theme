<?php
/**
 * ثبت تاکسونومی‌های محصول
 */
add_action('init', 'astra_child_register_product_taxonomies');
function astra_child_register_product_taxonomies() {
    
    // برند خودرو
    register_taxonomy('car_brand', 'product', array(
        'label' => 'برند خودرو',
        'hierarchical' => true,
        'show_in_rest' => true,
        'show_admin_column' => true,
        'rewrite' => array('slug' => 'car-brand')
    ));
    
    // مدل خودرو
    register_taxonomy('car_model', 'product', array(
        'label' => 'مدل خودرو',
        'hierarchical' => true,
        'show_in_rest' => true,
        'show_admin_column' => true,
        'rewrite' => array('slug' => 'car-model')
    ));
    
    // نسل خودرو
    register_taxonomy('car_generation', 'product', array(
        'label' => 'نسل خودرو',
        'hierarchical' => true,
        'show_in_rest' => true,
        'show_admin_column' => true,
        'rewrite' => array('slug' => 'generation')
    ));
    
    // برند قطعه
    register_taxonomy('part_brand', 'product', array(
        'label' => 'برند قطعه',
        'hierarchical' => true,
        'show_in_rest' => true,
        'show_admin_column' => true,
        'rewrite' => array('slug' => 'part-brand')
    ));
    
    // سیستم خودرو
    register_taxonomy('car_system', 'product', array(
        'label' => 'سیستم خودرو',
        'hierarchical' => true,
        'show_in_rest' => true,
        'show_admin_column' => true,
        'rewrite' => array('slug' => 'system')
    ));
    
    // درجه کیفیت
    register_taxonomy('quality_grade', 'product', array(
        'label' => 'درجه کیفیت',
        'hierarchical' => true,
        'show_in_rest' => true,
        'show_admin_column' => true
    ));
    
    // محل نصب
    register_taxonomy('install_position', 'product', array(
        'label' => 'محل نصب',
        'hierarchical' => true,
        'show_in_rest' => true
    ));
}

/**
 * ثبت متافیلدهای محصول
 */
add_action('init', 'astra_child_register_product_meta');
function astra_child_register_product_meta() {
    
    // شناسایی محصول
    $identification_fields = array(
        '_oem_code' => 'شماره فنی OEM',
        '_part_number' => 'شماره قطعه',
        '_barcode' => 'بارکد',
        '_internal_code' => 'کد داخلی',
        '_alternate_part_numbers' => 'شماره‌های جایگزین'
    );
    
    // موجودی
    $stock_fields = array(
        '_stock_source' => 'منبع موجودی',
        '_availability_type' => 'نوع موجودی',
        '_restock_date' => 'تاریخ تامین مجدد'
    );
    
    // مشخصات فنی
    $spec_fields = array(
        '_manufacturer' => 'تولیدکننده',
        '_country_of_origin' => 'کشور سازنده',
        '_quality_grade_text' => 'درجه کیفیت',
        '_material' => 'جنس',
        '_warranty_period' => 'مدت گارانتی'
    );
    
    // سازگاری خودرو
    $compatibility_fields = array(
        '_engine_type' => 'نوع موتور',
        '_engine_code' => 'کد موتور',
        '_year_from' => 'سال شروع',
        '_year_to' => 'سال پایان'
    );
    
    // موقعیت نصب
    $position_fields = array(
        '_side' => 'سمت',
        '_axle' => 'محور'
    );
    
    // اطلاعات فروش
    $sales_fields = array(
        '_installation_time' => 'زمان نصب',
        '_difficulty_level' => 'سختی نصب',
        '_replacement_interval' => 'زمان تعویض'
    );
    
    // محتوایی
    $content_fields = array(
        '_short_features' => 'ویژگی‌های کوتاه',
        '_installation_guide' => 'راهنمای نصب',
        '_maintenance_tips' => 'نکات نگهداری',
        '_common_failures' => 'علائم خرابی',
        '_video_url' => 'لینک ویدیو'
    );
    
    // نمایش
    $display_fields = array(
        '_show_partner_price' => 'نمایش قیمت همکار',
        '_featured_badge' => 'نشان ویژه',
        '_sale_badge_text' => 'متن تخفیف'
    );
    
    // لجستیک
    $shipping_fields = array(
        '_package_weight' => 'وزن بسته',
        '_package_length' => 'طول بسته',
        '_package_width' => 'عرض بسته',
        '_package_height' => 'ارتفاع بسته',
        '_fragile' => 'شکننده'
    );
    
    // ترکیب همه فیلدها (بدون قیمت)
    $all_fields = array_merge(
        $identification_fields,
        $stock_fields,
        $spec_fields,
        $compatibility_fields,
        $position_fields,
        $sales_fields,
        $content_fields,
        $display_fields,
        $shipping_fields
    );
    
    // ثبت متافیلدها
    foreach ($all_fields as $key => $label) {
        register_post_meta('product', $key, array(
            'type' => 'string',
            'description' => $label,
            'single' => true,
            'show_in_rest' => true,
            'auth_callback' => function() {
                return current_user_can('edit_posts');
            }
        ));
    }

    // ========== ثبت متافیلدهای تصویر Hero برای دسکتاپ و موبایل ==========
    register_post_meta('product', '_hero_image_desktop', array(
        'type' => 'integer',
        'description' => 'شناسه تصویر Hero Section - دسکتاپ',
        'single' => true,
        'show_in_rest' => true,
        'auth_callback' => function() {
            return current_user_can('edit_posts');
        }
    ));
    
    register_post_meta('product', '_hero_image_mobile', array(
        'type' => 'integer',
        'description' => 'شناسه تصویر Hero Section - موبایل',
        'single' => true,
        'show_in_rest' => true,
        'auth_callback' => function() {
            return current_user_can('edit_posts');
        }
    ));
}

/**
 * اضافه کردن متاباکس برای متافیلدها
 */
add_action('add_meta_boxes', 'astra_child_add_product_meta_boxes');
function astra_child_add_product_meta_boxes() {
    
    add_meta_box(
        'product_identification',
        'شناسایی محصول',
        'astra_child_render_identification_meta',
        'product',
        'normal',
        'high'
    );
    
    add_meta_box(
        'product_compatibility',
        'سازگاری خودرو',
        'astra_child_render_compatibility_meta',
        'product',
        'normal',
        'default'
    );

    // ========== متاباکس تصاویر Hero (دسکتاپ و موبایل) ==========
    add_meta_box(
        'product_hero_images',
        'تصاویر Hero Section (دسکتاپ و موبایل)',
        'astra_child_render_hero_images_meta',
        'product',
        'normal',
        'low'
    );
}

// رندر متاباکس شناسایی
function astra_child_render_identification_meta($post) {
    wp_nonce_field('product_meta_nonce', 'product_meta_nonce');
    
    $oem = get_post_meta($post->ID, '_oem_code', true);
    $part_number = get_post_meta($post->ID, '_part_number', true);
    $barcode = get_post_meta($post->ID, '_barcode', true);
    ?>
    <p>
        <label>شماره فنی OEM:</label>
        <input type="text" name="_oem_code" value="<?php echo esc_attr($oem); ?>" style="width:100%">
    </p>
    <p>
        <label>شماره قطعه:</label>
        <input type="text" name="_part_number" value="<?php echo esc_attr($part_number); ?>" style="width:100%">
    </p>
    <p>
        <label>بارکد:</label>
        <input type="text" name="_barcode" value="<?php echo esc_attr($barcode); ?>" style="width:100%">
    </p>
    <?php
}

// رندر متاباکس سازگاری
function astra_child_render_compatibility_meta($post) {
    $engine_type = get_post_meta($post->ID, '_engine_type', true);
    $year_from = get_post_meta($post->ID, '_year_from', true);
    $year_to = get_post_meta($post->ID, '_year_to', true);
    ?>
    <p>
        <label>نوع موتور:</label>
        <input type="text" name="_engine_type" value="<?php echo esc_attr($engine_type); ?>" style="width:100%">
    </p>
    <p>
        <label>از سال:</label>
        <input type="number" name="_year_from" value="<?php echo esc_attr($year_from); ?>" style="width:48%;margin-left:2%">
        <label>تا سال:</label>
        <input type="number" name="_year_to" value="<?php echo esc_attr($year_to); ?>" style="width:48%">
    </p>
    <?php
}

// ========== رندر متاباکس تصاویر Hero (دسکتاپ و موبایل) ==========
function astra_child_render_hero_images_meta($post) {
    wp_nonce_field('product_hero_images_nonce', 'product_hero_images_nonce');
    
    $desktop_image_id = get_post_meta($post->ID, '_hero_image_desktop', true);
    $mobile_image_id = get_post_meta($post->ID, '_hero_image_mobile', true);
    
    $desktop_url = $desktop_image_id ? wp_get_attachment_url($desktop_image_id) : '';
    $mobile_url = $mobile_image_id ? wp_get_attachment_url($mobile_image_id) : '';
    ?>
    <style>
        .hero-images-wrapper {
            display: flex;
            gap: 30px;
            flex-wrap: wrap;
        }
        .hero-image-box {
            flex: 1;
            min-width: 250px;
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 4px;
            background: #f9f9f9;
        }
        .hero-image-box h4 {
            margin-top: 0;
            color: #23282d;
            border-bottom: 2px solid #0073aa;
            padding-bottom: 8px;
        }
        .hero-image-box .image-preview {
            margin: 10px 0;
            min-height: 100px;
            background: #fff;
            border: 1px dashed #ddd;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .hero-image-box .image-preview img {
            max-width: 100%;
            height: auto;
            max-height: 200px;
        }
        .hero-image-box button {
            margin-top: 5px;
        }
        .hero-image-box .description {
            margin-top: 8px;
            font-style: italic;
            color: #666;
        }
    </style>
    
    <div class="hero-images-wrapper">
        <!-- تصویر دسکتاپ -->
        <div class="hero-image-box">
            <h4>💻 تصویر دسکتاپ</h4>
            <div class="image-preview">
                <?php if ($desktop_url) : ?>
                    <img src="<?php echo esc_url($desktop_url); ?>" alt="تصویر Hero دسکتاپ">
                <?php else : ?>
                    <span style="color: #999;">تصویری انتخاب نشده است</span>
                <?php endif; ?>
            </div>
            <input type="hidden" id="hero_image_desktop" name="hero_image_desktop" value="<?php echo esc_attr($desktop_image_id); ?>">
            <button type="button" class="button upload-hero-btn" data-target="desktop">انتخاب یا آپلود تصویر</button>
            <button type="button" class="button remove-hero-btn" data-target="desktop" <?php echo $desktop_image_id ? '' : 'style="display:none;"'; ?>>حذف تصویر</button>
            <p class="description">تصویر برای نمایش در دسکتاپ (حداقل عرض 1200px)</p>
        </div>
        
        <!-- تصویر موبایل -->
        <div class="hero-image-box">
            <h4>📱 تصویر موبایل</h4>
            <div class="image-preview">
                <?php if ($mobile_url) : ?>
                    <img src="<?php echo esc_url($mobile_url); ?>" alt="تصویر Hero موبایل">
                <?php else : ?>
                    <span style="color: #999;">تصویری انتخاب نشده است</span>
                <?php endif; ?>
            </div>
            <input type="hidden" id="hero_image_mobile" name="hero_image_mobile" value="<?php echo esc_attr($mobile_image_id); ?>">
            <button type="button" class="button upload-hero-btn" data-target="mobile">انتخاب یا آپلود تصویر</button>
            <button type="button" class="button remove-hero-btn" data-target="mobile" <?php echo $mobile_image_id ? '' : 'style="display:none;"'; ?>>حذف تصویر</button>
            <p class="description">تصویر برای نمایش در موبایل (حداقل عرض 768px)</p>
        </div>
    </div>
    
    <script>
        jQuery(document).ready(function($) {
            function initHeroImagesUploader() {
                $('.upload-hero-btn').off('click').on('click', function(e) {
                    e.preventDefault();
                    var button = $(this);
                    var target = button.data('target');
                    var wrapper = button.closest('.hero-image-box');
                    var input = wrapper.find('input[type="hidden"]');
                    var preview = wrapper.find('.image-preview');
                    var removeBtn = wrapper.find('.remove-hero-btn');
                    
                    var frame = wp.media({
                        title: 'انتخاب تصویر Hero - ' + (target === 'desktop' ? 'دسکتاپ' : 'موبایل'),
                        multiple: false,
                        library: { type: 'image' }
                    });
                    
                    frame.on('select', function() {
                        var attachment = frame.state().get('selection').first().toJSON();
                        input.val(attachment.id);
                        preview.html('<img src="' + attachment.url + '" alt="تصویر Hero">');
                        removeBtn.show();
                    });
                    
                    frame.open();
                });
                
                $('.remove-hero-btn').off('click').on('click', function(e) {
                    e.preventDefault();
                    var wrapper = $(this).closest('.hero-image-box');
                    wrapper.find('input[type="hidden"]').val('');
                    wrapper.find('.image-preview').html('<span style="color: #999;">تصویری انتخاب نشده است</span>');
                    $(this).hide();
                });
            }
            
            initHeroImagesUploader();
            $(document).ajaxComplete(function() {
                initHeroImagesUploader();
            });
        });
    </script>
    <?php
}

/**
 * ذخیره متافیلدها
 */
add_action('save_post_product', 'astra_child_save_product_meta');
function astra_child_save_product_meta($post_id) {
    
    if (!isset($_POST['product_meta_nonce']) || !wp_verify_nonce($_POST['product_meta_nonce'], 'product_meta_nonce')) {
        return;
    }
    
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    $fields = array(
        '_oem_code', '_part_number', '_barcode',
        '_engine_type', '_year_from', '_year_to'
    );
    
    foreach ($fields as $field) {
        if (isset($_POST[$field])) {
            update_post_meta($post_id, $field, sanitize_text_field($_POST[$field]));
        }
    }

    // ========== ذخیره تصاویر Hero ==========
    if (isset($_POST['product_hero_images_nonce']) && wp_verify_nonce($_POST['product_hero_images_nonce'], 'product_hero_images_nonce')) {
        
        // تصویر دسکتاپ
        if (isset($_POST['hero_image_desktop'])) {
            $desktop_id = intval($_POST['hero_image_desktop']);
            if ($desktop_id > 0) {
                update_post_meta($post_id, '_hero_image_desktop', $desktop_id);
            } else {
                delete_post_meta($post_id, '_hero_image_desktop');
            }
        }
        
        // تصویر موبایل
        if (isset($_POST['hero_image_mobile'])) {
            $mobile_id = intval($_POST['hero_image_mobile']);
            if ($mobile_id > 0) {
                update_post_meta($post_id, '_hero_image_mobile', $mobile_id);
            } else {
                delete_post_meta($post_id, '_hero_image_mobile');
            }
        }
    }
}

/**
 * اضافه کردن فیلدهای قیمت همکار
 */
add_action('woocommerce_product_options_pricing', 'astra_child_add_partner_price_fields');
function astra_child_add_partner_price_fields() {
    echo '<div class="options_group">';
    
    woocommerce_wp_text_input(array(
        'id' => '_partner_price',
        'label' => 'قیمت همکار (تومان)',
        'placeholder' => '',
        'desc_tip' => true,
        'description' => 'قیمت ویژه برای کاربران با نقش همکار',
        'type' => 'number',
        'custom_attributes' => array(
            'step' => 'any',
            'min' => '0'
        )
    ));
    
    woocommerce_wp_text_input(array(
        'id' => '_partner_sale_price',
        'label' => 'قیمت با تخفیف همکار (تومان)',
        'placeholder' => '',
        'desc_tip' => true,
        'description' => 'قیمت تخفیف‌خورده برای همکاران (اختیاری)',
        'type' => 'number',
        'custom_attributes' => array(
            'step' => 'any',
            'min' => '0'
        )
    ));
    
    echo '</div>';
}

add_action('woocommerce_process_product_meta', 'astra_child_save_partner_price_fields');
function astra_child_save_partner_price_fields($post_id) {
    $partner_price = isset($_POST['_partner_price']) ? sanitize_text_field($_POST['_partner_price']) : '';
    $partner_sale_price = isset($_POST['_partner_sale_price']) ? sanitize_text_field($_POST['_partner_sale_price']) : '';
    
    update_post_meta($post_id, '_partner_price', $partner_price);
    update_post_meta($post_id, '_partner_sale_price', $partner_sale_price);
}

// ======================== شروع بخش تصاویر تاکسونومی‌ها ========================

/**
 * افزودن فیلد تصویر به تاکسونومی‌های مشخص شده
 */
add_action('init', 'astra_child_add_taxonomy_image_field');
function astra_child_add_taxonomy_image_field() {
    // نام تاکسونومی‌هایی که می‌خواهید تصویر داشته باشند
    $target_taxonomies = array(
        'car_brand',
        'car_model',
        'car_generation',
        'part_brand',
        'car_system',
        'quality_grade',
        'install_position'
    );

    foreach ($target_taxonomies as $taxonomy) {
        // فیلد تصویر در صفحه افزودن عبارت جدید
        add_action("{$taxonomy}_add_form_fields", 'astra_child_taxonomy_add_image_field');
        // فیلد تصویر در صفحه ویرایش عبارت
        add_action("{$taxonomy}_edit_form_fields", 'astra_child_taxonomy_edit_image_field', 10, 2);
        // ذخیره‌سازی متا هنگام افزودن یا ویرایش
        add_action("created_{$taxonomy}", 'astra_child_save_taxonomy_image');
        add_action("edited_{$taxonomy}", 'astra_child_save_taxonomy_image');

        // ========== افزودن فیلدهای تصویر Hero برای تاکسونومی‌ها (دسکتاپ و موبایل) ==========
        add_action("{$taxonomy}_add_form_fields", 'astra_child_taxonomy_add_hero_images_field');
        add_action("{$taxonomy}_edit_form_fields", 'astra_child_taxonomy_edit_hero_images_field', 10, 2);
        add_action("created_{$taxonomy}", 'astra_child_save_taxonomy_hero_images');
        add_action("edited_{$taxonomy}", 'astra_child_save_taxonomy_hero_images');
    }
}

/**
 * نمایش فیلد تصویر در صفحه افزودن عبارت جدید
 */
function astra_child_taxonomy_add_image_field($taxonomy) {
    ?>
    <div class="form-field term-image-wrap">
        <label for="taxonomy_image_id">تصویر دسته</label>
        <div class="taxonomy-image-wrapper">
            <input type="hidden" id="taxonomy_image_id" name="taxonomy_image_id" value="">
            <div class="image-preview"></div>
            <button type="button" class="button upload-taxonomy-image-btn">انتخاب یا آپلود تصویر</button>
            <button type="button" class="button remove-taxonomy-image-btn" style="display:none;">حذف تصویر</button>
        </div>
        <p class="description">یک تصویر برای این عبارت انتخاب کنید.</p>
    </div>
    <?php
    astra_child_taxonomy_image_scripts();
}

/**
 * نمایش فیلد تصویر در صفحه ویرایش عبارت
 */
function astra_child_taxonomy_edit_image_field($term, $taxonomy) {
    $image_id = get_term_meta($term->term_id, 'taxonomy_image_id', true);
    $image_url = $image_id ? wp_get_attachment_url($image_id) : '';
    ?>
    <tr class="form-field term-image-wrap">
        <th scope="row"><label for="taxonomy_image_id">تصویر دسته</label></th>
        <td>
            <div class="taxonomy-image-wrapper">
                <input type="hidden" id="taxonomy_image_id" name="taxonomy_image_id" value="<?php echo esc_attr($image_id); ?>">
                <div class="image-preview">
                    <?php if ($image_url) : ?>
                        <img src="<?php echo esc_url($image_url); ?>" style="max-width:150px; max-height:150px;">
                    <?php endif; ?>
                </div>
                <button type="button" class="button upload-taxonomy-image-btn">انتخاب یا آپلود تصویر</button>
                <button type="button" class="button remove-taxonomy-image-btn" <?php echo $image_id ? '' : 'style="display:none;"'; ?>>حذف تصویر</button>
            </div>
            <p class="description">تصویر این عبارت را انتخاب کنید.</p>
        </td>
    </tr>
    <?php
    astra_child_taxonomy_image_scripts();
}

/**
 * اسکریپت و استایل مورد نیاز برای آپلودر رسانه
 */
function astra_child_taxonomy_image_scripts() {
    wp_enqueue_media();
    ?>
    <style>
        .taxonomy-image-wrapper .image-preview img {
            margin-bottom: 10px;
            max-width: 150px;
            height: auto;
            display: block;
        }
        .taxonomy-image-wrapper button {
            margin-top: 5px;
        }
    </style>
    <script>
        jQuery(document).ready(function($) {
            function initTaxonomyImageUploader() {
                $('.upload-taxonomy-image-btn').off('click').on('click', function(e) {
                    e.preventDefault();
                    var button = $(this);
                    var wrapper = button.closest('.taxonomy-image-wrapper');
                    var imageIdInput = wrapper.find('#taxonomy_image_id');
                    var imagePreview = wrapper.find('.image-preview');
                    var removeBtn = wrapper.find('.remove-taxonomy-image-btn');
                    
                    var frame = wp.media({
                        title: 'انتخاب تصویر دسته',
                        multiple: false,
                        library: { type: 'image' }
                    });
                    
                    frame.on('select', function() {
                        var attachment = frame.state().get('selection').first().toJSON();
                        imageIdInput.val(attachment.id);
                        imagePreview.html('<img src="' + attachment.url + '" style="max-width:150px; max-height:150px;">');
                        removeBtn.show();
                    });
                    
                    frame.open();
                });
                
                $('.remove-taxonomy-image-btn').off('click').on('click', function(e) {
                    e.preventDefault();
                    var wrapper = $(this).closest('.taxonomy-image-wrapper');
                    wrapper.find('#taxonomy_image_id').val('');
                    wrapper.find('.image-preview').html('');
                    $(this).hide();
                });
            }
            
            initTaxonomyImageUploader();
            $(document).ajaxComplete(function() {
                initTaxonomyImageUploader();
            });
        });
    </script>
    <?php
}

/**
 * ذخیره‌سازی شناسه تصویر هنگام افزودن یا ویرایش عبارت
 */
function astra_child_save_taxonomy_image($term_id) {
    if (isset($_POST['taxonomy_image_id'])) {
        $image_id = intval($_POST['taxonomy_image_id']);
        if ($image_id) {
            update_term_meta($term_id, 'taxonomy_image_id', $image_id);
        } else {
            delete_term_meta($term_id, 'taxonomy_image_id');
        }
    }
}

// ========== فیلدهای تصویر Hero برای تاکسونومی‌ها (دسکتاپ و موبایل) ==========

/**
 * نمایش فیلدهای تصویر Hero در صفحه افزودن عبارت جدید
 */
function astra_child_taxonomy_add_hero_images_field($taxonomy) {
    ?>
    <div class="form-field term-hero-images-wrap">
        <label>تصاویر Hero Section</label>
        <div class="taxonomy-hero-images-wrapper" style="display: flex; gap: 20px; flex-wrap: wrap; margin-bottom: 10px;">
            <!-- دسکتاپ -->
            <div style="flex: 1; min-width: 200px; border: 1px solid #ddd; padding: 10px; border-radius: 4px; background: #f9f9f9;">
                <h4 style="margin: 0 0 8px 0; font-size: 14px;">💻 تصویر دسکتاپ</h4>
                <input type="hidden" id="hero_image_desktop" name="hero_image_desktop" value="">
                <div class="image-preview" style="min-height: 80px; background: #fff; border: 1px dashed #ddd; margin-bottom: 8px; display: flex; align-items: center; justify-content: center;">
                    <span style="color: #999; font-size: 12px;">تصویری انتخاب نشده</span>
                </div>
                <button type="button" class="button upload-taxonomy-hero-btn" data-target="desktop" style="margin-top: 5px;">انتخاب تصویر</button>
                <button type="button" class="button remove-taxonomy-hero-btn" data-target="desktop" style="display:none; margin-top: 5px;">حذف</button>
            </div>
            
            <!-- موبایل -->
            <div style="flex: 1; min-width: 200px; border: 1px solid #ddd; padding: 10px; border-radius: 4px; background: #f9f9f9;">
                <h4 style="margin: 0 0 8px 0; font-size: 14px;">📱 تصویر موبایل</h4>
                <input type="hidden" id="hero_image_mobile" name="hero_image_mobile" value="">
                <div class="image-preview" style="min-height: 80px; background: #fff; border: 1px dashed #ddd; margin-bottom: 8px; display: flex; align-items: center; justify-content: center;">
                    <span style="color: #999; font-size: 12px;">تصویری انتخاب نشده</span>
                </div>
                <button type="button" class="button upload-taxonomy-hero-btn" data-target="mobile" style="margin-top: 5px;">انتخاب تصویر</button>
                <button type="button" class="button remove-taxonomy-hero-btn" data-target="mobile" style="display:none; margin-top: 5px;">حذف</button>
            </div>
        </div>
        <p class="description">تصاویر بنر بزرگ (Hero) برای این عبارت در دسکتاپ و موبایل.</p>
    </div>
    <?php
    astra_child_taxonomy_hero_scripts_v2();
}

/**
 * نمایش فیلدهای تصویر Hero در صفحه ویرایش عبارت
 */
function astra_child_taxonomy_edit_hero_images_field($term, $taxonomy) {
    $desktop_id = get_term_meta($term->term_id, 'hero_image_desktop', true);
    $mobile_id = get_term_meta($term->term_id, 'hero_image_mobile', true);
    
    $desktop_url = $desktop_id ? wp_get_attachment_url($desktop_id) : '';
    $mobile_url = $mobile_id ? wp_get_attachment_url($mobile_id) : '';
    ?>
    <tr class="form-field term-hero-images-wrap">
        <th scope="row"><label>تصاویر Hero Section</label></th>
        <td>
            <div class="taxonomy-hero-images-wrapper" style="display: flex; gap: 20px; flex-wrap: wrap; margin-bottom: 10px;">
                <!-- دسکتاپ -->
                <div style="flex: 1; min-width: 200px; border: 1px solid #ddd; padding: 10px; border-radius: 4px; background: #f9f9f9;">
                    <h4 style="margin: 0 0 8px 0; font-size: 14px;">💻 تصویر دسکتاپ</h4>
                    <input type="hidden" id="hero_image_desktop" name="hero_image_desktop" value="<?php echo esc_attr($desktop_id); ?>">
                    <div class="image-preview" style="min-height: 80px; background: #fff; border: 1px dashed #ddd; margin-bottom: 8px; display: flex; align-items: center; justify-content: center;">
                        <?php if ($desktop_url) : ?>
                            <img src="<?php echo esc_url($desktop_url); ?>" style="max-width:100%; max-height:150px;">
                        <?php else : ?>
                            <span style="color: #999; font-size: 12px;">تصویری انتخاب نشده</span>
                        <?php endif; ?>
                    </div>
                    <button type="button" class="button upload-taxonomy-hero-btn" data-target="desktop" style="margin-top: 5px;">انتخاب تصویر</button>
                    <button type="button" class="button remove-taxonomy-hero-btn" data-target="desktop" <?php echo $desktop_id ? '' : 'style="display:none; margin-top: 5px;"'; ?>>حذف</button>
                </div>
                
                <!-- موبایل -->
                <div style="flex: 1; min-width: 200px; border: 1px solid #ddd; padding: 10px; border-radius: 4px; background: #f9f9f9;">
                    <h4 style="margin: 0 0 8px 0; font-size: 14px;">📱 تصویر موبایل</h4>
                    <input type="hidden" id="hero_image_mobile" name="hero_image_mobile" value="<?php echo esc_attr($mobile_id); ?>">
                    <div class="image-preview" style="min-height: 80px; background: #fff; border: 1px dashed #ddd; margin-bottom: 8px; display: flex; align-items: center; justify-content: center;">
                        <?php if ($mobile_url) : ?>
                            <img src="<?php echo esc_url($mobile_url); ?>" style="max-width:100%; max-height:150px;">
                        <?php else : ?>
                            <span style="color: #999; font-size: 12px;">تصویری انتخاب نشده</span>
                        <?php endif; ?>
                    </div>
                    <button type="button" class="button upload-taxonomy-hero-btn" data-target="mobile" style="margin-top: 5px;">انتخاب تصویر</button>
                    <button type="button" class="button remove-taxonomy-hero-btn" data-target="mobile" <?php echo $mobile_id ? '' : 'style="display:none; margin-top: 5px;"'; ?>>حذف</button>
                </div>
            </div>
            <p class="description">تصاویر بنر بزرگ (Hero) برای این عبارت در دسکتاپ و موبایل.</p>
        </td>
    </tr>
    <?php
    astra_child_taxonomy_hero_scripts_v2();
}

/**
 * اسکریپت و استایل آپلودر برای تصویر Hero تاکسونومی‌ها (نسخه ۲)
 */
function astra_child_taxonomy_hero_scripts_v2() {
    wp_enqueue_media();
    ?>
    <style>
        .taxonomy-hero-images-wrapper .image-preview {
            min-height: 80px;
            background: #fff;
            border: 1px dashed #ddd;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .taxonomy-hero-images-wrapper .image-preview img {
            max-width: 100%;
            height: auto;
            max-height: 150px;
        }
        .taxonomy-hero-images-wrapper button {
            margin-right: 5px;
        }
    </style>
    <script>
        jQuery(document).ready(function($) {
            function initTaxonomyHeroUploaderV2() {
                $('.upload-taxonomy-hero-btn').off('click').on('click', function(e) {
                    e.preventDefault();
                    var button = $(this);
                    var target = button.data('target');
                    var wrapper = button.closest('div[style*="flex: 1"]');
                    var input = wrapper.find('input[type="hidden"]');
                    var preview = wrapper.find('.image-preview');
                    var removeBtn = wrapper.find('.remove-taxonomy-hero-btn');
                    
                    var frame = wp.media({
                        title: 'انتخاب تصویر Hero - ' + (target === 'desktop' ? 'دسکتاپ' : 'موبایل'),
                        multiple: false,
                        library: { type: 'image' }
                    });
                    
                    frame.on('select', function() {
                        var attachment = frame.state().get('selection').first().toJSON();
                        input.val(attachment.id);
                        preview.html('<img src="' + attachment.url + '" alt="تصویر Hero">');
                        removeBtn.show();
                    });
                    
                    frame.open();
                });
                
                $('.remove-taxonomy-hero-btn').off('click').on('click', function(e) {
                    e.preventDefault();
                    var wrapper = $(this).closest('div[style*="flex: 1"]');
                    wrapper.find('input[type="hidden"]').val('');
                    wrapper.find('.image-preview').html('<span style="color: #999; font-size: 12px;">تصویری انتخاب نشده</span>');
                    $(this).hide();
                });
            }
            
            initTaxonomyHeroUploaderV2();
            $(document).ajaxComplete(function() {
                initTaxonomyHeroUploaderV2();
            });
        });
    </script>
    <?php
}

/**
 * ذخیره تصاویر Hero تاکسونومی
 */
function astra_child_save_taxonomy_hero_images($term_id) {
    // ذخیره تصویر دسکتاپ
    if (isset($_POST['hero_image_desktop'])) {
        $desktop_id = intval($_POST['hero_image_desktop']);
        if ($desktop_id > 0) {
            update_term_meta($term_id, 'hero_image_desktop', $desktop_id);
        } else {
            delete_term_meta($term_id, 'hero_image_desktop');
        }
    }
    
    // ذخیره تصویر موبایل
    if (isset($_POST['hero_image_mobile'])) {
        $mobile_id = intval($_POST['hero_image_mobile']);
        if ($mobile_id > 0) {
            update_term_meta($term_id, 'hero_image_mobile', $mobile_id);
        } else {
            delete_term_meta($term_id, 'hero_image_mobile');
        }
    }
}

/**
 * نمایش ستون‌های تصاویر در صفحه لیست عبارات هر تاکسونومی
 */
add_filter('manage_edit-car_brand_columns', 'astra_child_add_taxonomy_image_column');
add_filter('manage_edit-car_model_columns', 'astra_child_add_taxonomy_image_column');
add_filter('manage_edit-car_generation_columns', 'astra_child_add_taxonomy_image_column');
add_filter('manage_edit-part_brand_columns', 'astra_child_add_taxonomy_image_column');
add_filter('manage_edit-car_system_columns', 'astra_child_add_taxonomy_image_column');
add_filter('manage_edit-quality_grade_columns', 'astra_child_add_taxonomy_image_column');
add_filter('manage_edit-install_position_columns', 'astra_child_add_taxonomy_image_column');

function astra_child_add_taxonomy_image_column($columns) {
    $new_columns = array();
    foreach ($columns as $key => $title) {
        $new_columns[$key] = $title;
        if ($key === 'name') {
            $new_columns['taxonomy_image'] = 'تصویر دسته';
            $new_columns['hero_desktop'] = 'Hero (Desktop)';
            $new_columns['hero_mobile'] = 'Hero (Mobile)';
        }
    }
    return $new_columns;
}

// اضافه کردن فیلترهای ستون برای هر تاکسونومی
$taxonomies = array('car_brand', 'car_model', 'car_generation', 'part_brand', 'car_system', 'quality_grade', 'install_position');
foreach ($taxonomies as $tax) {
    add_filter("manage_{$tax}_custom_column", 'astra_child_display_taxonomy_image_column_v2', 10, 3);
}

function astra_child_display_taxonomy_image_column_v2($content, $column_name, $term_id) {
    if ($column_name === 'taxonomy_image') {
        $image_id = get_term_meta($term_id, 'taxonomy_image_id', true);
        if ($image_id) {
            $image_url = wp_get_attachment_image_url($image_id, 'thumbnail');
            return '<img src="' . esc_url($image_url) . '" width="40" height="40" style="border-radius:4px;" />';
        }
        return '—';
    }
    
    if ($column_name === 'hero_desktop') {
        $image_id = get_term_meta($term_id, 'hero_image_desktop', true);
        if ($image_id) {
            $image_url = wp_get_attachment_image_url($image_id, 'thumbnail');
            return '<img src="' . esc_url($image_url) . '" width="40" height="40" style="border-radius:4px;" />';
        }
        return '—';
    }
    
    if ($column_name === 'hero_mobile') {
        $image_id = get_term_meta($term_id, 'hero_image_mobile', true);
        if ($image_id) {
            $image_url = wp_get_attachment_image_url($image_id, 'thumbnail');
            return '<img src="' . esc_url($image_url) . '" width="40" height="40" style="border-radius:4px;" />';
        }
        return '—';
    }
    
    return $content;
}

/**
 * افزودن پست‌تایپ 'product' به کوئریِ آرشیوِ تاکسونومی‌های سفارشی
 */
add_action( 'pre_get_posts', 'astra_child_fix_custom_tax_archives' );
function astra_child_fix_custom_tax_archives( $query ) {
    if ( is_admin() || ! $query->is_main_query() ) {
        return;
    }

    $custom_taxonomies = array(
        'car_brand',
        'car_model',
        'car_generation',
        'part_brand',
        'car_system',
        'quality_grade',
        'install_position'
    );

    if ( is_tax( $custom_taxonomies ) ) {
        $query->set( 'post_type', array( 'product' ) ); 
    }
}

// =========================================================================
// ۱. ثبت تاکسونومی مرکزی برای "انواع قطعه" (Part Type)
// =========================================================================
add_action('init', 'astra_child_register_part_type_taxonomy');
function astra_child_register_part_type_taxonomy() {
    register_taxonomy('part_type', 'product', array(
        'label' => 'نوع قطعه (برای تخصیص به برند)',
        'hierarchical' => true,
        'show_in_rest' => true,
        'show_admin_column' => true,
        'rewrite' => array('slug' => 'part-type')
    ));
}

// =========================================================================
// ۲. افزودن فیلد انتخاب "انواع قطعه" به تاکسونومی "برند قطعه" (part_brand)
// =========================================================================

// فرم افزودن برند جدید
add_action('part_brand_add_form_fields', 'astra_child_add_part_types_to_brand');
function astra_child_add_part_types_to_brand() {
    $part_types = get_terms(array('taxonomy' => 'part_type', 'hide_empty' => false));
    ?>
    <div class="form-field">
        <label>قطعات تولیدی این برند</label>
        <div style="max-height: 200px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; background: #fff;">
            <?php foreach ($part_types as $type) : ?>
                <label style="display: block; margin-bottom: 5px;">
                    <input type="checkbox" name="brand_part_types[]" value="<?php echo esc_attr($type->term_id); ?>">
                    <?php echo esc_html($type->name); ?>
                </label>
            <?php endforeach; ?>
            <?php if(empty($part_types)) echo '<p>ابتدا چند "نوع قطعه" تعریف کنید.</p>'; ?>
        </div>
        <p class="description">قطعاتی که این برند تولید می‌کند را انتخاب کنید (تأثیر مستقیم در سئو).</p>
    </div>
    <?php
}

// فرم ویرایش برند
add_action('part_brand_edit_form_fields', 'astra_child_edit_part_types_to_brand', 10, 2);
function astra_child_edit_part_types_to_brand($term, $taxonomy) {
    $part_types = get_terms(array('taxonomy' => 'part_type', 'hide_empty' => false));
    $selected_types = get_term_meta($term->term_id, '_brand_part_types', true);
    if (!is_array($selected_types)) $selected_types = array();
    ?>
    <tr class="form-field">
        <th scope="row"><label>قطعات تولیدی این برند</label></th>
        <td>
            <div style="max-height: 200px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; background: #fff; width: fit-content; min-width: 300px;">
                <?php foreach ($part_types as $type) : ?>
                    <label style="display: block; margin-bottom: 5px;">
                        <input type="checkbox" name="brand_part_types[]" value="<?php echo esc_attr($type->term_id); ?>" <?php checked(in_array($type->term_id, $selected_types)); ?>>
                        <?php echo esc_html($type->name); ?>
                    </label>
                <?php endforeach; ?>
            </div>
            <p class="description">قطعات مرتبط را تیک بزنید تا در صفحه آرشیو لینک‌سازی داخلی انجام شود.</p>
        </td>
    </tr>
    <?php
}

// ذخیره متا دیتای برند
add_action('created_part_brand', 'astra_child_save_brand_part_types');
add_action('edited_part_brand', 'astra_child_save_brand_part_types');
function astra_child_save_brand_part_types($term_id) {
    if (isset($_POST['brand_part_types']) && is_array($_POST['brand_part_types'])) {
        $types = array_map('intval', $_POST['brand_part_types']);
        update_term_meta($term_id, '_brand_part_types', $types);
    } else {
        delete_term_meta($term_id, '_brand_part_types');
    }
}

// =========================================================================
// ۳. خروجی سئو: تزریق خودکار لینک‌ها به توضیحات برند در بخش کاربری
// =========================================================================
add_filter('term_description', 'astra_child_inject_seo_links_to_brand', 10, 2);
function astra_child_inject_seo_links_to_brand($description, $term_id) {
    if (is_admin()) return $description;
    
    $term = get_term($term_id);
    if (!$term || !is_wp_error($term)) {
        if ($term->taxonomy === 'part_brand') {
            $selected_types = get_term_meta($term_id, '_brand_part_types', true);
            
            if (!empty($selected_types) && is_array($selected_types)) {
                $links = array();
                foreach ($selected_types as $type_id) {
                    $type_term = get_term($type_id, 'part_type');
                    if ($type_term && !is_wp_error($type_term)) {
                        $term_link = get_term_link($type_term);
                        $links[] = '<a href="' . esc_url($term_link) . '" title="قطعات ' . esc_attr($type_term->name) . '" style="font-weight:bold;">' . esc_html($type_term->name) . '</a>';
                    }
                }
                
                if (!empty($links)) {
                    $seo_paragraph = '<div class="brand-seo-tags" style="margin-top: 15px; padding: 15px; background: #f9f9f9; border-right: 4px solid #0073aa; border-radius: 4px;">';
                    $seo_paragraph .= '<strong>تخصص‌ها و تولیدات:</strong> برند ' . esc_html($term->name) . ' قطعات متنوعی را به بازار عرضه می‌کند. از مهم‌ترین دسته‌بندی‌های تولیدی این شرکت می‌توان به ' . implode('، ', $links) . ' اشاره کرد.';
                    $seo_paragraph .= '</div>';
                    
                    $description .= $seo_paragraph;
                }
            }
        }
    }
    return $description;
}

// =========================================================================
// ۴. تابع کمکی برای نمایش تصویر Hero مناسب با دستگاه
// =========================================================================
function astra_child_get_hero_image($post_id = null, $taxonomy_term_id = null, $size = 'full') {
    $desktop_id = null;
    $mobile_id = null;
    
    if ($post_id) {
        // برای محصولات
        $desktop_id = get_post_meta($post_id, '_hero_image_desktop', true);
        $mobile_id = get_post_meta($post_id, '_hero_image_mobile', true);
    } elseif ($taxonomy_term_id) {
        // برای تاکسونومی‌ها
        $desktop_id = get_term_meta($taxonomy_term_id, 'hero_image_desktop', true);
        $mobile_id = get_term_meta($taxonomy_term_id, 'hero_image_mobile', true);
    } else {
        return false;
    }
    
    // انتخاب تصویر مناسب بر اساس دستگاه
    $image_id = wp_is_mobile() ? $mobile_id : $desktop_id;
    
    // اگر تصویر مخصوص دستگاه وجود نداشت، از تصویر دیگر استفاده کن
    if (!$image_id) {
        $image_id = wp_is_mobile() ? $desktop_id : $mobile_id;
    }
    
    if ($image_id) {
        return wp_get_attachment_image($image_id, $size);
    }
    
    return false;
}
?>