<?php
function custom_subcats_and_menu_shortcode($atts) {
    // دریافت و تنظیم مقادیر پیش‌فرض شورت‌کد
    $atts = shortcode_atts(array(
        'cat_id'  => '',
        'menu_id' => '',
        'tax'     => 'product_cat' // برای مقالات وردپرس به 'category' تغییر دهید
    ), $atts);

    $html = '<ul class="custom-category-menu">';

    // ۱. فراخوانی زیرمجموعه‌های دسته اصلی
    if (!empty($atts['cat_id'])) {
        $terms = get_terms(array(
            'taxonomy'   => $atts['tax'],
            'parent'     => intval($atts['cat_id']),
            'hide_empty' => false, // اگر می‌خواهید دسته‌های خالی نمایش داده نشوند این را true کنید
        ));

        if (!is_wp_error($terms) && !empty($terms)) {
            foreach ($terms as $term) {
                $term_link = get_term_link($term);
                $html .= sprintf(
                    '<li class="cat-item cat-item-%d"><a href="%s">%s</a></li>',
                    esc_attr($term->term_id),
                    esc_url($term_link),
                    esc_html($term->name)
                );
            }
        }
    }

    // ۲. فراخوانی آیتم‌های یک فهرست (Menu)
    if (!empty($atts['menu_id'])) {
        // menu_id می‌تواند ID فهرست، نام (Name) یا نامک (Slug) آن باشد
        $menu_items = wp_get_nav_menu_items($atts['menu_id']);
        
        if ($menu_items && !is_wp_error($menu_items)) {
            foreach ($menu_items as $item) {
                $html .= sprintf(
                    '<li class="menu-item menu-item-%d"><a href="%s">%s</a></li>',
                    esc_attr($item->ID),
                    esc_url($item->url),
                    esc_html($item->title)
                );
            }
        }
    }

    $html .= '</ul>';

    return $html;
}
add_shortcode('hybrid_menu', 'custom_subcats_and_menu_shortcode');