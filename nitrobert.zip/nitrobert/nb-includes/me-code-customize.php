<?php
// ============================================================
// 1. نمایش محصولات ناموجود در انتهای لیست (فقط در صفحات فروشگاه)
// ============================================================
add_action('pre_get_posts', 'nitrobert_move_out_of_stock_to_end');
function nitrobert_move_out_of_stock_to_end($query) {
    // فقط در صفحات فروشگاه و دسته‌بندی و فقط کوئری اصلی
    if ( ! is_admin() && $query->is_main_query() && ( is_shop() || is_product_category() ) ) {
        $query->set('meta_key', '_stock_status');
        $query->set('orderby', 'meta_value');
        $query->set('order', 'ASC');
    }
}
// ============================================================
// 2. نمایش ترم‌های تاکسونومی با سلسله‌مراتب کامل (بدون کوئری اضافی) - نسخه نهایی
// ============================================================
function gap_display_tax_row( $taxonomy, $title, $term_sep = '، ', $hierarchy_sep = ' > ' ) {
    global $post;

    if ( ! $post || $post->post_type !== 'product' ) {
        return '';
    }

    $terms = get_the_terms( $post->ID, $taxonomy );
    if ( empty( $terms ) || is_wp_error( $terms ) ) {
        return '';
    }

    // دریافت همه ترم‌های این تاکسونومی
    $all_terms = get_terms( array(
        'taxonomy'   => $taxonomy,
        'hide_empty' => false,
    ) );

    // ساخت آرایه والدین
    $parent_map = array();
    foreach ( $all_terms as $t ) {
        $parent_map[ $t->term_id ] = $t->parent;
    }

    // شناسه‌های ترم‌هایی که مستقیماً به پست متصل هستند
    $assigned_ids = wp_list_pluck( $terms, 'term_id' );

    $term_items = array();
    foreach ( $terms as $term ) {
        $path = array();
        $current_id = $term->term_id;

        while ( $current_id && isset( $parent_map[ $current_id ] ) ) {
            $current_term = null;
            foreach ( $all_terms as $t ) {
                if ( $t->term_id == $current_id ) {
                    $current_term = $t;
                    break;
                }
            }
            if ( ! $current_term ) {
                break;
            }

            // فقط ترم جاری و نیاکانی که مستقیماً به پست متصل نیستند را اضافه کن
            if ( $current_id == $term->term_id || ! in_array( $current_id, $assigned_ids ) ) {
                $path[] = $current_term->name;
            }

            $current_id = $parent_map[ $current_id ];
        }

        if ( empty( $path ) ) {
            $path[] = $term->name;
        }

        $full_path = implode( $hierarchy_sep, array_reverse( $path ) );

        $term_items[] = '<a href="' . esc_url( get_term_link( $term ) ) . '" class="info-term-link">'
                        . esc_html( $full_path ) . '</a>';
    }

    $output  = '<div class="car-part-info-row taxonomy-' . sanitize_html_class( $taxonomy ) . '">';
    $output .= '  <span class="info-label">' . esc_html( $title ) . '</span>';
    $output .= '  <div class="info-values">';
    $output .= implode( '<span class="term-separator">' . esc_html( $term_sep ) . '</span>', $term_items );
    $output .= '  </div>';
    $output .= '</div>';

    return $output;
}

// تعریف شورت‌کدها
add_shortcode( 'car_model_terms', function() {
    return gap_display_tax_row( 'car_model', 'مدل خودرو', '، ', ' > ' );
} );
add_shortcode( 'product_category_terms', function() {
    return gap_display_tax_row( 'product_cat', 'سیستم قطعه', ' | ', ' / ' );
} );
add_shortcode( 'car_brand_terms', function() {
    return gap_display_tax_row( 'car_brand', 'برند خودرو', '، ', ' > ' );
} );
add_shortcode( 'part_brand_terms', function() {
    return gap_display_tax_row( 'part_brand', 'برند قطعه', '، ', ' > ' );
} );
// ============================================================
// 3. نمایش SKU محصول
// ============================================================
function gap_display_sku_row() {
    global $post;
    if ( ! $post || $post->post_type !== 'product' ) {
        return '';
    }
    $sku = get_post_meta( $post->ID, '_sku', true );
    if ( empty( $sku ) ) {
        return '';
    }
    $output  = '<div class="car-part-info-row sku-row">';
    $output .= '  <span class="info-label">' . esc_html__( 'کد محصول', 'your-text-domain' ) . '</span>';
    $output .= '  <div class="info-values">';
    $output .= '    <span class="info-sku">' . esc_html( $sku ) . '</span>';
    $output .= '  </div>';
    $output .= '</div>';
    return $output;
}
add_shortcode( 'product_sku', 'gap_display_sku_row' );

// ============================================================
// 4. شورت‌کد شماره‌های تماس
// ============================================================
add_shortcode('support_phones', function() {
    $phones = [
        ['label' => 'واحد فروش ۱', 'number' => '09170555640'],
        ['label' => 'واحد فروش ۲', 'number' => '09170555740'],
        ['label' => 'واحد فروش 3', 'number' => '09170555840'],
    ];
    $output  = '<div class="contact-box">';
    $output .= '  <div class="contact-title">تماس با ما</div>';
    $output .= '  <div class="contact-list">';
    foreach ($phones as $phone) {
        $output .= '    <a href="tel:' . esc_attr($phone['number']) . '" class="contact-item">';
        $output .= '      <span class="label">' . esc_html($phone['label']) . '</span>';
        $output .= '      <span class="number">' . esc_html($phone['number']) . '</span>';
        $output .= '    </a>';
    }
    $output .= '  </div>';
    $output .= '</div>';
    return $output;
});

// ============================================================
// 5. محاسبه درصد تخفیف محصول
// ============================================================
function nitrobert_calculate_discount_percentage() {
    global $product;
    if ( ! $product ) {
        $product = wc_get_product( get_the_ID() );
    }
    if ( ! $product ) {
        return '';
    }

    $max_discount = 0;

    if ( $product->is_type('variable') ) {
        $variations = $product->get_available_variations();
        foreach ( $variations as $variation_data ) {
            $variation = wc_get_product( $variation_data['variation_id'] );
            if ( ! $variation ) continue;
            $regular = $variation->get_regular_price();
            $sale    = $variation->get_sale_price();
            if ( $regular > 0 && $sale > 0 ) {
                $discount = ( ( $regular - $sale ) / $regular ) * 100;
                $max_discount = max( $max_discount, $discount );
            }
        }
    } else {
        $regular = $product->get_regular_price();
        $sale    = $product->get_sale_price();
        if ( $regular > 0 && $sale > 0 ) {
            $max_discount = ( ( $regular - $sale ) / $regular ) * 100;
        }
    }

    if ( $max_discount > 0 ) {
        return ceil( $max_discount ) . '% تخفیف';
    }
    return '';
}
add_shortcode( 'nitrobert_product_discount_percentage', 'nitrobert_calculate_discount_percentage' );

// ============================================================
// 6. دکمه‌های + و – برای تعداد محصول (در صفحه محصول)
// ============================================================
add_action( 'woocommerce_before_add_to_cart_quantity', 'beban_display_quantity_minus' );
function beban_display_quantity_minus() {
    echo '<button type="button" class="minus" aria-label="کاهش تعداد">-</button>';
}
add_action( 'woocommerce_after_add_to_cart_quantity', 'beban_display_quantity_plus' );
function beban_display_quantity_plus() {
    echo '<button type="button" class="plus" aria-label="افزایش تعداد">+</button>';
}

add_action( 'wp_footer', 'beban_add_cart_quantity_plus_minus' );
function beban_add_cart_quantity_plus_minus() {
    if ( ! is_product() ) return;
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('form.cart').on('click', 'button.plus, button.minus', function(e) {
                e.preventDefault();
                var $qty = $(this).closest('form.cart').find('.qty');
                var val = parseFloat($qty.val()) || 0;
                var max = parseFloat($qty.attr('max')) || Infinity;
                var min = parseFloat($qty.attr('min')) || 1;
                var step = parseFloat($qty.attr('step')) || 1;

                if ($(this).is('.plus')) {
                    if (val + step <= max) {
                        $qty.val(val + step).trigger('change');
                    }
                } else {
                    if (val - step >= min) {
                        $qty.val(val - step).trigger('change');
                    }
                }
            });
        });
    </script>
    <?php
}


/**
 * ============================================================
 * تغییر متون بخش نظرات ووکامرس + نمایش عدد ستاره‌ها
 * با مدیریت کامل هاور، انتخاب و کلاس selected
 * ============================================================

 */

// 1. تغییر عنوان فرم و دکمه ثبت
add_filter('woocommerce_product_review_comment_form_args', 'cro_review_form_args');
function cro_review_form_args($args) {
    $args['title_reply'] = 'تجربه خود را با دیگران به اشتراک بگذارید';
    $args['label_submit'] = 'ثبت دیدگاه و راهنمایی دیگران';
    $args['comment_field'] = str_replace(
        'Your review *',
        'نظر شما * (تجربه، نکات مثبت یا منفی خود را بنویسید)',
        $args['comment_field']
    );
    return $args;
}

// 2. تغییر لیبل فیلد امتیاز
add_filter('comment_form_default_fields', 'change_rating_label');
function change_rating_label($fields) {
    if (is_product() && isset($fields['rating'])) {
        $fields['rating'] = str_replace(
            'Your rating',
            'امتیاز شما * (چقدر از این محصول راضی هستید؟)',
            $fields['rating']
        );
    }
    return $fields;
}

// 3. تغییر سایر متون ثابت
add_filter('gettext', 'change_review_texts_cro', 20, 3);
add_filter('ngettext', 'change_review_texts_cro', 20, 3);
function change_review_texts_cro($translated_text, $text, $domain) {
    if (is_product() && in_array($domain, ['woocommerce', 'default'])) {
        $changes = [
            'Reviews (%s)' => 'نظرات و تجربیات خریداران (%s)',
            'There are no reviews yet.' => 'هنوز نظری ثبت نشده است. شما اولین نفری باشید که تجربه‌ی خود را با دیگران به اشتراک می‌گذارید!',
            'Your review *' => 'نظر شما * (تجربه، نکات مثبت یا منفی خود را بنویسید)',
            'Your rating *' => 'امتیاز شما * (چقدر از این محصول راضی هستید؟)',
            'Submit' => 'ثبت دیدگاه و راهنمایی دیگران',
        ];
        if (isset($changes[$text])) {
            return $changes[$text];
        }
    }
    return $translated_text;
}

// 4. جاوااسکریپت نهایی (تغییر متون + نمایش عدد فقط در هاور)
add_action('wp_footer', 'ultimate_review_script');
function ultimate_review_script() {
    if (!is_product()) return;
    ?>
    <script>
        (function() {
            // تابع برای تغییر متون (با تلاش مجدد تا موفقیت)
            function changeTexts() {
                var ratingLabel = document.querySelector('.comment-form-rating label');
                if (ratingLabel && ratingLabel.innerHTML.indexOf('چقدر از این محصول راضی هستید') === -1) {
                    ratingLabel.innerHTML = 'امتیاز شما * (چقدر از این محصول راضی هستید؟)';
                }
                var commentLabel = document.querySelector('.comment-form-comment label');
                if (commentLabel && commentLabel.innerHTML.indexOf('تجربه، نکات مثبت یا منفی') === -1) {
                    commentLabel.innerHTML = 'نظر شما * (تجربه، نکات مثبت یا منفی خود را بنویسید)';
                }
                var emptyMsg = document.querySelector('.woocommerce-noreviews');
                if (emptyMsg && emptyMsg.innerHTML.indexOf('هنوز نظری ثبت نشده') === -1) {
                    emptyMsg.innerHTML = 'هنوز نظری ثبت نشده است. شما اولین نفری باشید که تجربه‌ی خود را با دیگران به اشتراک می‌گذارید!';
                }
                // چپ‌چین دکمه و کاهش سایز
                var submitWrap = document.querySelector('.form-submit');
                if (submitWrap) submitWrap.style.textAlign = 'left';
                var submitBtn = document.querySelector('.submit');
                if (submitBtn) {
                    submitBtn.style.padding = '0.6rem 1.8rem';
                    submitBtn.style.fontSize = '0.9rem';
                    submitBtn.style.width = 'auto';
                }
            }

            // تابع اصلی برای مدیریت ستاره‌ها
            function initStars() {
                var starsContainer = document.querySelector('.comment-form-rating .stars') ||
                                     document.querySelector('.comment-form-rating .star-rating-select') ||
                                     document.querySelector('.comment-form-rating ul');
                if (!starsContainer) return false;

                // ایجاد المان نمایش عدد (مخفی در ابتدا)
                var ratingDisplay = document.createElement('span');
                ratingDisplay.style.marginRight = '12px';
                ratingDisplay.style.marginLeft = '12px';
                ratingDisplay.style.fontSize = '1rem';
                ratingDisplay.style.fontWeight = '700';
                ratingDisplay.style.color = '#1e293b';
                ratingDisplay.style.minWidth = '3rem';
                ratingDisplay.style.display = 'inline-block';
                ratingDisplay.textContent = ''; // خالی
                starsContainer.parentNode.insertBefore(ratingDisplay, starsContainer.nextSibling);

                // دریافت همه‌ی ستاره‌ها (لینک‌ها یا لیبل‌ها)
                var stars = starsContainer.querySelectorAll('a, label');
                if (stars.length === 0) {
                    var radios = starsContainer.querySelectorAll('input[type="radio"]');
                    if (radios.length > 0) {
                        stars = [];
                        radios.forEach(function(radio) {
                            var label = radio.parentNode.querySelector('label[for="' + radio.id + '"]');
                            if (label) stars.push(label);
                        });
                        if (stars.length === 0) stars = radios;
                    }
                }
                if (stars.length === 0) return false;

                // تابع دریافت مقدار عددی ستاره
                function getStarValue(element) {
                    var val = element.getAttribute('data-value') ||
                              element.getAttribute('data-star') ||
                              element.getAttribute('title');
                    if (val) {
                        var num = parseInt(val);
                        if (!isNaN(num)) return num;
                    }
                    if (element.tagName === 'INPUT' && element.type === 'radio') {
                        return parseInt(element.value) || 1;
                    }
                    var classList = element.className.split(' ');
                    for (var i = 0; i < classList.length; i++) {
                        if (classList[i].indexOf('star-') === 0) {
                            var num = parseInt(classList[i].replace('star-', ''));
                            if (!isNaN(num)) return num;
                        }
                    }
                    var all = starsContainer.querySelectorAll('a, label, input[type="radio"]');
                    return Array.from(all).indexOf(element) + 1;
                }

                // تابع تنظیم کلاس selected برای زرد ماندن ستاره‌ها
                function setSelected(value) {
                    starsContainer.querySelectorAll('.selected').forEach(function(el) {
                        el.classList.remove('selected');
                    });
                    var allItems = starsContainer.querySelectorAll('a, label, input[type="radio"]');
                    allItems.forEach(function(item) {
                        if (getStarValue(item) == value) {
                            if (item.tagName === 'A' || item.tagName === 'LABEL') {
                                item.classList.add('selected');
                                var siblings = item.parentNode.querySelectorAll('a, label');
                                for (var i = 0; i < siblings.length; i++) {
                                    if (siblings[i] === item) break;
                                    siblings[i].classList.add('selected');
                                }
                            } else if (item.tagName === 'INPUT') {
                                item.checked = true;
                                var parent = item.parentNode;
                                if (parent) parent.classList.add('selected');
                            }
                        }
                    });
                }

                // اعمال رویدادها
                stars.forEach(function(star) {
                    var starValue = getStarValue(star);

                    // هاور: عدد را نشان بده
                    star.addEventListener('mouseenter', function() {
                        ratingDisplay.textContent = starValue + ' از ۵';
                    });

                    // خروج از هاور: عدد را پاک کن (حتی اگر انتخاب شده باشد)
                    star.addEventListener('mouseleave', function() {
                        ratingDisplay.textContent = '';
                    });

                    // کلیک: فقط انتخاب را اعمال کن، عددی نمایش نده
                    star.addEventListener('click', function(e) {
                        e.preventDefault();
                        setSelected(starValue);
                        // چک کردن رادیو مربوطه
                        var radio = starsContainer.querySelector('input[type="radio"][value="' + starValue + '"]');
                        if (radio) {
                            radio.checked = true;
                            var event = new Event('change', { bubbles: true });
                            radio.dispatchEvent(event);
                        }
                        // عدد را پاک کن (در صورت نمایش)
                        ratingDisplay.textContent = '';
                    });
                });

                // اگر از قبل ستاره‌ای انتخاب شده بود، کلاس selected را تنظیم کن ولی عددی نشان نده
                var preSelected = starsContainer.querySelector('.selected, input:checked');
                if (preSelected) {
                    var preVal = getStarValue(preSelected);
                    setSelected(preVal);
                }

                return true;
            }

            // اجرای تابع تغییر متون با تأخیر و تکرار
            function run() {
                changeTexts();
                var success = initStars();
                if (!success) {
                    // اگر ستاره‌ها پیدا نشدند، دوباره تلاش کن
                    setTimeout(run, 500);
                }
            }

            // اجرا پس از بارگذاری کامل صفحه
            if (document.readyState === 'complete') {
                setTimeout(run, 300);
            } else {
                window.addEventListener('load', function() {
                    setTimeout(run, 300);
                });
            }

            // همچنین هر ۲ ثانیه یکبار متون را بررسی کن تا مطمئن شویم تغییر کرده‌اند
            setInterval(changeTexts, 2000);
        })();
    </script>
    <?php
}
?>