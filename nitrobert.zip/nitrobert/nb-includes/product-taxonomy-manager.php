<?php
/**
 * Auto-detect taxonomies and add Enable/Disable toggle (SEO Safe)
 * By WP Expert
 */

// 1. اضافه کردن فیلد وضعیت به تمامی تاکسونومی‌های عمومی
add_action('init', 'wpexpert_register_taxonomy_status_fields', 99);
function wpexpert_register_taxonomy_status_fields() {
    $taxonomies = get_taxonomies(array('public' => true));
    foreach ($taxonomies as $tax) {
        add_action("{$tax}_add_form_fields", 'wpexpert_add_term_status_field');
        add_action("{$tax}_edit_form_fields", 'wpexpert_edit_term_status_field');
        add_action("created_{$tax}", 'wpexpert_save_term_status');
        add_action("edited_{$tax}", 'wpexpert_save_term_status');
    }
}

function wpexpert_add_term_status_field() {
    ?>
    <div class="form-field term-status-wrap">
        <label for="term-status">وضعیت نمایش ترم (سئو سیف)</label>
        <select name="_is_disabled" id="term-status">
            <option value="no">فعال (نمایش داده شود)</option>
            <option value="yes">غیرفعال (مخفی شود)</option>
        </select>
        <p>با غیرفعال کردن، این ترم و پست‌ها/محصولات آن از لیست‌ها و آرشیوها مخفی می‌شوند اما لینک مستقیم آن‌ها برای گوگل (وضعیت 200) باز می‌ماند.</p>
    </div>
    <?php
}

function wpexpert_edit_term_status_field($term) {
    $status = get_term_meta($term->term_id, '_is_disabled', true) ?: 'no';
    ?>
    <tr class="form-field term-status-wrap">
        <th scope="row"><label for="term-status">وضعیت نمایش ترم (سئو سیف)</label></th>
        <td>
            <select name="_is_disabled" id="term-status">
                <option value="no" <?php selected($status, 'no'); ?>>فعال (نمایش داده شود)</option>
                <option value="yes" <?php selected($status, 'yes'); ?>>غیرفعال (مخفی شود)</option>
            </select>
            <p class="description">با غیرفعال کردن، این ترم و پست‌ها/محصولات آن از لیست‌ها و آرشیوها مخفی می‌شوند اما لینک مستقیم آن‌ها برای گوگل (وضعیت 200) باز می‌ماند.</p>
        </td>
    </tr>
    <?php
}

function wpexpert_save_term_status($term_id) {
    if (isset($_POST['_is_disabled'])) {
        update_term_meta($term_id, '_is_disabled', sanitize_text_field($_POST['_is_disabled']));
    }
}

// 2. کوئری دیتابیس برای دریافت سریع ترم‌های غیرفعال (با کش Transient برای سرعت بالا)
function wpexpert_get_disabled_terms_grouped() {
    $grouped = get_transient('wpexpert_disabled_terms_grouped');
    if (false === $grouped) {
        global $wpdb;
        // گرفتن مستقیم از دیتابیس برای جلوگیری از لوپ بی‌نهایت و سرعت فوق‌العاده
        $results = $wpdb->get_results("
            SELECT tm.term_id, tt.taxonomy
            FROM {$wpdb->termmeta} tm
            INNER JOIN {$wpdb->term_taxonomy} tt ON tm.term_id = tt.term_id
            WHERE tm.meta_key = '_is_disabled' AND tm.meta_value = 'yes'
        ");
        
        $grouped = array('all_ids' => array(), 'by_tax' => array());
        foreach ($results as $row) {
            $grouped['all_ids'][] = $row->term_id;
            $grouped['by_tax'][$row->taxonomy][] = $row->term_id;
        }
        set_transient('wpexpert_disabled_terms_grouped', $grouped, 12 * HOUR_IN_SECONDS);
    }
    return $grouped;
}

// پاک کردن کش در صورت تغییر وضعیت ترم‌ها
add_action('added_term_meta', 'wpexpert_clear_disabled_terms_transient', 10, 3);
add_action('updated_term_meta', 'wpexpert_clear_disabled_terms_transient', 10, 3);
add_action('deleted_term_meta', 'wpexpert_clear_disabled_terms_transient', 10, 3);
function wpexpert_clear_disabled_terms_transient($mid, $object_id, $meta_key) {
    if ($meta_key === '_is_disabled') {
        delete_transient('wpexpert_disabled_terms_grouped');
    }
}

// 3. مخفی کردن خود "ترم‌ها" از تمام لیست‌ها، منوها، ویجت‌ها و کوئری افزونه‌ها (به جز دسترسی مستقیم URL)
add_filter('get_terms', 'wpexpert_filter_disabled_terms', 10, 4);
function wpexpert_filter_disabled_terms($terms, $taxonomies, $args, $term_query) {
    if (is_admin()) return $terms; // در ادمین همه چیز نمایش داده شود
    
    // اگر کوئری مستقیماً به دنبال یک نامک یا ID خاص است (یعنی کاربر آدرس دسته‌بندی را در مرورگر زده است)، دخالت نمی‌کنیم تا 404 نشود
    if (!empty($args['slug']) || !empty($args['term_taxonomy_id']) || !empty($args['include'])) {
        return $terms;
    }

    $disabled_data = wpexpert_get_disabled_terms_grouped();
    if (empty($disabled_data['all_ids'])) return $terms;

    $filtered_terms = array();
    foreach ($terms as $term) {
        $term_id = is_object($term) ? $term->term_id : (is_numeric($term) ? $term : 0);
        if ($term_id && in_array($term_id, $disabled_data['all_ids'])) {
            continue; // ترم غیرفعال است، ردش کن
        }
        $filtered_terms[] = $term;
    }
    return $filtered_terms;
}

// 4. مخفی کردن محصولات و نوشته‌های متصل به ترم غیرفعال از تمام لوپ‌های سایت
add_action('pre_get_posts', 'wpexpert_hide_posts_of_disabled_terms', 9999);
function wpexpert_hide_posts_of_disabled_terms($query) {
    if (is_admin()) return;

    // مهم برای سئو: اگر کاربر لینک مستقیم محصول را باز کرد، نمایش داده شود تا 404 نگیریم
    if ($query->is_singular()) return;

    // استثنا برای منوهای ناوبری وردپرس
    if ($query->get('post_type') === 'nav_menu_item') return;

    $disabled_data = wpexpert_get_disabled_terms_grouped();
    if (empty($disabled_data['by_tax'])) return;

    $tax_query = $query->get('tax_query') ?: array();
    
    // تمام ترم‌های غیرفعال را به صورت NOT IN به کوئری اضافه می‌کنیم
    foreach ($disabled_data['by_tax'] as $tax => $ids) {
        $tax_query[] = array(
            'taxonomy' => $tax,
            'field'    => 'term_id',
            'terms'    => $ids,
            'operator' => 'NOT IN',
        );
    }
    
    if (!empty($tax_query)) {
        $tax_query['relation'] = 'AND';
        $query->set('tax_query', $tax_query);
    }
}

// 5. اضافه کردن ستون وضعیت به لیست ترم‌ها
add_action('init', 'wpexpert_add_quick_edit_columns_to_taxonomies', 100);
function wpexpert_add_quick_edit_columns_to_taxonomies() {
    $taxonomies = get_taxonomies(array('public' => true));
    foreach ($taxonomies as $tax) {
        // اضافه کردن هدر ستون
        add_filter("manage_edit-{$tax}_columns", 'wpexpert_add_status_column');
        // نمایش محتوای ستون
        add_filter("manage_{$tax}_custom_column", 'wpexpert_populate_status_column', 10, 3);
    }
}

function wpexpert_add_status_column($columns) {
    $columns['term_status'] = 'وضعیت (سئو سیف)';
    return $columns;
}

function wpexpert_populate_status_column($content, $column_name, $term_id) {
    if ($column_name === 'term_status') {
        $status = get_term_meta($term_id, '_is_disabled', true) ?: 'no';
        
        // نمایش گرافیکی وضعیت برای خوانایی سریع
        if ($status === 'yes') {
            $text = '<span style="color: #d63638; font-weight: bold;">غیرفعال 🔴</span>';
        } else {
            $text = '<span style="color: #00a32a; font-weight: bold;">فعال 🟢</span>';
        }
        
        // فیلد مخفی برای استفاده جاوااسکریپت در ویرایش سریع
        $content .= $text . '<div class="hidden term-status-val" id="status_' . $term_id . '">' . esc_attr($status) . '</div>';
    }
    return $content;
}

// 6. اضافه کردن فیلد به فرم ویرایش سریع (Quick Edit)
add_action('quick_edit_custom_box', 'wpexpert_quick_edit_term_status', 10, 3);
function wpexpert_quick_edit_term_status($column_name, $screen, $name) {
    // فقط برای ستونی که خودمان ساختیم اجرا شود
    if ($column_name === 'term_status') {
        ?>
        <fieldset>
            <div class="inline-edit-col">
                <label>
                    <span class="title">وضعیت نمایش</span>
                    <span class="input-text-wrap">
                        <select name="_is_disabled" class="term-status-input">
                            <option value="no">فعال (نمایش داده شود)</option>
                            <option value="yes">غیرفعال (مخفی شود)</option>
                        </select>
                    </span>
                </label>
            </div>
        </fieldset>
        <?php
    }
}

// 7. جاوااسکریپت برای مقداردهی خودکار فیلد در ویرایش سریع
add_action('admin_footer', 'wpexpert_quick_edit_javascript');
function wpexpert_quick_edit_javascript() {
    $current_screen = get_current_screen();
    
    // فقط در صفحات لیست دسته‌بندی‌ها اجرا شود
    if ( ! $current_screen || empty($current_screen->taxonomy) ) {
        return;
    }
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            // اطمینان از وجود اسکریپت ویرایش سریع وردپرس در صفحه
            if (typeof inlineEditTax === 'undefined') {
                return;
            }
            
            // کپی کردن تابع اصلی وردپرس
            var $wp_inline_edit = inlineEditTax.edit;
            
            // بازنویسی تابع برای تزریق مقادیر ما
            inlineEditTax.edit = function(id) {
                // ابتدا تابع اصلی وردپرس اجرا شود
                $wp_inline_edit.apply(this, arguments);

                var term_id = 0;
                if (typeof(id) == 'object') {
                    term_id = parseInt(this.getId(id));
                }

                if (term_id > 0) {
                    // پیدا کردن ردیف در حال ویرایش
                    var $edit_row = $('#edit-' + term_id);
                    // خواندن مقدار ذخیره شده از ستون جدول
                    var status_val = $('#status_' + term_id).text();
                    
                    // تنظیم مقدار در فیلد کشویی فرم ویرایش سریع
                    $edit_row.find('.term-status-input').val(status_val);
                }
            };
        });
    </script>
    <?php
}


// 8. اضافه کردن اکشن‌های دسته‌جمعی (Bulk Actions) برای همه تاکسونومی‌ها
add_action('admin_init', 'wpexpert_register_bulk_actions_for_taxonomies');
function wpexpert_register_bulk_actions_for_taxonomies() {
    $taxonomies = get_taxonomies(array('public' => true));
    foreach ($taxonomies as $tax) {
        // اضافه کردن گزینه‌ها به منوی کشویی کارهای دسته‌جمعی
        add_filter("bulk_actions-edit-{$tax}", 'wpexpert_custom_bulk_actions');
        // پردازش عملیات بعد از کلیک روی دکمه "اجرا"
        add_filter("handle_bulk_actions-edit-{$tax}", 'wpexpert_handle_custom_bulk_actions', 10, 3);
    }
}

// تعریف نام گزینه‌ها در منوی کشویی
function wpexpert_custom_bulk_actions($bulk_actions) {
    $bulk_actions['mark_seo_enabled'] = 'فعال کردن (نمایش)';
    $bulk_actions['mark_seo_disabled'] = 'غیرفعال کردن (سئو سیف)';
    return $bulk_actions;
}

// پردازش تغییرات دیتابیس برای آیتم‌های انتخاب شده
function wpexpert_handle_custom_bulk_actions($redirect_to, $doaction, $term_ids) {
    // اگر اکشن ما نبود، دخالت نکن
    if ($doaction !== 'mark_seo_disabled' && $doaction !== 'mark_seo_enabled') {
        return $redirect_to;
    }

    $status = ($doaction === 'mark_seo_disabled') ? 'yes' : 'no';
    $count = 0;

    // آپدیت کردن متای تمام ترم‌های تیک‌خورده
    foreach ($term_ids as $term_id) {
        update_term_meta($term_id, '_is_disabled', $status);
        $count++;
    }

    // پاک کردن کش ترانزینت (برای اعمال فوری در فرانت‌اند)
    delete_transient('wpexpert_disabled_terms_grouped');

    // اضافه کردن پارامتر به URL برای نمایش پیام موفقیت‌آمیز
    $redirect_to = add_query_arg(array(
        'seo_status_updated' => $count,
        'new_status' => $status
    ), $redirect_to);

    return $redirect_to;
}

// 9. نمایش پیام موفقیت‌آمیز در بالای صفحه بعد از ویرایش دسته‌جمعی
add_action('admin_notices', 'wpexpert_bulk_action_admin_notice');
function wpexpert_bulk_action_admin_notice() {
    if (!empty($_REQUEST['seo_status_updated'])) {
        $count = intval($_REQUEST['seo_status_updated']);
        $status = sanitize_text_field($_REQUEST['new_status']);
        
        if ($status === 'yes') {
            $message = sprintf('وضعیت %d مورد با موفقیت به <strong>غیرفعال 🔴</strong> تغییر یافت.', $count);
        } else {
            $message = sprintf('وضعیت %d مورد با موفقیت به <strong>فعال 🟢</strong> تغییر یافت.', $count);
        }
        
        echo '<div id="message" class="updated notice is-dismissible"><p>' . $message . '</p></div>';
    }
}

// 10. هماهنگ‌سازی کش شورت‌کد اختصاصی (Pro Tax Grid) با تغییر وضعیت ترم‌ها
add_action('added_term_meta', 'wpexpert_clear_pro_tax_grid_cache_on_meta_update', 10, 4);
add_action('updated_term_meta', 'wpexpert_clear_pro_tax_grid_cache_on_meta_update', 10, 4);
add_action('deleted_term_meta', 'wpexpert_clear_pro_tax_grid_cache_on_meta_update', 10, 4);

function wpexpert_clear_pro_tax_grid_cache_on_meta_update($meta_id, $object_id, $meta_key, $meta_value) {
    // فقط وقتی تنظیمات "وضعیت نمایش ترم" تغییر کرد وارد عمل شو
    if ($meta_key === '_is_disabled') {
        $term = get_term($object_id);
        
        // بررسی می‌کنیم که تابع پاک‌کننده کش شورت‌کد شما در قالب وجود داشته باشد
        if ($term && !is_wp_error($term) && function_exists('pro_tax_carousel_clear_transient')) {
            // فراخوانی تابع پاک‌کننده کش فایل pro-tax-grid.php
            pro_tax_carousel_clear_transient($term->term_id, $term->term_taxonomy_id, $term->taxonomy);
        }
    }
}

// افزودن ستون "قطعات مرتبط" فقط به تاکسونومی "برند قطعه"
add_filter( 'manage_edit-part_brand_columns', 'pro_tax_add_brand_parts_column' );
function pro_tax_add_brand_parts_column( $columns ) {
    $columns['brand_parts_col'] = 'قطعات مرتبط (تولیدات)';
    return $columns;
}

add_filter( 'manage_part_brand_custom_column', 'pro_tax_populate_brand_parts_column', 10, 3 );
function pro_tax_populate_brand_parts_column( $content, $column_name, $term_id ) {
    if ( 'brand_parts_col' === $column_name ) {
        $selected_types = get_term_meta( $term_id, '_brand_part_types', true );
        
        if ( !empty($selected_types) && is_array($selected_types) ) {
            $type_names = array();
            foreach ( $selected_types as $type_id ) {
                $type_term = get_term( $type_id, 'part_type' );
                if ( $type_term && !is_wp_error($type_term) ) {
                    $type_names[] = $type_term->name;
                }
            }
            if ( !empty($type_names) ) {
                // نمایش نام قطعات با رنگ آبی وردپرس
                $content = '<span style="color:#2271b1; font-weight:600; line-height:1.5;">' . esc_html( implode( '، ', $type_names ) ) . '</span>';
            } else {
                $content = '<span style="color:#a7aaad;">—</span>';
            }
        } else {
            $content = '<span style="color:#a7aaad;">—</span>';
        }
    }
    return $content;
}




