<?php
function complete_dynamic_schema() {
    if (!is_product()) {
        return;
    }

    global $product;

    if (!$product) {
        return;
    }

    // 🚀 اطلاعات سایت
    $site_name = get_bloginfo('name');
    $site_url = home_url();
    $logo_url = wp_get_attachment_image_url(get_theme_mod('custom_logo'), 'full') ?: "$site_url/wp-content/uploads/default-logo.png";

    // 🚀 اطلاعات کسب‌وکار محلی
    $business_name = "عطاری روناس";
    $business_address = "استان فارس، شیراز، پارامونت ابتدای خیابان لطفعلی خان زند، مغازه دوم – سمت چپ";
    $business_city = "شیراز";
    $business_postal_code = "7153735843";
    $business_country = "IR"; // اصلاح شده
    $business_phone = "+989190522472";
    $business_email = "attarironas@gmail.com";
    $business_opening_hours = ["Sa-Th 08:00-20:00"];
    $business_price_range = "IRR 50000-5000000";

    // 🚀 اطلاعات محصول
    $product_name = $product->get_name();
    $product_url = get_permalink($product->get_id());
    $product_image = wp_get_attachment_url($product->get_image_id());
    $product_price = $product->get_price() * 10; // تبدیل تومان به ریال
    $currency_code = "IRR";
    $availability = $product->is_in_stock() ? "https://schema.org/InStock" : "https://schema.org/OutOfStock";
    $sku = $product->get_sku();
    $product_description = wp_strip_all_tags($product->get_description()) ?: "این محصول در عطاری روناس عرضه می‌شود.";

    // 🚀 دریافت امتیازات و نظرات
    $average_rating = $product->get_average_rating();
    $review_count = $product->get_review_count();
    $reviews = get_comments(['post_id' => $product->get_id(), 'status' => 'approve']);
    $reviews_schema = [];

    foreach ($reviews as $review) {
        $rating = get_comment_meta($review->comment_ID, 'rating', true);
        if ($rating) {
            $reviews_schema[] = [
                "@type" => "Review",
                "author" => $review->comment_author,
                "reviewBody" => $review->comment_content,
                "reviewRating" => [
                    "@type" => "Rating",
                    "ratingValue" => $rating
                ]
            ];
        }
    }

    // 🚀 اسکیما محصول
    $product_schema = [
        "@context" => "https://schema.org/",
        "@type" => "Product",
        "name" => $product_name,
        "image" => $product_image,
        "description" => $product_description,
        "sku" => $sku,
        "brand" => ["@type" => "Brand", "name" => $site_name],
        "offers" => [
            "@type" => "Offer",
            "url" => $product_url,
            "priceCurrency" => $currency_code,
            "price" => $product_price,
            "availability" => $availability,
            "itemCondition" => "https://schema.org/NewCondition",
            "priceValidUntil" => "2026-12-31", // ✅ اضافه شد
            "shippingDetails" => [ // ✅ اطلاعات ارسال
                "@type" => "OfferShippingDetails",
                "shippingRate" => [
                    "@type" => "MonetaryAmount",
                    "currency" => $currency_code,
                    "value" => "50000"
                ],
                "shippingDestination" => [
                    "@type" => "DefinedRegion",
                    "addressCountry" => "IR"
                ]
            ],
            "hasMerchantReturnPolicy" => [ // ✅ سیاست بازگشت کالا
                "@type" => "MerchantReturnPolicy",
                "applicableCountry" => "IR",
                "returnPolicyCategory" => "https://schema.org/MerchantReturnFiniteReturnWindow",
                "returnPolicyDays" => 7,
                "returnShippingFeesAmount" => [
                    "@type" => "MonetaryAmount",
                    "currency" => $currency_code,
                    "value" => "0"
                ]
            ]
        ]
    ];

    // **اضافه کردن aggregateRating فقط در صورتی که امتیاز واقعی وجود داشته باشد**
    if ($review_count > 0 && $average_rating > 0) {
        $product_schema["aggregateRating"] = [
            "@type" => "AggregateRating",
            "ratingValue" => $average_rating,
            "reviewCount" => $review_count
        ];
    }

    // **اضافه کردن نظرات فقط در صورتی که حداقل یک نظر واقعی وجود داشته باشد**
    if (!empty($reviews_schema)) {
        $product_schema["review"] = $reviews_schema;
    }

    // 🚀 نمایش اسکیما در هد سایت
    echo '<script type="application/ld+json">' . json_encode($product_schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
}

add_action('wp_head', 'complete_dynamic_schema');
