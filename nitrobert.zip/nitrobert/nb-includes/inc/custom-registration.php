<?php
add_shortcode('custom_login_register_form', 'custom_login_register_form_shortcode');

function custom_login_register_form_shortcode() {
    $sms_enabled = get_option('sms_enabled');
    
    ob_start();
    ?>
    <h2><?php echo $sms_enabled ? 'ورود یا ثبت‌نام با پیامک' : 'ورود یا ثبت‌نام'; ?></h2>
    <form method="post" action="">
        <p>
            <label for="reg_phone">شماره تماس<span class="required">*</span></label>
            <input type="text" name="reg_phone" id="reg_phone" required />
        </p>

        <?php if ($sms_enabled): ?>
            <div id="otp-section">
                <p>
                    <label for="otp_code">کد تأیید</label>
                    <input type="text" name="otp_code" id="otp_code" />
                </p>
                <p>
                    <button type="button" id="send_otp">ارسال کد تأیید</button>
                </p>
            </div>
        <?php else: ?>
            <div id="password-section">
                <p>
                    <label for="reg_password">رمز عبور</label>
                    <input type="password" name="reg_password" id="reg_password" required />
                </p>
            </div>
        <?php endif; ?>

        <p>
            <input type="submit" name="dynamic_submit" value="ثبت‌نام / ورود" />
        </p>
    </form>

    <?php if ($sms_enabled): ?>
        <script>
            document.getElementById('send_otp').addEventListener('click', function() {
                var phone = document.getElementById('reg_phone').value;
                if (phone) {
                    fetch('<?php echo admin_url("admin-ajax.php?action=send_otp&phone="); ?>' + phone)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                alert('کد تأیید ارسال شد!');
                            } else {
                                alert('خطا در ارسال کد تأیید.');
                            }
                        });
                } else {
                    alert('لطفاً شماره تماس را وارد کنید.');
                }
            });
        </script>
    <?php endif; ?>
    <?php
    return ob_get_clean();
}
