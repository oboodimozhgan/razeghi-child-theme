<?php
function send_sms($to, $message) {
    $sms_enabled = get_option('sms_enabled');
    $provider = get_option('sms_provider');
    $api_key = get_option('sms_api_key');
    $sender_number = get_option('sms_sender_number');

    if (!$sms_enabled || empty($api_key) || empty($sender_number)) {
        return false; // پیامک غیرفعال است یا اطلاعات ناقص است
    }

    $url = ($provider === 'farazsms') ? "https://api.sms.ir/v1/send" : "https://rest.ippanel.com/v1/messages";

    $args = array(
        'headers' => array(
            'Authorization' => "AccessKey $api_key",
            'Content-Type' => 'application/json',
        ),
        'body' => json_encode(array(
            'originator' => $sender_number,
            'recipients' => array($to),
            'message' => $message,
        )),
        'method' => 'POST',
    );

    $response = wp_remote_post($url, $args);
    return wp_remote_retrieve_body($response);
}
