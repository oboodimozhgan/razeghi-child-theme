<?php
// افزودن منوی تنظیمات پیامک در پیشخوان
add_action('admin_menu', 'sms_settings_menu');

function sms_settings_menu() {
    add_menu_page(
        'تنظیمات پیامک',
        'تنظیمات پیامک',
        'manage_options',
        'sms-settings',
        'sms_settings_page',
        'dashicons-email-alt',
        25
    );
}

// صفحه تنظیمات پیامک
function sms_settings_page() {
    ?>
    <div class="wrap">
        <h1>تنظیمات پیامک</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('sms_settings_group');
            do_settings_sections('sms-settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// ثبت تنظیمات پیامک
add_action('admin_init', 'register_sms_settings');

function register_sms_settings() {
    register_setting('sms_settings_group', 'sms_enabled');
    register_setting('sms_settings_group', 'sms_provider'); // انتخاب فراز اس ام اس یا IP Panel
    register_setting('sms_settings_group', 'sms_api_key');
    register_setting('sms_settings_group', 'sms_sender_number');

    add_settings_section('sms_settings_section', 'تنظیمات ارسال پیامک', null, 'sms-settings');

    add_settings_field('sms_enabled', 'فعال‌سازی پیامک', 'sms_enabled_callback', 'sms-settings', 'sms_settings_section');
    add_settings_field('sms_provider', 'سرویس‌دهنده پیامک', 'sms_provider_callback', 'sms-settings', 'sms_settings_section');
    add_settings_field('sms_api_key', 'کلید API', 'sms_api_key_callback', 'sms-settings', 'sms_settings_section');
    add_settings_field('sms_sender_number', 'شماره ارسال‌کننده', 'sms_sender_number_callback', 'sms-settings', 'sms_settings_section');
}

function sms_enabled_callback() {
    $sms_enabled = get_option('sms_enabled');
    echo '<input type="checkbox" name="sms_enabled" value="1"' . checked(1, $sms_enabled, false) . ' /> فعال';
}

function sms_provider_callback() {
    $provider = get_option('sms_provider', 'farazsms');
    ?>
    <select name="sms_provider">
        <option value="farazsms" <?php selected($provider, 'farazsms'); ?>>فراز اس‌ام‌اس</option>
        <option value="ippanel" <?php selected($provider, 'ippanel'); ?>>IP Panel</option>
    </select>
    <?php
}

function sms_api_key_callback() {
    $api_key = get_option('sms_api_key');
    echo '<input type="text" name="sms_api_key" value="' . esc_attr($api_key) . '" />';
}

function sms_sender_number_callback() {
    $sender_number = get_option('sms_sender_number');
    echo '<input type="text" name="sms_sender_number" value="' . esc_attr($sender_number) . '" />';
}
