<?php
// تنظیمات پیامک و ارسال پیامک
add_action('admin_menu', 'sms_settings_menu');

function sms_settings_menu() {
    add_menu_page(
        'تنظیمات پیامک',
        'تنظیمات پیامک',
        'manage_options',
        'sms-settings',
        'sms_settings_page',
        'dashicons-email-alt',
        25
    );
}

function sms_settings_page() {
    ?>
    <div class="wrap">
        <h1>تنظیمات پیامک</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('sms_settings_group');
            do_settings_sections('sms-settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

add_action('admin_init', 'register_sms_settings');

function register_sms_settings() {
    register_setting('sms_settings_group', 'sms_enabled');
    register_setting('sms_settings_group', 'farazsms_api_key');
    register_setting('sms_settings_group', 'farazsms_sender_number');

    add_settings_section('sms_settings_section', 'تنظیمات ارسال پیامک', null, 'sms-settings');

    add_settings_field('sms_enabled', 'فعال‌سازی پیامک', 'sms_enabled_callback', 'sms-settings', 'sms_settings_section');
    add_settings_field('farazsms_api_key', 'کلید API فراز اس‌ام‌اس', 'farazsms_api_key_callback', 'sms-settings', 'sms_settings_section');
    add_settings_field('farazsms_sender_number', 'شماره ارسال‌کننده', 'farazsms_sender_number_callback', 'sms-settings', 'sms_settings_section');
}

function sms_enabled_callback() {
    $sms_enabled = get_option('sms_enabled');
    echo '<input type="checkbox" name="sms_enabled" value="1"' . checked(1, $sms_enabled, false) . ' /> فعال';
}

function farazsms_api_key_callback() {
    $api_key = get_option('farazsms_api_key');
    echo '<input type="text" name="farazsms_api_key" value="' . esc_attr($api_key) . '" />';
}

function farazsms_sender_number_callback() {
    $sender_number = get_option('farazsms_sender_number');
    echo '<input type="text" name="farazsms_sender_number" value="' . esc_attr($sender_number) . '" />';
}

// ارسال پیامک
function send_sms_via_farazsms($to, $message) {
    $sms_enabled = get_option('sms_enabled');
    $api_key = get_option('farazsms_api_key');
    $sender_number = get_option('farazsms_sender_number');

    if (!$sms_enabled || empty($api_key) || empty($sender_number)) {
        return false; // پیامک غیرفعال است یا اطلاعات ناقص است
    }

    $url = "https://rest.ippanel.com/v1/messages";
    $args = array(
        'headers' => array(
            'Authorization' => "AccessKey $api_key",
            'Content-Type' => 'application/json',
        ),
        'body' => json_encode(array(
            'originator' => $sender_number,
            'recipients' => array($to),
            'message' => $message,
        )),
        'method' => 'POST',
    );

    $response = wp_remote_post($url, $args);
    return wp_remote_retrieve_body($response);
}
