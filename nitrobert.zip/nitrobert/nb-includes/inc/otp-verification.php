<?php
// ارسال کد OTP
add_action('wp_ajax_send_otp', 'send_otp');
add_action('wp_ajax_nopriv_send_otp', 'send_otp');

function send_otp() {
    $phone = sanitize_text_field($_GET['phone']);
    $otp = rand(1000, 9999);

    // ارسال کد OTP از طریق پنل پیامک
    $response = send_sms($phone, "کد تأیید شما: $otp");

    if ($response) {
        wp_send_json_success();
    } else {
        wp_send_json_error();
    }

    wp_die();
}

// بررسی و تأیید OTP
function validate_otp($user_id, $input_otp) {
    $stored_otp = get_user_meta($user_id, 'otp_code', true);
    if ($stored_otp && $stored_otp === $input_otp) {
        return true;
    }
    return false;
}
