<?php
// بارگذاری تنظیمات پیامک
require_once get_stylesheet_directory() . '/nb-includes/inc/sms-settings.php';

// بارگذاری مدیریت ارسال پیامک
require_once get_stylesheet_directory() . '/nb-includes/inc/sms-handler.php';

// بارگذاری فرم‌های ثبت‌نام و ورود سفارشی
require_once get_stylesheet_directory() . '/nb-includes/inc/custom-registration.php';

// بارگذاری مدیریت OTP
require_once get_stylesheet_directory() . '/nb-includes/inc/otp-verification.php';
