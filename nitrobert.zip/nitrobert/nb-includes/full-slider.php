<?php
/**
 * اسلایدر سراسری با چرخه خودکار و درگ‌اند‌دراپ
 * نسخه نهایی با اولویت، مدت نمایش چرخه‌ای و شمارش کلیک
 */

// ============================================
// بخش 1: منو و بارگذاری Assets
// ============================================

add_action('admin_menu', 'global_slider_menu');
function global_slider_menu() {
    add_menu_page(
        'تنظیمات اسلایدر اصلی',
        'اسلایدر اصلی',
        'manage_options',
        'global-slider-settings',
        'global_slider_page_html',
        'dashicons-images-alt2',
        20
    );
}

add_action('admin_enqueue_scripts', 'global_slider_enqueue_assets');
function global_slider_enqueue_assets($hook) {
    if ($hook !== 'toplevel_page_global-slider-settings') {
        return;
    }
    wp_enqueue_media();
    wp_enqueue_script('jquery-ui-sortable');
    wp_add_inline_style('wp-admin', '
        .slider-field-row.ui-sortable-helper {
            opacity: 0.6;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
        }
        .slider-field-row.ui-sortable-placeholder {
            border: 2px dashed #b4b9be;
            background: #f1f1f1;
            visibility: visible !important;
            height: 120px;
            margin-bottom: 15px;
        }
        .slider-type label {
            margin-left: 15px;
            font-weight: normal;
        }
        .slider-index-badge {
            display: inline-block;
            background: #f0f0f1;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 12px;
            margin-left: 10px;
            color: #50575e;
        }
        .slider-status-badge {
            display: inline-block;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
            margin-left: 10px;
            color: #fff;
        }
        .slider-status-badge.active {
            background: #00a32a;
        }
        .slider-status-badge.inactive {
            background: #d63638;
        }
        .slider-info-box {
            margin-top: 20px;
            padding: 15px;
            background: #f0f6fc;
            border: 1px solid #c3d9ed;
            border-radius: 4px;
        }
        .slider-info-box .badge-example {
            display: inline-block;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
            color: #fff;
        }
        .slider-info-box .badge-example.green {
            background: #00a32a;
        }
        .slider-info-box .badge-example.red {
            background: #d63638;
        }
        .slider-current-week {
            margin: 15px 0;
            padding: 10px;
            background: #e8f0fe;
            border-right: 4px solid #1e73be;
            border-radius: 4px;
            font-weight: 600;
        }
        .slider-clicks {
            display: inline-block;
            margin-left: 15px;
            font-size: 13px;
            background: #f0f0f1;
            padding: 2px 10px;
            border-radius: 12px;
            color: #50575e;
        }
        .slider-priority, .slider-duration {
            display: inline-block;
            margin: 0 10px 0 0;
        }
        .slider-priority input, .slider-duration input {
            width: 60px;
        }
    ');
}

// ============================================
// بخش 2: توابع کمکی محاسبه وضعیت اسلایدها (با در نظر گرفتن مدت)
// ============================================

function calculate_slider_statuses($items, $current_week) {
    $statuses = [];
    $cycle_items = [];

    // جمع‌آوری اسلایدهای چرخه‌ای با مدت آنها
    foreach ($items as $index => $item) {
        if (isset($item['type']) && $item['type'] === 'cycle') {
            $duration = isset($item['duration']) ? max(1, intval($item['duration'])) : 1;
            $cycle_items[] = [
                'index'    => $index,
                'duration' => $duration,
            ];
        }
    }

    // تعیین اسلاید فعال در بین چرخه‌ای‌ها بر اساس مجموع مدت‌ها
    $selected_cycle_index = -1;
    if (!empty($cycle_items)) {
        $total_duration = array_sum(array_column($cycle_items, 'duration'));
        // فرض: هفته ۱ شروع چرخه است
        $offset = ($current_week - 1) % $total_duration;
        $accum = 0;
        foreach ($cycle_items as $cycle) {
            $accum += $cycle['duration'];
            if ($offset < $accum) {
                $selected_cycle_index = $cycle['index'];
                break;
            }
        }
        // اگر به هر دلیل پیدا نشد، اولین را انتخاب کن
        if ($selected_cycle_index === -1 && !empty($cycle_items)) {
            $selected_cycle_index = $cycle_items[0]['index'];
        }
    }

    // تعیین وضعیت هر اسلاید
    foreach ($items as $index => $item) {
        $type = isset($item['type']) ? $item['type'] : 'always';
        if ($type === 'always') {
            $statuses[$index] = 'active';
        } else {
            $statuses[$index] = ($index === $selected_cycle_index) ? 'active' : 'inactive';
        }
    }

    return $statuses;
}

// ============================================
// بخش 3: صفحه تنظیمات (با فیلدهای جدید)
// ============================================

function global_slider_page_html() {
    if (!current_user_can('manage_options')) {
        return;
    }

    // ذخیره اطلاعات
    if (isset($_POST['submit_global_slider']) && wp_verify_nonce($_POST['global_slider_nonce'], 'save_global_slider')) {
        $items = [];
        $images = isset($_POST['slider_images']) ? array_map('intval', $_POST['slider_images']) : [];
        $links  = isset($_POST['slider_links']) ? array_map('esc_url_raw', $_POST['slider_links']) : [];
        $types = isset($_POST['slider_type']) ? $_POST['slider_type'] : [];
        $priorities = isset($_POST['slider_priority']) ? array_map('intval', $_POST['slider_priority']) : [];
        $durations = isset($_POST['slider_duration']) ? array_map('intval', $_POST['slider_duration']) : [];

        foreach ($images as $index => $image_id) {
            if (empty($image_id)) continue;
            $items[] = [
                'image'    => $image_id,
                'link'     => isset($links[$index]) ? $links[$index] : '',
                'type'     => isset($types[$index]) ? sanitize_text_field($types[$index]) : 'always',
                'priority' => isset($priorities[$index]) ? max(0, intval($priorities[$index])) : 0,
                'duration' => isset($durations[$index]) ? max(1, intval($durations[$index])) : 1,
            ];
        }

        update_option('global_slider_items', $items);
        echo '<div class="notice notice-success is-dismissible"><p>تنظیمات اسلایدر با موفقیت ذخیره شد.</p></div>';
    }

    $items = get_option('global_slider_items', []);
    $current_week = (int) date('W');
    $statuses = calculate_slider_statuses($items, $current_week);

    // دریافت آمار کلیک‌ها
    $clicks_data = get_option('global_slider_clicks', []);
    ?>
    <div class="wrap">
        <h1>تنظیمات اسلایدر اصلی سایت</h1>
        
        <!-- نمایش هفته جاری -->
        <div class="slider-current-week">
            📅 هفته جاری: <strong>هفته <?php echo $current_week; ?></strong> از سال میلادی
            <span style="font-weight:normal; margin-right:15px; font-size:13px; color:#555;">
                (چرخه از همین هفته شروع می‌شود)
            </span>
        </div>

        <form method="POST" action="">
            <?php wp_nonce_field('save_global_slider', 'global_slider_nonce'); ?>
            
            <div id="slider-repeater" style="margin-top:20px;">
                <div class="slider-field-wrapper">
                    <?php if (!empty($items)): ?>
                        <?php foreach ($items as $index => $item): 
                            $status = isset($statuses[$index]) ? $statuses[$index] : 'inactive';
                            $status_label = ($status === 'active') ? 'فعال' : 'غیرفعال';
                            $status_class = ($status === 'active') ? 'active' : 'inactive';
                            $priority = isset($item['priority']) ? intval($item['priority']) : 0;
                            $duration = isset($item['duration']) ? intval($item['duration']) : 1;
                            $click_count = isset($clicks_data[$item['image']]) ? intval($clicks_data[$item['image']]) : 0;
                        ?>
                            <div class="slider-field-row" data-index="<?php echo $index; ?>" data-type="<?php echo esc_attr($item['type']); ?>">
                                <div class="slider-image-wrapper">
                                    <div class="slider-image-preview">
                                        <?php echo wp_get_attachment_image($item['image'], 'medium'); ?>
                                    </div>
                                    <input type="hidden" class="slider-image-id" name="slider_images[]" value="<?php echo esc_attr($item['image']); ?>">
                                    <button type="button" class="button slider-upload-btn">انتخاب عکس</button>
                                    <button type="button" class="button slider-remove-btn">حذف</button>
                                </div>
                                <div class="slider-link-wrapper">
                                    <label>لینک (اختیاری):</label>
                                    <input type="url" class="regular-text slider-link-input" name="slider_links[]" value="<?php echo esc_url($item['link']); ?>" placeholder="https://example.com">
                                </div>
                                <div class="slider-type">
                                    <label>نوع نمایش:</label><br>
                                    <label>
                                        <input type="radio" name="slider_type[<?php echo $index; ?>]" value="always" <?php checked($item['type'], 'always'); ?>> 
                                        همیشه نمایش داده شود
                                    </label>
                                    <label>
                                        <input type="radio" name="slider_type[<?php echo $index; ?>]" value="cycle" <?php checked($item['type'], 'cycle'); ?>> 
                                        چرخه‌ای (بر اساس ترتیب و شماره هفته)
                                    </label>
                                    <span class="slider-index-badge">شماره قرارگیری: <?php echo $index + 1; ?></span>
                                    <span class="slider-status-badge <?php echo $status_class; ?>"><?php echo $status_label; ?></span>
                                </div>
                                <div class="slider-meta" style="margin-top:10px; border-top:1px solid #eee; padding-top:10px;">
                                    <span class="slider-priority">
                                        <label>اولویت نمایش:</label>
                                        <input type="number" name="slider_priority[]" value="<?php echo $priority; ?>" min="0" step="1">
                                    </span>
                                    <span class="slider-duration">
                                        <label>مدت (هفته):</label>
                                        <input type="number" name="slider_duration[]" value="<?php echo $duration; ?>" min="1" step="1">
                                    </span>
                                    <span class="slider-clicks">
                                        👆 کلیک: <?php echo number_format($click_count); ?>
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="slider-field-row" data-index="0" data-type="always">
                            <div class="slider-image-wrapper">
                                <div class="slider-image-preview">
                                    <p>هیچ عکسی انتخاب نشده است</p>
                                </div>
                                <input type="hidden" class="slider-image-id" name="slider_images[]" value="">
                                <button type="button" class="button slider-upload-btn">انتخاب عکس</button>
                                <button type="button" class="button slider-remove-btn">حذف</button>
                            </div>
                            <div class="slider-link-wrapper">
                                <label>لینک (اختیاری):</label>
                                <input type="url" class="regular-text slider-link-input" name="slider_links[]" value="" placeholder="https://example.com">
                            </div>
                            <div class="slider-type">
                                <label>نوع نمایش:</label><br>
                                <label>
                                    <input type="radio" name="slider_type[0]" value="always" checked> 
                                    همیشه نمایش داده شود
                                </label>
                                <label>
                                    <input type="radio" name="slider_type[0]" value="cycle"> 
                                    چرخه‌ای (بر اساس ترتیب و شماره هفته)
                                </label>
                                <span class="slider-index-badge">شماره قرارگیری: ۱</span>
                                <span class="slider-status-badge active">فعال</span>
                            </div>
                            <div class="slider-meta" style="margin-top:10px; border-top:1px solid #eee; padding-top:10px;">
                                <span class="slider-priority">
                                    <label>اولویت نمایش:</label>
                                    <input type="number" name="slider_priority[]" value="0" min="0" step="1">
                                </span>
                                <span class="slider-duration">
                                    <label>مدت (هفته):</label>
                                    <input type="number" name="slider_duration[]" value="1" min="1" step="1">
                                </span>
                                <span class="slider-clicks">
                                    👆 کلیک: ۰
                                </span>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <button type="button" class="button button-secondary slider-add-row" style="margin-top:10px;">افزودن اسلاید جدید</button>
            </div>

            <p class="submit">
                <input type="submit" name="submit_global_slider" id="submit" class="button button-primary" value="ذخیره تغییرات">
            </p>
        </form>

        <div class="slider-info-box">
            <h3>📋 راهنمای استفاده</h3>
            <p><strong>شورت‌کد:</strong> <code>[full_slider speed="4000"]</code></p>
            <p><strong>وضعیت اسلایدها:</strong></p>
            <p>
                <span class="badge-example green">فعال</span> = اسلاید در هفته جاری نمایش داده می‌شود &nbsp;|&nbsp;
                <span class="badge-example red">غیرفعال</span> = اسلاید در هفته جاری نمایش داده نمی‌شود
            </p>
            <p><strong>نکات جدید:</strong></p>
            <ul>
                <li><strong>اولویت نمایش:</strong> اسلایدها در خروجی بر اساس اولویت (عدد کوچک‌تر = اولویت بیشتر) مرتب می‌شوند.</li>
                <li><strong>مدت نمایش (چرخه‌ای):</strong> برای اسلایدهای چرخه‌ای، تعداد هفته‌هایی که هر اسلاید نشان داده می‌شود را مشخص کنید. مجموع مدت‌ها چرخه را می‌سازد.</li>
                <li><strong>شمارش کلیک:</strong> هر بار که کاربر روی لینک اسلاید کلیک کند، تعداد کلیک افزایش می‌یابد و در همین صفحه نمایش داده می‌شود.</li>
                <li>ترتیب قرارگیری اسلایدها با <strong>درگ‌اند‌دراپ</strong> قابل تغییر است و بر شماره‌ها و نام فیلدها تأثیر می‌گذارد.</li>
            </ul>
        </div>
    </div>

    <style>
        #slider-repeater { direction: rtl; max-width: 900px; }
        .slider-field-row {
            background: #fff;
            border: 1px solid #ccd0d4;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 4px;
            box-shadow: 0 1px 1px rgba(0,0,0,.04);
            cursor: move;
            transition: background 0.2s;
        }
        .slider-field-row:hover {
            background: #fafafa;
        }
        .slider-image-preview {
            display: inline-block;
            margin: 10px 0;
            max-width: 200px;
            min-height: 100px;
            border: 1px dashed #b4b9be;
            padding: 5px;
            background: #f9f9f9;
        }
        .slider-image-preview img {
            max-width: 100%;
            height: auto;
            display: block;
        }
        .slider-image-preview p {
            text-align: center;
            color: #999;
            padding: 30px 0;
            margin: 0;
        }
        .slider-link-wrapper {
            margin-top: 10px;
            border-top: 1px solid #eee;
            padding-top: 10px;
        }
        .slider-link-wrapper label,
        .slider-type label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
        }
        .slider-link-wrapper input {
            width: 100%;
        }
        .slider-type {
            margin-top: 10px;
            border-top: 1px solid #eee;
            padding-top: 10px;
        }
        .slider-remove-btn {
            color: #a00 !important;
            border-color: #a00 !important;
        }
        .slider-remove-btn:hover {
            background: #a00 !important;
            color: #fff !important;
        }
        .slider-info-box {
            margin-top: 20px;
            padding: 15px;
            background: #f0f6fc;
            border: 1px solid #c3d9ed;
            border-radius: 4px;
        }
        .slider-info-box ul {
            margin: 10px 0 0 20px;
            list-style: disc;
        }
        .slider-info-box ul li {
            margin-bottom: 5px;
        }
        .badge-example {
            display: inline-block;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
            color: #fff;
        }
        .badge-example.green {
            background: #00a32a;
        }
        .badge-example.red {
            background: #d63638;
        }
        .slider-current-week {
            margin: 15px 0;
            padding: 10px;
            background: #e8f0fe;
            border-right: 4px solid #1e73be;
            border-radius: 4px;
            font-weight: 600;
        }
        .slider-clicks {
            display: inline-block;
            margin-left: 15px;
            font-size: 13px;
            background: #f0f0f1;
            padding: 2px 10px;
            border-radius: 12px;
            color: #50575e;
        }
        .slider-priority, .slider-duration {
            display: inline-block;
            margin: 0 10px 0 0;
        }
        .slider-priority input, .slider-duration input {
            width: 60px;
        }
    </style>

    <script>
    jQuery(document).ready(function($) {
        var currentWeek = <?php echo (int) date('W'); ?>;

        // ===== محاسبه وضعیت اسلایدها با استفاده از data-index و مدت‌ها =====
        function updateStatusBadges() {
            // جمع‌آوری ایندکس‌های اسلایدهای چرخه‌ای با مدت آنها
            var cycleItems = [];
            $('.slider-field-row').each(function() {
                var type = $(this).data('type');
                if (type === 'cycle') {
                    var duration = parseInt($(this).find('input[name^="slider_duration"]').val()) || 1;
                    cycleItems.push({
                        index: $(this).data('index'),
                        duration: duration
                    });
                }
            });

            var totalDuration = cycleItems.reduce(function(sum, item) { return sum + item.duration; }, 0);
            var selectedIndex = -1;
            if (cycleItems.length > 0 && totalDuration > 0) {
                var offset = (currentWeek - 1) % totalDuration;
                var accum = 0;
                for (var i = 0; i < cycleItems.length; i++) {
                    accum += cycleItems[i].duration;
                    if (offset < accum) {
                        selectedIndex = cycleItems[i].index;
                        break;
                    }
                }
                if (selectedIndex === -1 && cycleItems.length > 0) {
                    selectedIndex = cycleItems[0].index;
                }
            }

            $('.slider-field-row').each(function() {
                var $row = $(this);
                var type = $row.data('type');
                var $badge = $row.find('.slider-status-badge');
                var isActive = false;

                if (type === 'always') {
                    isActive = true;
                } else if (type === 'cycle') {
                    if ($row.data('index') === selectedIndex) {
                        isActive = true;
                    }
                }

                if (isActive) {
                    $badge.removeClass('inactive').addClass('active').text('فعال');
                } else {
                    $badge.removeClass('active').addClass('inactive').text('غیرفعال');
                }
            });
        }

        // ===== راه‌اندازی Sortable =====
        function initSortable() {
            $('.slider-field-wrapper').sortable({
                handle: '.slider-field-row',
                placeholder: 'slider-field-row ui-sortable-placeholder',
                axis: 'y',
                update: function() {
                    updateIndicesAndBadges();
                    updateRadioNames();
                    updateStatusBadges();
                }
            });
        }

        // ===== به‌روزرسانی شماره‌ها و نام‌ها =====
        function updateIndicesAndBadges() {
            $('.slider-field-row').each(function(index) {
                $(this).attr('data-index', index);
                var badge = $(this).find('.slider-index-badge');
                if (badge.length) {
                    badge.text('شماره قرارگیری: ' + (index + 1));
                }
            });
        }

        function updateRadioNames() {
            $('.slider-field-row').each(function(index) {
                $(this).find('input[type="radio"]').each(function() {
                    var currentName = $(this).attr('name');
                    var baseName = 'slider_type';
                    if (currentName && currentName.startsWith(baseName + '[')) {
                        var newName = baseName + '[' + index + ']';
                        $(this).attr('name', newName);
                    }
                });
            });
        }

        // ===== افزودن ردیف جدید =====
        $('.slider-add-row').on('click', function() {
            var row = $('.slider-field-row:first').clone();
            row.find('.slider-image-id').val('');
            row.find('.slider-image-preview').html('<p>هیچ عکسی انتخاب نشده است</p>');
            row.find('.slider-link-input').val('');
            row.find('input[type="radio"]').prop('checked', false);
            row.find('input[value="always"]').prop('checked', true);
            row.find('input[name^="slider_priority"]').val(0);
            row.find('input[name^="slider_duration"]').val(1);
            row.find('.slider-clicks').text('👆 کلیک: ۰');
            row.data('type', 'always');
            $('.slider-field-wrapper').append(row);
            $('.slider-field-wrapper').sortable('refresh');
            updateIndicesAndBadges();
            updateRadioNames();
            updateStatusBadges();
        });

        // ===== حذف ردیف =====
        $(document).on('click', '.slider-remove-btn', function() {
            if ($('.slider-field-row').length > 1) {
                $(this).closest('.slider-field-row').remove();
                $('.slider-field-wrapper').sortable('refresh');
                updateIndicesAndBadges();
                updateRadioNames();
                updateStatusBadges();
            } else {
                alert('حداقل یک اسلاید باید وجود داشته باشد.');
            }
        });

        // ===== تغییر نوع اسلاید =====
        $(document).on('change', 'input[name^="slider_type"]', function() {
            var $row = $(this).closest('.slider-field-row');
            var value = $(this).val();
            $row.data('type', value);
            updateStatusBadges();
        });

        // ===== تغییر مدت یا اولویت =====
        $(document).on('change', 'input[name^="slider_duration"]', function() {
            updateStatusBadges();
        });

        // ===== انتخاب عکس =====
        $(document).on('click', '.slider-upload-btn', function(e) {
            e.preventDefault();
            var button = $(this);
            var frame = wp.media({
                title: 'انتخاب عکس',
                multiple: false,
                library: { type: 'image' }
            });

            frame.on('select', function() {
                var attachment = frame.state().get('selection').first().toJSON();
                var row = button.closest('.slider-field-row');
                row.find('.slider-image-id').val(attachment.id);
                row.find('.slider-image-preview').html('<img src="' + attachment.sizes.medium.url + '">');
                // به‌روزرسانی آمار کلیک (با تصویر جدید، کلیک‌ها از ابتدا)
                // اما ما کلیک‌ها را بر اساس attachment.id ذخیره می‌کنیم، بنابراین نیازی به تغییر نیست.
            });

            frame.open();
        });

        // ===== اجرای اولیه =====
        initSortable();
        updateStatusBadges();
    });
    </script>
    <?php
}

// ============================================
// بخش 4: شورت‌کد نمایش در فرانت‌اند (با اولویت و کلیک)
// ============================================

add_shortcode('full_slider', 'global_slider_shortcode');
function global_slider_shortcode($atts) {
    $defaults = ['speed' => 4000];
    $atts = shortcode_atts($defaults, $atts);

    $all_items = get_option('global_slider_items', []);
    if (empty($all_items)) {
        return '';
    }

    // تفکیک اسلایدها
    $always_items = [];
    $cycle_items = [];
    foreach ($all_items as $item) {
        $type = isset($item['type']) ? $item['type'] : 'always';
        if ($type === 'always') {
            $always_items[] = $item;
        } else {
            $cycle_items[] = $item;
        }
    }

    // انتخاب اسلاید چرخه‌ای بر اساس مدت‌ها
    $selected_cycle = null;
    $cycle_count = count($cycle_items);
    if ($cycle_count > 0) {
        // محاسبه مجموع مدت‌ها
        $durations = array_map(function($item) {
            return isset($item['duration']) ? max(1, intval($item['duration'])) : 1;
        }, $cycle_items);
        $total_duration = array_sum($durations);
        $current_week = (int) date('W');
        $offset = ($current_week - 1) % $total_duration;
        $accum = 0;
        foreach ($cycle_items as $index => $item) {
            $duration = isset($item['duration']) ? max(1, intval($item['duration'])) : 1;
            $accum += $duration;
            if ($offset < $accum) {
                $selected_cycle = $item;
                break;
            }
        }
        // اگر به هر دلیل پیدا نشد، اولین را انتخاب کن
        if (!$selected_cycle && !empty($cycle_items)) {
            $selected_cycle = $cycle_items[0];
        }
    }

    // ترکیب: همه‌ی همیشه + یک اسلاید چرخه‌ای
    $active_items = $always_items;
    if ($selected_cycle) {
        $active_items[] = $selected_cycle;
    }

    if (empty($active_items)) {
        return '';
    }

    // مرتب‌سازی بر اساس اولویت (صعودی)
    usort($active_items, function($a, $b) {
        $pa = isset($a['priority']) ? intval($a['priority']) : 0;
        $pb = isset($b['priority']) ? intval($b['priority']) : 0;
        return $pa - $pb;
    });

    $active_items = array_values($active_items);
    $slider_id = 'slider-' . uniqid();

    ob_start();
    ?>
    <div class="my-slider-wrapper">
        <div class="my-slider-container" id="<?php echo $slider_id; ?>">
            <div class="my-slider-track">
                <?php foreach ($active_items as $item): 
                    $image_id = $item['image'];
                    $image_url = wp_get_attachment_image_url($image_id, 'full');
                    $image_alt = get_post_meta($image_id, '_wp_attachment_image_alt', true);
                    $link = esc_url($item['link']);

                    // ساخت لینک کلیک‌شمار
                    $click_link = '';
                    if (!empty($link)) {
                        // ساخت آدرس شمارش کلیک
                        $click_link = add_query_arg([
                            'slider_click' => $image_id,
                            'slider_link'  => urlencode($link),
                        ], home_url('/'));
                    }
                ?>
                    <div class="my-slider-slide">
                        <?php if (!empty($click_link)): ?>
                            <a href="<?php echo esc_url($click_link); ?>" target="_blank" class="my-slider-link">
                        <?php endif; ?>
                            <img src="<?php echo esc_url($image_url); ?>" 
                                 alt="<?php echo esc_attr($image_alt); ?>" 
                                 class="my-slider-image">
                        <?php if (!empty($click_link)): ?>
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <style>
        .my-slider-wrapper {
            width: 100%;
            max-width: 100%;
            margin: 0;
            padding: 0;
            overflow: hidden;
            line-height: 0;
            font-size: 0;
            display: block;
            position: relative;
            background: transparent;
            direction: ltr !important;
        }
        .my-slider-container {
            position: relative;
            width: 100%;
            max-width: 100%;
            margin: 0;
            padding: 0;
            overflow: hidden;
            display: block;
            line-height: 0;
            font-size: 0;
            direction: ltr !important;
        }
        .my-slider-track {
            display: flex;
            transition: transform 800ms ease-in-out;
            width: 100%;
            margin: 0;
            padding: 0;
            align-items: flex-start;
            flex-direction: row !important;
        }
        .my-slider-slide {
            flex: 0 0 100%;
            max-width: 100%;
            position: relative;
            overflow: hidden;
            display: block;
            width: 100%;
            height: auto;
            margin: 0;
            padding: 0;
        }
        .my-slider-link {
            display: block;
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
            text-decoration: none;
        }
        .my-slider-image {
            width: 100%;
            height: auto;
            display: block;
            margin: 0;
            padding: 0;
            border: 0;
            max-width: 100%;
            vertical-align: middle;
        }
        @media (max-width: 767px) {
            .my-slider-wrapper,
            .my-slider-container,
            .my-slider-track,
            .my-slider-slide {
                margin: 0 !important;
                padding: 0 !important;
                border: 0 !important;
            }
        }
    </style>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const container = document.querySelector('#<?php echo $slider_id; ?>');
        if (!container) return;
        const track = container.querySelector('.my-slider-track');
        if (!track) return;
        const slides = track.querySelectorAll('.my-slider-slide');
        const totalSlides = slides.length;
        if (totalSlides === 0) return;
        let currentIndex = 0;
        let autoPlayInterval;

        function goToSlide(index) {
            if (index < 0) index = totalSlides - 1;
            if (index >= totalSlides) index = 0;
            currentIndex = index;
            track.style.transform = 'translateX(-' + (currentIndex * 100) + '%)';
        }

        function startAutoPlay() {
            if (totalSlides <= 1) return;
            if (autoPlayInterval) clearInterval(autoPlayInterval);
            autoPlayInterval = setInterval(function() {
                goToSlide(currentIndex + 1);
            }, <?php echo intval($atts['speed']); ?>);
        }

        startAutoPlay();

        container.addEventListener('mouseenter', function() {
            if (autoPlayInterval) {
                clearInterval(autoPlayInterval);
                autoPlayInterval = null;
            }
        });
        container.addEventListener('mouseleave', function() {
            if (!autoPlayInterval) {
                startAutoPlay();
            }
        });

        let touchStartX = 0;
        container.addEventListener('touchstart', function(e) {
            touchStartX = e.changedTouches[0].screenX;
        }, { passive: true });
        container.addEventListener('touchend', function(e) {
            const diff = touchStartX - e.changedTouches[0].screenX;
            if (Math.abs(diff) > 50) {
                if (diff > 0) {
                    goToSlide(currentIndex + 1);
                } else {
                    goToSlide(currentIndex - 1);
                }
                if (autoPlayInterval) {
                    clearInterval(autoPlayInterval);
                    startAutoPlay();
                }
            }
        }, { passive: true });

        let resizeTimer;
        window.addEventListener('resize', function() {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(function() {
                goToSlide(currentIndex);
            }, 200);
        });
    });
    </script>
    <?php
    return ob_get_clean();
}

// ============================================
// بخش 5: شمارش کلیک‌ها (از طریق redirect)
// ============================================

add_action('init', 'global_slider_click_tracker');
function global_slider_click_tracker() {
    if (!isset($_GET['slider_click']) || !isset($_GET['slider_link'])) {
        return;
    }

    $image_id = intval($_GET['slider_click']);
    $link = urldecode($_GET['slider_link']);
    $link = esc_url_raw($link);

    if ($image_id > 0 && !empty($link)) {
        // دریافت داده‌های کلیک
        $clicks = get_option('global_slider_clicks', []);
        if (!isset($clicks[$image_id])) {
            $clicks[$image_id] = 0;
        }
        $clicks[$image_id]++;
        update_option('global_slider_clicks', $clicks);

        // ریدایرکت به لینک اصلی
        wp_redirect($link);
        exit;
    } else {
        // اگر داده‌ها ناقص بود، به خانه برو
        wp_redirect(home_url());
        exit;
    }
}