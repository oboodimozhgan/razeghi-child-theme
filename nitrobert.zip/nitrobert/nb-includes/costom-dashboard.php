<?php
  // 1. Register new endpoint (URL) for My Account page
// Note: Re-save Permalinks or it will give 404 error

function bbloomer_add_premium_support_endpoint() {
add_rewrite_endpoint( 'premium-support', EP_ROOT | EP_PAGES );
}

add_action( 'init', 'bbloomer_add_premium_support_endpoint' );

// ------------------
// 2. Add new query var

function bbloomer_premium_support_query_vars( $vars ) {
$vars[] = 'premium-support';
return $vars;
}

add_filter( 'query_vars', 'bbloomer_premium_support_query_vars', 0 );

// ------------------
// 3. Insert the new endpoint into the My Account menu

function bbloomer_add_premium_support_link_my_account( $items ) {
$items['premium-support'] = 'تیکت های من';
return $items;
}

add_filter( 'woocommerce_account_menu_items', 'bbloomer_add_premium_support_link_my_account' );

// ------------------
// 4. Add content to the new tab

function bbloomer_premium_support_content() {
//echo '<h3>پشتیبانی حرفه ای ووکامرس</h3><p>توضیحات خود را اینجا قرار دهید</i></p>';
echo do_shortcode( '[elementor-template id="713"]' );
}

add_action( 'woocommerce_account_premium-support_endpoint', 'bbloomer_premium_support_content' );
// Note: add_action must follow 'woocommerce_account_{your-endpoint-slug}_endpoint' format


//-------------------------------------------------------------------------------منوی جدید ------------------------------------------


// 1. Register new endpoint (URL) for My Account page
// Note: Re-save Permalinks or it will give 404 error

function bbloomer_add_send_ticket_endpoint() {
add_rewrite_endpoint( 'send-ticket', EP_ROOT | EP_PAGES );
}

add_action( 'init', 'bbloomer_add_send_ticket_endpoint' );

// ------------------
// 2. Add new query var

function bbloomer_send_ticket_query_vars( $vars ) {
$vars[] = 'send-ticket';
return $vars;
}

add_filter( 'query_vars', 'bbloomer_send_ticket_query_vars', 0 );

// ------------------
// 3. Insert the new endpoint into the My Account menu

function bbloomer_add_send_ticket_link_my_account( $items ) {
$items['send-ticket'] = 'ارسال تیکت';
return $items;
}

add_filter( 'woocommerce_account_menu_items', 'bbloomer_add_send_ticket_link_my_account' );

// ------------------
// 4. Add content to the new tab

function bbloomer_send_ticket_content() {
//echo '<h3>ارسال تیکت</h3><p>توضیحات خود را اینجا قرار دهید</i></p>';
echo do_shortcode( '[elementor-template id="715"]' );
}

add_action( 'woocommerce_account_send-ticket_endpoint', 'bbloomer_send_ticket_content' );
// Note: add_action must follow 'woocommerce_account_{your-endpoint-slug}_endpoint' format


//*****************//
function user_items_purchased_shortcode() {
    $user_id = get_current_user_id();
    if ($user_id == 0) {
        return 'لطفاً وارد حساب کاربری خود شوید.';
    }

    // تعداد سفارش‌ها و اقلام خریداری‌شده
    $orders = wc_get_orders(array(
        'customer' => $user_id,
        'status' => 'completed',
        'limit' => -1,
    ));
    $items_count = 0;
    foreach ($orders as $order) {
        $items_count += $order->get_item_count();
    }

    return '<p>' . $items_count . '</p>';
}
add_shortcode('user_items_purchased', 'user_items_purchased_shortcode');


function user_total_spent_shortcode() {
    $user_id = get_current_user_id();
    if ($user_id == 0) {
        return 'لطفاً وارد حساب کاربری خود شوید.';
    }

    // مجموع هزینه‌های خرید کاربر
    $total_spent = wc_get_customer_total_spent($user_id);

    return '<p> ' . wc_price($total_spent) . '</p>';
}
add_shortcode('user_total_spent', 'user_total_spent_shortcode');

function user_approved_comments_shortcode() { 
    $user_id = get_current_user_id(); 
    if ($user_id == 0) { 
        return 'لطفاً وارد حساب کاربری خود شوید.'; 
    } 
 
    // تعداد نظرات تایید شده 
    $comments_count = get_comments(array( 
        'user_id' => $user_id, 
        'status' => 'approve' 
    )); 
    $approved_comments = count($comments_count); 

    if ($approved_comments == 0) {
        return '<p>نظر دهید!</p>';
    }

    return '<p>' . $approved_comments . ' نظر تایید شده دارید.</p>'; 
} 
add_shortcode('user_approved_comments', 'user_approved_comments_shortcode');

function user_registration_time_shortcode() {
    $user_id = get_current_user_id();
    if ($user_id == 0) {
        return 'لطفاً وارد حساب کاربری خود شوید.';
    }

    // مدت زمان ثبت‌نام
    $user = get_user_by('id', $user_id);
    $registration_date = $user->user_registered;
    $registration_timestamp = strtotime($registration_date);
    $current_timestamp = current_time('timestamp');
    
    // محاسبه تعداد روزها
    $days_since_registration = floor(($current_timestamp - $registration_timestamp) / (60 * 60 * 24));

    return '<p> ' . $days_since_registration . ' روز</p>';
}
add_shortcode('user_registration_time', 'user_registration_time_shortcode');
// شورت کد برای نمایش کوپن تخفیف و میزان خرید باقی‌مانده تا رسیدن به تخفیف بعدی
function dynamic_discounts_shortcode() {
    if ( ! is_user_logged_in() ) return '';

    $user_id = get_current_user_id();
    $orders = wc_get_orders( [
        'customer' => $user_id,
        'status'   => 'completed',
        'limit'    => -1,
    ] );

    $total_spent = 0;
    $has_used = [];

    foreach ( $orders as $order ) {
        $total_spent += $order->get_total();
        $coupons = $order->get_coupon_codes();
        $has_used = array_merge( $has_used, $coupons );
    }

    // Define thresholds
    $thresholds = [
        'FIRST5' => 0,
        'SECOND10' => 500000,
        'THIRD15' => 2000000,
        'FOURTH25' => 2900000,
    ];

    // Define messages
    $output = '';
    $motivational_message = '';

    if ( $total_spent > 5000000 ) {
        $output .= '<p>کد تخفیف ۱۰٪ برای مشتریان ویژه: VIP10</p>';
    }

    if ( ! in_array( 'FIRST5', $has_used ) && count( $orders ) === 0 ) {
        $output .= '<p>کد تخفیف ۵٪: FIRST5</p>';
    } elseif ( ! in_array( 'SECOND10', $has_used ) && $total_spent > 500000 ) {
        $output .= '<p>کد تخفیف ۱۰٪: SECOND10</p>';
    } elseif ( ! in_array( 'THIRD15', $has_used ) && $total_spent > 2000000 ) {
        $output .= '<p>کد تخفیف ۱۵٪: THIRD15</p>';
    } elseif ( ! in_array( 'FOURTH25', $has_used ) && $total_spent > 2900000 ) {
        $output .= '<p>کد تخفیف ۲۵٪: FOURTH25</p>';
    } else {
        $next_threshold = null;
        foreach ( $thresholds as $code => $threshold ) {
            if ( ! in_array( $code, $has_used ) && $total_spent < $threshold ) {
                $next_threshold = $threshold;
                break;
            }
        }

        if ( $next_threshold ) {
            $remaining = $next_threshold - $total_spent;
            $motivational_message = '<p>فقط ' . wc_price( $remaining ) . ' دیگر خرید کنید تا تخفیف بعدی خود را دریافت کنید!</p>';
        } else {
            $motivational_message = '<p>با خرید بیشتر، تخفیف‌های بیشتری دریافت کنید!</p>';
        }

        $output .= $motivational_message;
    }

    return $output;
}

add_shortcode( 'dynamic_discounts', 'dynamic_discounts_shortcode' );