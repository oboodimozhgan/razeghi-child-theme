<?php
// افزودن صفحه راهنمای رنگ‌ها به پیشخوان وردپرس
function add_color_guide_page() {
    add_menu_page(
        'راهنمای رنگ‌ها',          // عنوان صفحه
        'راهنمای رنگ‌ها',          // نام منو
        'manage_options',           // سطح دسترسی
        'color-guide',              // شناسه منو
        'display_color_guide_page', // تابع نمایش صفحه
        'dashicons-art',            // آیکن منو
        100                         // موقعیت
    );
}
add_action('admin_menu', 'add_color_guide_page');

// تابع نمایش صفحه راهنمای رنگ‌ها
function display_color_guide_page() {
    ?>
    <div class="wrap">
        <h1>راهنمای رنگ‌ها و کلاس‌ها</h1>
        <p>برای استفاده از کلاس‌ها، روی دکمه "کپی" کلیک کنید تا نام کلاس به کلیپ‌بورد کپی شود.</p>
        <div class="color-guide">
            <!-- کلاس‌های رنگ اصلی -->
            <div class="color-item">
                <div class="color-preview" style="background-color: #2E7D32;"></div>
                <span class="color-name">رنگ اصلی (سبز تیره)</span>
                <span class="class-name">primary-color, btn-primary</span>
                <ul class="usage-list">
                    <li>دکمه‌های اصلی و CTA</li>
                    <li>لینک‌های مهم</li>
                </ul>
                <button class="copy-button" onclick="copyToClipboard('btn-primary')">کپی</button>
            </div>
            <!-- کلاس‌های رنگ ثانویه -->
            <div class="color-item">
                <div class="color-preview" style="background-color: #8D6E63;"></div>
                <span class="color-name">رنگ ثانویه (قهوه‌ای طبیعی)</span>
                <span class="class-name">secondary-color, highlight</span>
                <ul class="usage-list">
                    <li>بخش‌های برجسته</li>
                    <li>هایلایت اطلاعات خاص</li>
                </ul>
                <button class="copy-button" onclick="copyToClipboard('highlight')">کپی</button>
            </div>
            <!-- کلاس رنگ متن سبز روشن -->
            <div class="color-item">
                <div class="color-preview" style="background-color: #66BB6A;"></div>
                <span class="color-name">رنگ متن سبز روشن</span>
                <span class="class-name">text-color</span>
                <ul class="usage-list">
                    <li>متن‌های تأکیدی</li>
                    <li>برجسته‌سازی ویژگی‌های خاص محصولات</li>
                </ul>
                <button class="copy-button" onclick="copyToClipboard('text-color')">کپی</button>
            </div>
            <!-- رنگ هشدار (قرمز ملایم) -->
            <div class="color-item">
                <div class="color-preview" style="background-color: #FF6B6B;"></div>
                <span class="color-name">رنگ هشدار (قرمز ملایم)</span>
                <span class="class-name">alert-color</span>
                <ul class="usage-list">
                    <li>پیام‌های خطا و هشدار</li>
                </ul>
                <button class="copy-button" onclick="copyToClipboard('alert-color')">کپی</button>
            </div>
            <!-- رنگ موفقیت (سبز روشن) -->
            <div class="color-item">
                <div class="color-preview" style="background-color: #4CAF50;"></div>
                <span class="color-name">رنگ موفقیت (سبز روشن)</span>
                <span class="class-name">success-color</span>
                <ul class="usage-list">
                    <li>پیام‌های موفقیت</li>
                </ul>
                <button class="copy-button" onclick="copyToClipboard('success-color')">کپی</button>
            </div>
            <!-- رنگ لینک‌های کم‌اهمیت (خاکستری متمایل به آبی) -->
            <div class="color-item">
                <div class="color-preview" style="background-color: #607D8B;"></div>
                <span class="color-name">رنگ لینک‌های کم‌اهمیت</span>
                <span class="class-name">secondary-link-color</span>
                <ul class="usage-list">
                    <li>لینک‌های کم‌اهمیت</li>
                </ul>
                <button class="copy-button" onclick="copyToClipboard('secondary-link-color')">کپی</button>
            </div>
            <!-- رنگ پس‌زمینه فوتر (خاکستری تیره) -->
            <div class="color-item">
                <div class="color-preview" style="background-color: #333333;"></div>
                <span class="color-name">رنگ پس‌زمینه فوتر (خاکستری تیره)</span>
                <span class="class-name">footer-background</span>
                <ul class="usage-list">
                    <li>پس‌زمینه فوتر و هدر</li>
                </ul>
                <button class="copy-button" onclick="copyToClipboard('footer-background')">کپی</button>
            </div>

            <!-- رنگ پس‌زمینه‌ی المان‌های خاص -->
            <div class="color-item">
                <div class="color-preview" style="background-color: #F2F2F2;"></div>
                <span class="color-name">رنگ پس‌زمینه‌ی بخش‌های خاص</span>
                <span class="class-name">special-background</span>
                <ul class="usage-list">
                    <li>باکس‌های محتوا و کارت‌ها</li>
                </ul>
                <button class="copy-button" onclick="copyToClipboard('special-background')">کپی</button>
            </div>

            <!-- رنگ انتخاب‌شده (Active) -->
            <div class="color-item">
                <div class="color-preview" style="background-color: #1565C0;"></div>
                <span class="color-name">رنگ انتخاب‌شده (Active)</span>
                <span class="class-name">active-color</span>
                <ul class="usage-list">
                    <li>وضعیت فعال لینک‌ها و دکمه‌ها</li>
                </ul>
                <button class="copy-button" onclick="copyToClipboard('active-color')">کپی</button>
            </div>
        </div>

        <!-- پیغام کپی شد -->
        <div id="copy-notification" style="display: none;">کد کپی شد!</div>
    </div>
<!-- توضیحات کدها -->
    <div style="margin-top: 30px; font-family: Arial, sans-serif;">
        <h2>توضیحات کدها:</h2>
        <p>primary-color و btn-primary: برای لینک‌ها و دکمه‌های اصلی و CTA، رنگ سبز تیره و تغییر رنگ در حالت هاور تعریف شده است.</p>
        <p>secondary-color و highlight: برای بخش‌هایی که نیاز به هایلایت دارند، از رنگ قهوه‌ای طبیعی استفاده شده است.</p>
        <p>text-color و title-color: برای متن‌ها و عنوان‌ها به ترتیب از رنگ سبز روشن و خاکستری تیره استفاده شده است.</p>
        <p>description-color: برای توضیحات و متن‌های کم‌اهمیت از رنگ خاکستری ملایم استفاده شده است.</p>
        <p>btn-neutral: برای دکمه‌های خنثی که CTA قوی ندارند، رنگ قهوه‌ای تیره با تغییر رنگ در هاور استفاده شده است.</p>
        <p>body: رنگ پس‌زمینه اصلی برای کل سایت به رنگ کرمی روشن تنظیم شده است.</p>
        <p>box-background: برای باکس‌های اطلاعات و کارت‌ها، رنگ پس‌زمینه، پدینگ و سایه تعریف شده است.</p>
        <p>separator: برای خطوط جداکننده از رنگ خاکستری خیلی روشن استفاده شده است.</p>

        <h3>استفاده از کلاس‌ها:</h3>
        <ul>
            <li>برای لینک‌ها و دکمه‌های مهم از کلاس‌های primary-color و btn-primary استفاده کنید.</li>
            <li>برای هایلایت کردن متن‌ها یا بخش‌ها، کلاس‌های secondary-color و highlight را به کار ببرید.</li>
            <li>برای متن‌ها و عناوین از text-color و title-color استفاده کنید.</li>
            <li>برای توضیحات اضافی یا کم‌اهمیت، کلاس description-color مناسب است.</li>
            <li>دکمه‌های خنثی که CTA قوی ندارند، می‌توانند از کلاس btn-neutral استفاده کنند.</li>
            <li>برای پس‌زمینه‌ی اصلی از استایل body استفاده می‌شود.</li>
            <li>برای باکس‌های اطلاعات از کلاس box-background و برای خطوط جداکننده از separator استفاده کنید.</li>
        </ul>
    </div>

    <script>
        function copyToClipboard(className) {
            navigator.clipboard.writeText(className).then(function() {
                // نمایش پیغام کپی شد
                var notification = document.getElementById("copy-notification");
                notification.style.display = "block";
                notification.style.opacity = "1";

                // محو کردن پیغام پس از 2 ثانیه
                setTimeout(function() {
                    notification.style.opacity = "0";
                    setTimeout(function() {
                        notification.style.display = "none";
                    }, 500); // صبر برای محو شدن کامل
                }, 2000);
            }).catch(function(err) {
                console.error("کپی کردن نام کلاس به کلیپ‌بورد شکست خورد: ", err);
            });
        }
    </script>

    <style>
        .color-guide {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .color-item {
            border: 1px solid #ddd;
            padding: 10px;
            border-radius: 5px;
            width: 200px;
            text-align: center;
            font-family: Arial, sans-serif;
        }
        .color-preview {
            width: 100%;
            height: 50px;
            border-radius: 5px;
            margin-bottom: 10px;
        }
        .color-name {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }
        .class-name {
            color: #555;
            display: block;
            margin-bottom: 5px;
        }
        .usage-list {
            list-style: none;
            padding: 0;
            font-size: 0.9em;
            color: #777;
            text-align: left;
            margin: 5px 0 10px 0;
        }
        .usage-list li {
            margin-bottom: 5px;
        }
        .copy-button {
            background-color: #2E7D32;
            color: #FFFFFF;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .copy-button:hover {
            background-color: #276B29;
        }
        #copy-notification {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #2E7D32;
            color: #FFFFFF;
            padding: 10px 20px;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            font-family: Arial, sans-serif;
            opacity: 0;
            transition: opacity 0.5s ease;
            z-index: 1000;
        }
    </style>
    <?php
}
?>
