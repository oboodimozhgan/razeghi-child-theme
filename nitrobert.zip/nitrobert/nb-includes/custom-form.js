document.addEventListener("DOMContentLoaded", function () {
    // انتخاب همه چک‌باکس‌ها و رادیوها
    var inputs = document.querySelectorAll('.elementor-field-option input[type="checkbox"], .elementor-field-option input[type="radio"]');

    // تابع برای مدیریت نمایش چک‌باکس‌ها و رادیوها
    function handleVisibility(input) {
        var label = input.nextElementSibling; // گرفتن لیبل مرتبط
        if (input.checked) {
            input.style.display = "inline-block"; // نمایش چک‌باکس یا رادیو
            if (label) {
                label.style.borderColor = "#3b82f6"; // تغییر رنگ حاشیه لیبل
            }
        } else {
            input.style.display = "none"; // مخفی کردن در صورت انتخاب‌نشدن
            if (label) {
                label.style.borderColor = "#d1d5db"; // بازگرداندن استایل پیش‌فرض لیبل
            }
        }
    }

    // افزودن event listener برای هر چک‌باکس و رادیو
    for (var i = 0; i < inputs.length; i++) {
        (function (input) {
            handleVisibility(input); // مقدار اولیه
            input.addEventListener('change', function () {
                handleVisibility(input); // بررسی تغییرات
            });
        })(inputs[i]);
    }
});
