<?php
if (!defined('ABSPATH')) exit;

/*
|--------------------------------------------------------------------------
| تنظیمات قابل تغییر توسط برنامه‌نویس
|--------------------------------------------------------------------------
*/

// تعداد حداکثر تصاویر
define('VISITOR_MAX_IMAGES', 3);

// مسیر نسبی ذخیره‌سازی داخل wp-content/uploads
define('VISITOR_UPLOAD_DIR', 'visitor-uploads');

/*
|--------------------------------------------------------------------------
| 1. ایجاد نقش Visitor
|--------------------------------------------------------------------------
*/
add_action('init', function () {
    if (!get_role('visitor')) {
        add_role('visitor', 'Visitor', [
            'read' => true,
        ]);
    }
});

/*
|--------------------------------------------------------------------------
| 2. جلوگیری از ورود Visitor به wp-admin
|--------------------------------------------------------------------------
*/
add_action('admin_init', function () {
    if (wp_doing_ajax()) return;

    if (is_user_logged_in()) {
        $user = wp_get_current_user();
        if (in_array('visitor', (array) $user->roles)) {
            wp_redirect(home_url('/'));
            exit;
        }
    }
});

/*
|--------------------------------------------------------------------------
| 3. پردازش فرم لاگین (قبل از خروجی HTML)
|--------------------------------------------------------------------------
*/
add_action('wp_loaded', function () {

    if (!isset($_POST['visitor_login_btn'])) return;
    if (is_user_logged_in()) return;

    $creds = [
        'user_login'    => sanitize_text_field($_POST['visitor_user'] ?? ''),
        'user_password' => $_POST['visitor_pass'] ?? '',
        'remember'      => true,
    ];

    $user = wp_signon($creds, false);

    if (!is_wp_error($user)) {
        echo '<script>location.reload();</script>';
        exit;
    }

    global $visitor_login_error;
    $visitor_login_error = 'نام کاربری یا رمز عبور اشتباه است.';
});

/*
|--------------------------------------------------------------------------
| 4. ذخیره اطلاعات پنل Visitor (شامل محصولات و تصاویر)
|--------------------------------------------------------------------------
*/
add_action('init', function () {

    if (!is_user_logged_in()) return;
    if (!isset($_POST['visitor_save_dashboard'])) return;

    $user = wp_get_current_user();
    if (!in_array('visitor', (array) $user->roles)) return;

    $uid = $user->ID;

    // فیلدهای ساده
    update_user_meta($uid, 'shop_name', sanitize_text_field($_POST['shop_name'] ?? ''));
    update_user_meta($uid, 'shop_phone', sanitize_text_field($_POST['shop_phone'] ?? ''));
    update_user_meta($uid, 'shop_address', sanitize_textarea_field($_POST['shop_address'] ?? ''));
    update_user_meta($uid, 'shop_lat', sanitize_text_field($_POST['shop_lat'] ?? ''));
    update_user_meta($uid, 'shop_lng', sanitize_text_field($_POST['shop_lng'] ?? ''));
    update_user_meta($uid, 'visit_hours', sanitize_text_field($_POST['visit_hours'] ?? ''));

    // محصولات معرفی شده: آرایه از ID محصولات
    $introduced = isset($_POST['introduced_products']) && is_array($_POST['introduced_products'])
        ? array_map('intval', $_POST['introduced_products'])
        : [];
    update_user_meta($uid, 'introduced_products', $introduced);

    // محصولات گرفته شده: آرایه از ID محصولات
    $taken = isset($_POST['taken_products']) && is_array($_POST['taken_products'])
        ? array_map('intval', $_POST['taken_products'])
        : [];
    update_user_meta($uid, 'taken_products', $taken);

    // آپلود تصاویر
    if (!empty($_FILES['visitor_images']) && is_array($_FILES['visitor_images']['name'])) {
        $uploaded_urls = get_user_meta($uid, 'visitor_images', true);
        if (!is_array($uploaded_urls)) {
            $uploaded_urls = [];
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';

        $upload_dir = wp_upload_dir();
        $base_dir   = trailingslashit($upload_dir['basedir']) . VISITOR_UPLOAD_DIR;
        $base_url   = trailingslashit($upload_dir['baseurl']) . VISITOR_UPLOAD_DIR;

        if (!file_exists($base_dir)) {
            wp_mkdir_p($base_dir);
        }

        $files = $_FILES['visitor_images'];
        $count = count($files['name']);

        for ($i = 0; $i < $count; $i++) {

            if (empty($files['name'][$i])) continue;
            if (count($uploaded_urls) >= VISITOR_MAX_IMAGES) break;

            $file_array = [
                'name'     => sanitize_file_name($files['name'][$i]),
                'type'     => $files['type'][$i],
                'tmp_name' => $files['tmp_name'][$i],
                'error'    => $files['error'][$i],
                'size'     => $files['size'][$i],
            ];

            if ($file_array['error'] !== UPLOAD_ERR_OK) continue;

            // انتقال فایل به پوشه‌ی اختصاصی
            $ext = pathinfo($file_array['name'], PATHINFO_EXTENSION);
            $new_name = 'visitor-' . $uid . '-' . time() . '-' . $i . '.' . $ext;

            $target = trailingslashit($base_dir) . $new_name;

            if (@move_uploaded_file($file_array['tmp_name'], $target)) {
                $uploaded_urls[] = trailingslashit($base_url) . $new_name;
            }
        }

        update_user_meta($uid, 'visitor_images', $uploaded_urls);
    }

    global $visitor_dashboard_message;
    $visitor_dashboard_message = '✅ اطلاعات با موفقیت ذخیره شد.';
});

/*
|--------------------------------------------------------------------------
| 5. شورت‌کد ورود
|--------------------------------------------------------------------------
*/
add_shortcode('visitor_login', function () {

    global $visitor_login_error;

    // کاربر لاگین نیست → فرم ورود
    if (!is_user_logged_in()) {

        ob_start(); ?>
        <div class="visitor-login-box" style="max-width:400px;margin:40px auto;padding:25px;border:1px solid #ddd;border-radius:8px;">
            <h3 style="text-align:center">ورود ویزیتور</h3>

            <?php if (!empty($visitor_login_error)): ?>
                <div style="color:#c00;margin-bottom:10px">
                    <?php echo esc_html($visitor_login_error); ?>
                </div>
            <?php endif; ?>

            <form method="post">
                <p>
                    <label>نام کاربری</label><br>
                    <input type="text" name="visitor_user" required style="width:100%">
                </p>
                <p>
                    <label>رمز عبور</label><br>
                    <input type="password" name="visitor_pass" required style="width:100%">
                </p>
                <p>
                    <button type="submit" name="visitor_login_btn" style="width:100%">
                        ورود
                    </button>
                </p>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }

    // کاربر لاگین است ولی Visitor نیست
    $user = wp_get_current_user();
    if (!in_array('visitor', (array) $user->roles)) {
        return '<div style="color:red;text-align:center">دسترسی غیرمجاز</div>';
    }

    return do_shortcode('[visitor_dashboard]');
});

/*
|--------------------------------------------------------------------------
| 6. شورت‌کد پنل Visitor
|--------------------------------------------------------------------------
*/
add_shortcode('visitor_dashboard', function () {

    if (!is_user_logged_in()) return '';

    $user = wp_get_current_user();
    if (!in_array('visitor', (array) $user->roles)) return '';

    global $visitor_dashboard_message;
    $uid = $user->ID;

    // داده‌ها
    $shop_name   = get_user_meta($uid, 'shop_name', true);
    $shop_phone  = get_user_meta($uid, 'shop_phone', true);
    $shop_address= get_user_meta($uid, 'shop_address', true);
    $shop_lat    = get_user_meta($uid, 'shop_lat', true);
    $shop_lng    = get_user_meta($uid, 'shop_lng', true);
    $visit_hours = get_user_meta($uid, 'visit_hours', true);

    $introduced_selected = get_user_meta($uid, 'introduced_products', true);
    if (!is_array($introduced_selected)) $introduced_selected = [];

    $taken_selected = get_user_meta($uid, 'taken_products', true);
    if (!is_array($taken_selected)) $taken_selected = [];

    $visitor_images = get_user_meta($uid, 'visitor_images', true);
    if (!is_array($visitor_images)) $visitor_images = [];

    // گرفتن محصولات ووکامرس
    $products = get_posts([
        'post_type'      => 'product',
        'posts_per_page' => -1,
        'post_status'    => 'publish',
        'orderby'        => 'title',
        'order'          => 'ASC',
        'fields'         => 'ids',
    ]);

    ob_start(); ?>

    <!-- استایل ساده -->
    <style>
        .visitor-dashboard-wrapper * {
            box-sizing: border-box;
        }
        .visitor-dashboard-wrapper label {
            display:block;
            margin:10px 0 5px;
            font-weight:600;
        }
        .visitor-dashboard-wrapper input[type="text"],
        .visitor-dashboard-wrapper textarea,
        .visitor-dashboard-wrapper select {
            width:100%;
            padding:6px 8px;
            border:1px solid #ccc;
            border-radius:4px;
        }
        .visitor-dashboard-wrapper button {
            padding:8px 15px;
            border:none;
            background:#2271b1;
            color:#fff;
            border-radius:4px;
            cursor:pointer;
        }
        .visitor-dashboard-wrapper button:hover {
            background:#135e96;
        }
        .visitor-product-list {
            max-height:200px;
            overflow-y:auto;
            border:1px solid #ccc;
            padding:5px;
        }
        .visitor-product-item {
            display:flex;
            align-items:center;
            margin-bottom:3px;
        }
        .visitor-product-item input {
            margin-left:5px;
        }
        .visitor-images-preview img {
            max-width:100px;
            margin:5px;
            border-radius:4px;
            border:1px solid #ccc;
        }
        #visitor-map {
            width:100%;
            height:300px;
            margin-top:10px;
            border-radius:4px;
            border:1px solid #ccc;
        }
    </style>

    <div class="visitor-dashboard-wrapper" style="max-width:900px;margin:40px auto">
        <h2>پنل ویزیتور</h2>
        <p>خوش آمدید <strong><?php echo esc_html($user->display_name); ?></strong></p>

        <?php if (!empty($visitor_dashboard_message)): ?>
            <div style="color:green;margin-bottom:10px">
                <?php echo esc_html($visitor_dashboard_message); ?>
            </div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data">

            <!-- اطلاعات فروشگاه -->
            <h3>اطلاعات فروشگاه</h3>
            <label>نام مغازه</label>
            <input type="text" name="shop_name" value="<?php echo esc_attr($shop_name); ?>">

            <label>تلفن</label>
            <input type="text" name="shop_phone" value="<?php echo esc_attr($shop_phone); ?>">

            <label>آدرس دقیق</label>
            <textarea name="shop_address" rows="3"><?php echo esc_textarea($shop_address); ?></textarea>

            <!-- نقشه -->
            <h3 style="margin-top:25px;">موقعیت روی نقشه</h3>
            <button type="button" id="visitor-get-location-btn">دریافت موقعیت فعلی با GPS</button>

            <div id="visitor-map"></div>
            <input type="hidden" id="shop_lat" name="shop_lat" value="<?php echo esc_attr($shop_lat); ?>">
            <input type="hidden" id="shop_lng" name="shop_lng" value="<?php echo esc_attr($shop_lng); ?>">

            <!-- ساعات حضور -->
            <h3 style="margin-top:25px;">ساعات حضور</h3>
            <input type="text" name="visit_hours" value="<?php echo esc_attr($visit_hours); ?>" placeholder="مثلاً: شنبه تا چهارشنبه ۱۰ تا ۱۴">

            <!-- محصولات -->
            <h3 style="margin-top:25px;">محصولات معرفی شده</h3>
            <input type="text" id="visitor-product-search-introduced" placeholder="جستجوی محصول...">
            <div class="visitor-product-list" id="visitor-product-list-introduced">
                <?php
                if (!empty($products)) {
                    foreach ($products as $pid) {
                        $title = get_the_title($pid);
                        $checked = in_array($pid, $introduced_selected) ? 'checked' : '';
                        echo '<div class="visitor-product-item" data-title="' . esc_attr($title) . '">';
                        echo '<label>';
                        echo '<input type="checkbox" name="introduced_products[]" value="' . esc_attr($pid) . '" ' . $checked . '>';
                        echo esc_html($title);
                        echo '</label>';
                        echo '</div>';
                    }
                } else {
                    echo '<p>محصولی یافت نشد.</p>';
                }
                ?>
            </div>

            <h3 style="margin-top:25px;">محصولات گرفته شده</h3>
            <input type="text" id="visitor-product-search-taken" placeholder="جستجوی محصول...">
            <div class="visitor-product-list" id="visitor-product-list-taken">
                <?php
                if (!empty($products)) {
                    foreach ($products as $pid) {
                        $title = get_the_title($pid);
                        $checked = in_array($pid, $taken_selected) ? 'checked' : '';
                        echo '<div class="visitor-product-item" data-title="' . esc_attr($title) . '">';
                        echo '<label>';
                        echo '<input type="checkbox" name="taken_products[]" value="' . esc_attr($pid) . '" ' . $checked . '>';
                        echo esc_html($title);
                        echo '</label>';
                        echo '</div>';
                    }
                } else {
                    echo '<p>محصولی یافت نشد.</p>';
                }
                ?>
            </div>

            <!-- آپلود تصویر -->
            <h3 style="margin-top:25px;">تصاویر</h3>
            <p>حداکثر <?php echo (int) VISITOR_MAX_IMAGES; ?> تصویر می‌توانید آپلود کنید.</p>
            <input type="file" name="visitor_images[]" multiple accept="image/*">
            <?php if (!empty($visitor_images)): ?>
                <div class="visitor-images-preview">
                    <?php foreach ($visitor_images as $img_url): ?>
                        <img src="<?php echo esc_url($img_url); ?>" alt="">
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <br><br>
            <button type="submit" name="visitor_save_dashboard">
                ذخیره اطلاعات
            </button>
        </form>
    </div>

    <!-- Leaflet CSS & JS از CDN -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
          integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin=""/>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
            integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>

    <script>
        (function(){
            // جستجو در لیست محصولات
            function setupProductSearch(inputId, listId) {
                var input = document.getElementById(inputId);
                var list  = document.getElementById(listId);
                if (!input || !list) return;

                input.addEventListener('keyup', function() {
                    var q = this.value.toLowerCase();
                    var items = list.querySelectorAll('.visitor-product-item');
                    items.forEach(function(item){
                        var title = item.getAttribute('data-title').toLowerCase();
                        item.style.display = title.indexOf(q) !== -1 ? 'flex' : 'none';
                    });
                });
            }

            setupProductSearch('visitor-product-search-introduced', 'visitor-product-list-introduced');
            setupProductSearch('visitor-product-search-taken', 'visitor-product-list-taken');

            // نقشه Leaflet
            var latInput = document.getElementById('shop_lat');
            var lngInput = document.getElementById('shop_lng');

            var lat = parseFloat(latInput.value) || 35.6892; // تهران
            var lng = parseFloat(lngInput.value) || 51.3890;
            var map = L.map('visitor-map').setView([lat, lng], (latInput.value && lngInput.value) ? 16 : 12);

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
            }).addTo(map);

            var marker = L.marker([lat, lng], {draggable:true}).addTo(map);

            function updateLatLngFields(latlng){
                latInput.value = latlng.lat.toFixed(6);
                lngInput.value = latlng.lng.toFixed(6);
            }

            marker.on('dragend', function(e){
                updateLatLngFields(e.target.getLatLng());
            });

            map.on('click', function(e){
                marker.setLatLng(e.latlng);
                updateLatLngFields(e.latlng);
            });

            // دکمه دریافت لوکیشن GPS
            var gpsBtn = document.getElementById('visitor-get-location-btn');
            if (gpsBtn && navigator.geolocation) {
                gpsBtn.addEventListener('click', function(){
                    gpsBtn.disabled = true;
                    gpsBtn.innerText = 'در حال دریافت موقعیت...';

                    navigator.geolocation.getCurrentPosition(function(pos){
                        var latlng = {
                            lat: pos.coords.latitude,
                            lng: pos.coords.longitude
                        };
                        map.setView(latlng, 17);
                        marker.setLatLng(latlng);
                        updateLatLngFields(latlng);
                        gpsBtn.disabled = false;
                        gpsBtn.innerText = 'دریافت موقعیت فعلی با GPS';
                    }, function(err){
                        alert('امکان دریافت موقعیت وجود ندارد: ' + err.message);
                        gpsBtn.disabled = false;
                        gpsBtn.innerText = 'دریافت موقعیت فعلی با GPS';
                    });
                });
            }
        })();
    </script>

    <?php
    return ob_get_clean();
});
