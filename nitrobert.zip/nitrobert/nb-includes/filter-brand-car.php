<?php
// ============================================
// 1. ثبت شورت کدهای کروسل برای ۴ مسیر
// ============================================
add_shortcode('raz_carousel', 'raz_carousel_shortcode');
function raz_carousel_shortcode($atts) {
    $atts = shortcode_atts([
        'route'      => 'car_to_brand', // پیش‌فرض
        'items'      => 8,
        'autoplay'   => 'false',
        'loop'       => 'true',
        'title'      => ''
    ], $atts);

    $route = $atts['route'];
    $items = intval($atts['items']);
    $autoplay = $atts['autoplay'] === 'true' ? 3000 : false;
    $loop = $atts['loop'] === 'true';

    // تعیین عنوان و محتوای کروسل بر اساس route
    switch ($route) {
        case 'brand_to_car':
            $title = $atts['title'] ?: 'خرید بر اساس برند قطعه';
            $items_data = raz_get_brands_for_carousel();
            $card_template = 'brand_card';
            $link_base = home_url('/brand-archive/');
            break;
        case 'car_to_brand':
            $title = $atts['title'] ?: 'خودرو خود را انتخاب کنید';
            $items_data = raz_get_cars_for_carousel();
            $card_template = 'car_card';
            $link_base = home_url('/car-brands-archive/');
            break;
        case 'car_to_system_to_brand':
            $title = $atts['title'] ?: 'قطعات تخصصی خودرو (موتوری، برقی، ...)';
            $items_data = raz_get_cars_for_carousel();
            $card_template = 'car_card';
            $link_base = home_url('/car-system-archive/');
            break;
        case 'car_to_system':
            $title = $atts['title'] ?: 'خرید سریع قطعات (بدون انتخاب برند)';
            $items_data = raz_get_cars_for_carousel();
            $card_template = 'car_card';
            $link_base = home_url('/car-system-fast-archive/');
            break;
        default:
            return '<p>مسیر نامعتبر است.</p>';
    }

    if (empty($items_data)) return '<p>موردی برای نمایش وجود ندارد.</p>';

    ob_start();
    ?>
    <div class="raz-carousel-wrapper" data-autoplay="<?php echo $autoplay ?: 'false'; ?>" data-loop="<?php echo $loop ? 'true' : 'false'; ?>">
        <?php if ($title) : ?>
            <h2 class="raz-carousel-title"><?php echo esc_html($title); ?></h2>
        <?php endif; ?>
        <div class="swiper-container raz-swiper" data-items="<?php echo $items; ?>">
            <div class="swiper-wrapper">
                <?php foreach ($items_data as $item) : ?>
                    <div class="swiper-slide">
                        <?php if ($card_template === 'brand_card') : ?>
                            <a href="<?php echo esc_url(add_query_arg('brand_id', $item['id'], $link_base)); ?>" class="raz-brand-card">
                                <?php if ($item['logo']) : ?>
                                    <img src="<?php echo esc_url($item['logo']); ?>" alt="<?php echo esc_attr($item['name']); ?>">
                                <?php else : ?>
                                    <div class="no-logo"><?php echo esc_html($item['name']); ?></div>
                                <?php endif; ?>
                                <span><?php echo esc_html($item['name']); ?></span>
                            </a>
                        <?php else : ?>
                            <a href="<?php echo esc_url(add_query_arg('car_id', $item['id'], $link_base)); ?>" class="raz-car-card">
                                <?php if ($item['image']) : ?>
                                    <img src="<?php echo esc_url($item['image']); ?>" alt="<?php echo esc_attr($item['name']); ?>">
                                <?php else : ?>
                                    <div class="no-image"><?php echo esc_html($item['name']); ?></div>
                                <?php endif; ?>
                                <span><?php echo esc_html($item['name']); ?></span>
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="swiper-pagination"></div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

// ============================================
// 2. توابع کمکی برای دریافت داده‌های کروسل
// ============================================
function raz_get_brands_for_carousel() {
    // دریافت برندهای قطعه که موجودی دارند (ترم‌های tax 'part_brand')
    $terms = get_terms([
        'taxonomy'   => 'part_brand',
        'hide_empty' => true,
        'meta_query' => [] // می‌توانید شرط موجودی محصولات زیر هر برند را اضافه کنید
    ]);
    $brands = [];
    foreach ($terms as $term) {
        // عکس برند را از فیلد ACF یا متا 'brand_logo' بگیرید
        $logo = function_exists('get_field') ? get_field('brand_logo', $term) : '';
        $brands[] = [
            'id'   => $term->term_id,
            'name' => $term->name,
            'logo' => $logo
        ];
    }
    return $brands;
}

function raz_get_cars_for_carousel() {
    // دریافت خودروها (مثلاً ترم‌های 'car_model' که محصول دارند)
    $terms = get_terms([
        'taxonomy'   => 'car_model',
        'hide_empty' => true,
        'parent'     => 0 // فقط مدل‌های اصلی (در صورت نیاز برند خودرو هم می‌توانید ترکیب کنید)
    ]);
    $cars = [];
    foreach ($terms as $term) {
        $image = function_exists('get_field') ? get_field('car_image', $term) : '';
        $cars[] = [
            'id'    => $term->term_id,
            'name'  => $term->name,
            'image' => $image
        ];
    }
    return $cars;
}