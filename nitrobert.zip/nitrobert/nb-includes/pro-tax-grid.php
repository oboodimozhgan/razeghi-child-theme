<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ====================================================================
// بخش اول: شورت‌کد و منطق دریافت، مرتب‌سازی و نمایش در فرانت‌اند
// ====================================================================

function render_pro_taxonomy_carousel( $atts ) {
    $atts = shortcode_atts( array(
        'taxonomy'               => 'car_system',
        'limit'                  => 10,
        'columns'                => 5,
        'tablet_columns'         => 4,
        'mobile_columns'         => 2,
        'max_width'              => 1400,
        'style'                  => 'default',     // حالت‌ها: default, subtitle, flip
        'show_brand_name'        => 'yes',         // نمایش نام برند (بله/خیر)
        'show_term_name'         => 'yes',         // نمایش نام ترم اصلی (بله/خیر)
        'show_subtitle'          => 'yes',         // نمایش ساب‌تایتل (بله/خیر)
        'subtitle_source'        => 'part_type',   // منبع ساب‌تایتل: part_type, count, custom_field
        'hide_empty_terms'       => 'yes',         // مخفی کردن ترم‌های بدون محصول
        'exclude_terms'          => '',            // آیدی ترم‌هایی که نباید نمایش داده شوند (مثل: 5,12,23)
        'flip_animation'         => 'rotate',      // انیمیشن flip: rotate, slide, fade
        'hide_disabled_terms'    => 'yes',         // مخفی کردن ترم‌های غیرفعال (با متای _is_disabled=yes)
        'order_by'               => 'priority',    // مرتب‌سازی بر اساس: priority, count, name, term_id
        'order'                  => 'asc',         // ترتیب: asc, desc
    ), $atts, 'pro_tax_carousel' );

    // Sanitize inputs
    $taxonomy               = sanitize_text_field( $atts['taxonomy'] );
    $limit                  = intval( $atts['limit'] );
    $columns                = max( 1, intval( $atts['columns'] ) );
    $tablet_columns         = max( 1, intval( $atts['tablet_columns'] ) );
    $mobile_columns         = max( 1, intval( $atts['mobile_columns'] ) );
    $max_width              = max( 300, intval( $atts['max_width'] ) );
    $style                  = sanitize_text_field( $atts['style'] );
    $show_brand_name        = sanitize_text_field( $atts['show_brand_name'] ) === 'yes';
    $show_term_name         = sanitize_text_field( $atts['show_term_name'] ) === 'yes';
    $show_subtitle          = sanitize_text_field( $atts['show_subtitle'] ) === 'yes';
    $subtitle_source        = sanitize_text_field( $atts['subtitle_source'] );
    $hide_empty_terms       = sanitize_text_field( $atts['hide_empty_terms'] ) === 'yes';
    $exclude_terms          = array_map( 'intval', explode( ',', sanitize_text_field( $atts['exclude_terms'] ) ) );
    $flip_animation         = sanitize_text_field( $atts['flip_animation'] );
    $hide_disabled_terms    = sanitize_text_field( $atts['hide_disabled_terms'] ) === 'yes';
    $order_by               = sanitize_text_field( $atts['order_by'] );
    $order                  = sanitize_text_field( $atts['order'] );

    // ساخت کلید cache منحصر به فرد
    $transient_key = 'pro_tax_grid_' . md5( $taxonomy . '_' . $limit . '_' . $style . '_' . $show_brand_name . '_' . $show_term_name . '_' . $show_subtitle . '_' . $subtitle_source . '_' . $hide_disabled_terms . '_' . $order_by . '_' . $order );
    $terms = get_transient( $transient_key );

    if ( false === $terms ) {
        // تنظیمات دریافت ترم‌ها
        $get_terms_args = array(
            'taxonomy'   => $taxonomy,
            'hide_empty' => $hide_empty_terms,
        );
        
        // افزودن exclude اگر مقدار داشته باشد
        if ( ! empty( $exclude_terms ) ) {
            $get_terms_args['exclude'] = $exclude_terms;
        }
        
        $all_terms = get_terms( $get_terms_args );

        if ( ! is_wp_error( $all_terms ) && ! empty( $all_terms ) ) {
            
            // ==============================================
            // فیلتر کردن ترم‌های غیرفعال (با متای _is_disabled)
            // ==============================================
            if ( $hide_disabled_terms && function_exists( 'wpexpert_get_disabled_terms_grouped' ) ) {
                $disabled_data = wpexpert_get_disabled_terms_grouped();
                if ( ! empty( $disabled_data['all_ids'] ) ) {
                    $filtered_terms = array();
                    foreach ( $all_terms as $term ) {
                        // اگر ترم در لیست غیرفعال‌ها نبود، اضافه کن
                        if ( ! in_array( $term->term_id, $disabled_data['all_ids'] ) ) {
                            $filtered_terms[] = $term;
                        }
                    }
                    $all_terms = $filtered_terms;
                }
            }
            
            // ==============================================
            // مرتب‌سازی هوشمند بر اساس پارامترهای انتخابی
            // ==============================================
            usort( $all_terms, function( $a, $b ) use ( $order_by, $order ) {
                
                // مرتب‌سازی بر اساس اولویت (pro_tax_priority)
                if ( $order_by === 'priority' ) {
                    $priority_a = get_term_meta( $a->term_id, 'pro_tax_priority', true );
                    $priority_b = get_term_meta( $b->term_id, 'pro_tax_priority', true );
                    
                    $has_priority_a = ( $priority_a !== '' && $priority_a !== false );
                    $has_priority_b = ( $priority_b !== '' && $priority_b !== false );
                    
                    // هر دو اولویت دارند
                    if ( $has_priority_a && $has_priority_b ) {
                        $result = intval( $priority_a ) - intval( $priority_b );
                        return $order === 'desc' ? -$result : $result;
                    }
                    
                    // فقط یکی اولویت دارد
                    if ( $has_priority_a && ! $has_priority_b ) return -1;
                    if ( ! $has_priority_a && $has_priority_b ) return 1;
                    
                    // هیچکدام اولویت ندارند -> بر اساس تعداد محصولات
                    $result = $b->count - $a->count;
                    return $order === 'desc' ? -$result : $result;
                }
                
                // مرتب‌سازی بر اساس تعداد محصولات
                if ( $order_by === 'count' ) {
                    $result = $a->count - $b->count;
                    return $order === 'desc' ? -$result : $result;
                }
                
                // مرتب‌سازی بر اساس نام
                if ( $order_by === 'name' ) {
                    $result = strcmp( $a->name, $b->name );
                    return $order === 'desc' ? -$result : $result;
                }
                
                // مرتب‌سازی بر اساس ID (پیش‌فرض)
                $result = $a->term_id - $b->term_id;
                return $order === 'desc' ? -$result : $result;
            });

            // محدودیت تعداد
            if ( $limit > 0 && count( $all_terms ) > $limit ) {
                $terms = array_slice( $all_terms, 0, $limit );
            } else {
                $terms = $all_terms;
            }

            set_transient( $transient_key, $terms, 12 * HOUR_IN_SECONDS );
        } else {
            $terms = $all_terms; 
        }
    }

    if ( is_wp_error( $terms ) || empty( $terms ) ) {
        return '<p class="pro-tax-not-found" style="text-align:center; padding:20px; color:#fff;">' . esc_html__( 'دسته بندی یافت نشد.', 'text-domain' ) . '</p>';
    }

    ob_start();
    ?>
    
    <div class="pro-tax-grid-wrapper style-<?php echo esc_attr( $style ); ?> flip-animation-<?php echo esc_attr( $flip_animation ); ?>" 
         style="
            max-width: <?php echo esc_attr( $max_width ); ?>px; 
            --desk-cols: <?php echo esc_attr( $columns ); ?>; 
            --tab-cols: <?php echo esc_attr( $tablet_columns ); ?>; 
            --mob-cols: <?php echo esc_attr( $mobile_columns ); ?>;
         ">
         
        <div class="pro-tax-grid">
            <?php foreach ( $terms as $term ) : ?>
                <?php
                $term_link = get_term_link( $term );
                if ( is_wp_error( $term_link ) ) continue;

                $image_id  = get_term_meta( $term->term_id, 'taxonomy_image_id', true );
                $image_url = $image_id ? wp_get_attachment_image_url( $image_id, 'medium' ) : false;
                
                // تولید محتوای ساب‌تایتل بر اساس منبع انتخابی
                $subtitle_text = '';
                if ( $show_subtitle ) {
                    if ( $subtitle_source === 'part_type' ) {
                        $selected_types = get_term_meta( $term->term_id, '_brand_part_types', true );
                        if ( ! empty( $selected_types ) && is_array( $selected_types ) ) {
                            $type_names = array();
                            foreach ( $selected_types as $type_id ) {
                                $type_term = get_term( $type_id, 'part_type' );
                                if ( $type_term && ! is_wp_error( $type_term ) ) {
                                    $type_names[] = $type_term->name;
                                }
                            }
                            if ( ! empty( $type_names ) ) {
                                $subtitle_text = implode( '، ', $type_names );
                            }
                        }
                    } elseif ( $subtitle_source === 'count' ) {
                        $subtitle_text = $term->count . ' محصول';
                    } elseif ( $subtitle_source === 'custom_field' ) {
                        $custom_subtitle = get_term_meta( $term->term_id, 'pro_tax_subtitle', true );
                        $subtitle_text = ! empty( $custom_subtitle ) ? $custom_subtitle : '';
                    }
                    
                    // مقدار پیش‌فرض در صورت خالی بودن
                    if ( empty( $subtitle_text ) && $subtitle_source !== 'custom_field' ) {
                        $subtitle_text = $term->count . ' مورد';
                    }
                }
                
                // ساخت نام نمایشی
                $display_name = '';
                if ( $show_brand_name && $show_term_name ) {
                    $display_name = $term->name;
                } elseif ( $show_brand_name && ! $show_term_name ) {
                    // فقط نام برند (اگر متادیتای خاصی دارید)
                    $brand_name = get_term_meta( $term->term_id, 'brand_custom_name', true );
                    $display_name = ! empty( $brand_name ) ? $brand_name : $term->name;
                } elseif ( ! $show_brand_name && $show_term_name ) {
                    // فقط نام ترم اصلی
                    $display_name = $term->name;
                } else {
                    // هیچکدام نمایش داده نشود
                    $display_name = '';
                }
                ?>

                <div class="pro-tax-item">
                    <?php if ( $style === 'flip' ) : ?>
                        <!-- استایل فلپ کارت -->
                        <div class="pro-tax-flip-container">
                            <div class="pro-tax-flip-inner">
                                <div class="pro-tax-flip-front">
                                    <div class="pro-tax-image-wrapper <?php echo $image_url ? '' : 'is-empty'; ?>">
                                        <?php if ( $image_url ) : ?>
                                            <img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $term->name ); ?>" class="pro-tax-img" loading="lazy" />
                                        <?php else : ?>
                                            <div class="no-image-placeholder" aria-hidden="true">
                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                                                    <rect x="3" y="3" width="18" height="18" rx="3" ry="3"></rect>
                                                    <circle cx="8.5" cy="8.5" r="1.5"></circle>
                                                    <path d="M21 15l-5-5L5 21"></path>
                                                </svg>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <?php if ( ! empty( $display_name ) ) : ?>
                                        <h3 class="pro-tax-title"><?php echo esc_html( $display_name ); ?></h3>
                                    <?php endif; ?>
                                </div>
                                <div class="pro-tax-flip-back">
                                    <?php if ( ! empty( $display_name ) ) : ?>
                                        <h3 class="pro-tax-title-back"><?php echo esc_html( $display_name ); ?></h3>
                                    <?php endif; ?>
                                    <?php if ( $show_subtitle && ! empty( $subtitle_text ) ) : ?>
                                        <span class="pro-tax-count-badge"><?php echo esc_html( $subtitle_text ); ?></span>
                                    <?php endif; ?>
                                    <a href="<?php echo esc_url( $term_link ); ?>" class="pro-tax-btn-neon">مشاهده محصولات</a>
                                </div>
                            </div>
                        </div>

                    <?php else : ?>
                        <!-- استایل‌های default و subtitle -->
                        <a href="<?php echo esc_url( $term_link ); ?>" class="pro-tax-item-link" title="<?php echo esc_attr( $term->name ); ?>">
                            <div class="pro-tax-image-wrapper <?php echo $image_url ? '' : 'is-empty'; ?>">
                                <?php if ( $image_url ) : ?>
                                    <img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $term->name ); ?>" class="pro-tax-img" loading="lazy" />
                                <?php else : ?>
                                    <div class="no-image-placeholder" aria-hidden="true">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                                            <rect x="3" y="3" width="18" height="18" rx="3" ry="3"></rect>
                                            <circle cx="8.5" cy="8.5" r="1.5"></circle>
                                            <path d="M21 15l-5-5L5 21"></path>
                                        </svg>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="pro-tax-text-group">
                                <?php if ( ! empty( $display_name ) ) : ?>
                                    <h3 class="pro-tax-title"><?php echo esc_html( $display_name ); ?></h3>
                                <?php endif; ?>
                                
                                <?php if ( $style === 'subtitle' && $show_subtitle && ! empty( $subtitle_text ) ) : ?>
                                    <span class="pro-tax-subtitle" title="<?php echo esc_attr( $subtitle_text ); ?>">
                                        <?php echo esc_html( $subtitle_text ); ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php

    return ob_get_clean();
}
add_shortcode( 'pro_tax_carousel', 'render_pro_taxonomy_carousel' );

// ====================================================================
// بخش دوم: مدیریت کش و پاک‌سازی آن پس از ذخیره دسته‌بندی
// ====================================================================

add_action( 'saved_term', 'pro_tax_carousel_clear_transient', 10, 3 );
add_action( 'delete_term', 'pro_tax_carousel_clear_transient', 10, 3 );
add_action( 'added_term_meta', 'pro_tax_carousel_clear_on_meta_change', 10, 4 );
add_action( 'updated_term_meta', 'pro_tax_carousel_clear_on_meta_change', 10, 4 );

function pro_tax_carousel_clear_transient( $term_id, $tt_id, $taxonomy ) {
    global $wpdb;
    $wpdb->query( $wpdb->prepare( "DELETE FROM $wpdb->options WHERE option_name LIKE %s", '_transient_pro_tax_grid_%' ) );
    $wpdb->query( $wpdb->prepare( "DELETE FROM $wpdb->options WHERE option_name LIKE %s", '_transient_timeout_pro_tax_grid_%' ) );
}

function pro_tax_carousel_clear_on_meta_change( $meta_id, $object_id, $meta_key, $meta_value ) {
    if ( $meta_key === '_is_disabled' || $meta_key === 'pro_tax_priority' ) {
        pro_tax_carousel_clear_transient( $object_id, 0, '' );
    }
}

// ====================================================================
// بخش سوم: افزودن فیلدها، ستون‌ها و ویرایش سریع به پنل مدیریت
// ====================================================================

add_action('admin_init', 'pro_tax_admin_setup');
function pro_tax_admin_setup() {
    $taxonomies = get_taxonomies( array( 'public' => true ), 'names' );
    foreach ( $taxonomies as $tax ) {
        // فرم‌های افزودن و ویرایش اصلی
        add_action( "{$tax}_add_form_fields", 'pro_tax_add_priority_field', 10, 1 );
        add_action( "{$tax}_edit_form_fields", 'pro_tax_edit_priority_field', 10, 2 );
        add_action( "created_{$tax}", 'pro_tax_save_priority_field', 10, 2 );
        add_action( "edited_{$tax}", 'pro_tax_save_priority_field', 10, 2 );
        
        // ستون‌های جدول
        add_filter( "manage_edit-{$tax}_columns", 'pro_tax_add_priority_column' );
        add_filter( "manage_{$tax}_custom_column", 'pro_tax_priority_column_content', 10, 3 );
        add_filter( "manage_edit-{$tax}_sortable_columns", 'pro_tax_priority_sortable_column' );
    }
}

// فیلد در فرم افزودن
function pro_tax_add_priority_field( $taxonomy ) {
    ?>
    <div class="form-field term-priority-wrap">
        <label for="pro_tax_priority"><?php _e( 'اولویت نمایش (ترتیب)', 'text-domain' ); ?></label>
        <input type="number" name="pro_tax_priority" id="pro_tax_priority" value="" />
        <p><?php _e( 'هرچه عدد کوچکتر باشد، در لیست جلوتر نمایش داده می‌شود.', 'text-domain' ); ?></p>
    </div>
    
    <div class="form-field term-subtitle-wrap">
        <label for="pro_tax_subtitle"><?php _e( 'متن دلخواه برای ساب‌تایتل', 'text-domain' ); ?></label>
        <input type="text" name="pro_tax_subtitle" id="pro_tax_subtitle" value="" />
        <p><?php _e( 'اگر از منبع "فیلد دلخواه" برای ساب‌تایتل استفاده می‌کنید، این متن نمایش داده می‌شود.', 'text-domain' ); ?></p>
    </div>
    <?php
}

// فیلد در فرم ویرایش اصلی
function pro_tax_edit_priority_field( $term, $taxonomy ) {
    $priority = get_term_meta( $term->term_id, 'pro_tax_priority', true );
    $subtitle = get_term_meta( $term->term_id, 'pro_tax_subtitle', true );
    ?>
    <tr class="form-field term-priority-wrap">
        <th scope="row"><label for="pro_tax_priority"><?php _e( 'اولویت نمایش', 'text-domain' ); ?></label></th>
        <td>
            <input type="number" name="pro_tax_priority" id="pro_tax_priority" value="<?php echo esc_attr( $priority ); ?>" />
            <p class="description"><?php _e( 'هرچه عدد کوچکتر باشد، در لیست جلوتر نمایش داده می‌شود.', 'text-domain' ); ?></p>
        </td>
    </tr>
    <tr class="form-field term-subtitle-wrap">
        <th scope="row"><label for="pro_tax_subtitle"><?php _e( 'متن دلخواه برای ساب‌تایتل', 'text-domain' ); ?></label></th>
        <td>
            <input type="text" name="pro_tax_subtitle" id="pro_tax_subtitle" value="<?php echo esc_attr( $subtitle ); ?>" />
            <p class="description"><?php _e( 'اگر از منبع "فیلد دلخواه" برای ساب‌تایتل استفاده می‌کنید، این متن نمایش داده می‌شود.', 'text-domain' ); ?></p>
        </td>
    </table>
    <?php
}

// ذخیره‌سازی داده‌ها
function pro_tax_save_priority_field( $term_id, $tt_id ) {
    if ( isset( $_POST['pro_tax_priority'] ) ) {
        $priority_value = sanitize_text_field( $_POST['pro_tax_priority'] );
        if ( $priority_value === '' ) {
            delete_term_meta( $term_id, 'pro_tax_priority' );
        } else {
            update_term_meta( $term_id, 'pro_tax_priority', intval( $priority_value ) );
        }
    }
    
    if ( isset( $_POST['pro_tax_subtitle'] ) ) {
        $subtitle_value = sanitize_text_field( $_POST['pro_tax_subtitle'] );
        if ( $subtitle_value === '' ) {
            delete_term_meta( $term_id, 'pro_tax_subtitle' );
        } else {
            update_term_meta( $term_id, 'pro_tax_subtitle', $subtitle_value );
        }
    }
}

// افزودن عنوان ستون جدول
function pro_tax_add_priority_column( $columns ) {
    $columns['pro_tax_priority_col'] = __( 'اولویت', 'text-domain' );
    return $columns;
}

// محتوای ستون جدول
function pro_tax_priority_column_content( $content, $column_name, $term_id ) {
    if ( 'pro_tax_priority_col' === $column_name ) {
        $priority = get_term_meta( $term_id, 'pro_tax_priority', true );
        $hidden_field = '<input type="hidden" class="pro-tax-priority-value" value="' . esc_attr( $priority ) . '" />';
        
        if ( $priority !== '' ) {
            $content = $hidden_field . '<span style="display:inline-block; padding:3px 8px; background:#e0f0fa; color:#2271b1; border-radius:3px; font-weight:bold;">' . esc_html( $priority ) . '</span>';
        } else {
            $content = $hidden_field . '<span aria-hidden="true" style="color:#a7aaad;">—</span>';
        }
    }
    return $content;
}

// قابل مرتب‌سازی کردن ستون
function pro_tax_priority_sortable_column( $columns ) {
    $columns['pro_tax_priority_col'] = 'pro_tax_priority';
    return $columns;
}

// ====================================================================
// بخش چهارم: رابط کاربری ویرایش سریع (Quick Edit)
// ====================================================================

add_action( 'quick_edit_custom_box', 'pro_tax_quick_edit_custom_box', 10, 3 );
function pro_tax_quick_edit_custom_box( $column_name, $screen, $name ) {
    if ( $column_name === 'pro_tax_priority_col' ) {
        ?>
        <fieldset>
            <div class="inline-edit-col">
                <label>
                    <span class="title"><?php _e( 'اولویت', 'text-domain' ); ?></span>
                    <span class="input-text-wrap">
                        <input type="number" name="pro_tax_priority" class="pro-tax-priority-field" value="" style="width: 100%; max-width: 120px;"/>
                    </span>
                </label>
            </div>
        </fieldset>
        <?php
    }
}

// انتقال مقدار ستون به فرم ویرایش سریع
add_action( 'admin_footer-edit-tags.php', 'pro_tax_quick_edit_javascript' );
function pro_tax_quick_edit_javascript() {
    ?>
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        var $inline_editor = inlineEditTax.edit;
        inlineEditTax.edit = function(id) {
            $inline_editor.apply(this, arguments);
            var term_id = 0;
            if (typeof(id) === 'object') {
                term_id = parseInt(this.getId(id));
            }
            if (term_id > 0) {
                var $row = $('#tag-' + term_id);
                var priority = $row.find('.pro-tax-priority-value').val();
                var $edit_row = $('#edit-' + term_id);
                $edit_row.find('.pro-tax-priority-field').val(priority);
            }
        };
    });
    </script>
    <?php
}

// ====================================================================
// بخش پنجم: فعال‌سازی مرتب‌سازی در جدول ادمین
// ====================================================================

add_filter( 'terms_clauses', 'pro_tax_enable_admin_column_sorting', 10, 3 );
function pro_tax_enable_admin_column_sorting( $clauses, $taxonomies, $args ) {
    global $wpdb;

    if ( is_admin() && isset( $_GET['orderby'] ) && 'pro_tax_priority' === $_GET['orderby'] ) {
        $order = isset( $_GET['order'] ) && 'desc' === strtolower( $_GET['order'] ) ? 'DESC' : 'ASC';
        $clauses['join'] .= " LEFT JOIN {$wpdb->termmeta} AS pro_tm ON t.term_id = pro_tm.term_id AND pro_tm.meta_key = 'pro_tax_priority'";
        $clauses['orderby'] = "ORDER BY pro_tm.meta_value IS NULL ASC, CAST(pro_tm.meta_value AS SIGNED) {$order}";
        $clauses['order'] = '';
        $fields = trim( str_ireplace( 'DISTINCT', '', $clauses['fields'] ) );
        $clauses['fields'] = "DISTINCT " . $fields;
    }
    return $clauses;
}