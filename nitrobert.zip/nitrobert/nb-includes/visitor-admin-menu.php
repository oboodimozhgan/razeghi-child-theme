<?php
/**
 * پنل مدیریت ویزیتورها در ادمین وردپرس
 * شامل: مدیریت ویزیتورها، همکاران، فروشگاه‌ها، سفارشات، آمار و خروجی اکسل
 */

if (!defined('ABSPATH')) exit;
if (defined('VISITOR_ADMIN_LOADED')) return;
define('VISITOR_ADMIN_LOADED', true);

// بارگذاری فایل sms-api
$sms_api_path = WP_CONTENT_DIR . '/../visitor-panel/includes/sms-api.php';
if (!file_exists($sms_api_path)) {
    $sms_api_path = ABSPATH . 'visitor-panel/includes/sms-api.php';
}
if (!file_exists($sms_api_path)) {
    // تلاش با مسیر نسبی به wp-content
    $sms_api_path = dirname(WP_CONTENT_DIR) . '/visitor-panel/includes/sms-api.php';
}
if (file_exists($sms_api_path) && !defined('VISITOR_SMS_API_LOADED')) {
    require_once $sms_api_path;
}

$visitor_functions_path = WP_CONTENT_DIR . '/../visitor-panel/includes/functions.php';
if (!file_exists($visitor_functions_path)) {
    $visitor_functions_path = ABSPATH . 'visitor-panel/includes/functions.php';
}
if (!file_exists($visitor_functions_path)) {
    $visitor_functions_path = dirname(WP_CONTENT_DIR) . '/visitor-panel/includes/functions.php';
}
if (file_exists($visitor_functions_path) && !defined('VISITOR_FUNCTIONS_LOADED')) {
    require_once $visitor_functions_path;
}

// نمایش مبدا «ویزیتور - نام» در ستون Origin سفارشات ووکامرس
add_filter('wc_order_attribution_origin_formatted_source', 'visitor_panel_wc_origin_formatted_source', 10, 2);
add_filter('wc_order_attribution_origin_label', 'visitor_panel_wc_origin_label', 10, 4);

function visitor_panel_wc_origin_formatted_source($formatted_source, $source) {
    if (is_string($source) && strncmp($source, 'visitor-panel:', 14) === 0) {
        return substr($source, 14);
    }
    return $formatted_source;
}

function visitor_panel_wc_origin_label($label, $source_type, $source, $formatted_source) {
    if (is_string($source) && strncmp($source, 'visitor-panel:', 14) === 0) {
        return '%s';
    }
    return $label;
}

// ستون «پنل ویزیتور» در لیست سفارشات ووکامرس (HPOS)
add_filter('woocommerce_shop_order_list_table_columns', 'visitor_wc_orders_list_column');
add_action('woocommerce_shop_order_list_table_custom_column', 'visitor_wc_orders_list_column_content', 10, 2);

function visitor_wc_orders_list_column($columns) {
    $new = [];
    foreach ($columns as $key => $label) {
        $new[$key] = $label;
        if ($key === 'order_status') {
            $new['visitor_panel'] = 'پنل ویزیتور';
        }
    }
    if (!isset($new['visitor_panel'])) {
        $new['visitor_panel'] = 'پنل ویزیتور';
    }
    return $new;
}

function visitor_wc_orders_list_column_content($column, $order) {
    if ($column !== 'visitor_panel' || !$order instanceof WC_Order) {
        return;
    }

    $visitor_order_id = (int) $order->get_meta('_visitor_panel_order_id');
    $visitor_name = (string) $order->get_meta('_visitor_panel_visitor_name');

    if ($visitor_order_id <= 0) {
        $source = (string) $order->get_meta('_wc_order_attribution_utm_source');
        if (strncmp($source, 'visitor-panel:', 14) === 0) {
            echo esc_html(substr($source, 14));
        } else {
            echo '—';
        }
        return;
    }

    $label = $visitor_name !== '' ? $visitor_name : 'ویزیتور';
    echo '<span class="visitor-wc-badge">#' . esc_html($visitor_order_id) . ' — ' . esc_html($label) . '</span>';
}

// ---------- 1. منوی اصلی و زیرمنوها ----------
add_action('admin_menu', 'visitor_admin_main_menu');
function visitor_admin_main_menu() {
    add_menu_page(
        'مدیریت ویزیتورها',
        'ویزیتورها',
        'manage_options',
        'visitors',
        'visitor_admin_page',
        'dashicons-groups',
        30
    );

    add_submenu_page('visitors', 'مدیریت ویزیتورها', 'لیست ویزیتورها', 'manage_options', 'visitors', 'visitor_admin_page');
    add_submenu_page('visitors', 'مدیریت همکاران', 'لیست جذب‌شدگان', 'manage_options', 'visitor-colleagues', 'visitor_colleagues_page');
    add_submenu_page('visitors', 'فروشگاه‌ها', 'فروشگاه‌ها', 'manage_options', 'visitor-shops', 'visitor_shops_admin_page');
    add_submenu_page('visitors', 'پیگیری سفارشات', 'سفارشات', 'manage_options', 'visitor-orders', 'visitor_orders_admin_page');
    add_submenu_page('visitors', 'آمار و رتبه‌بندی', 'آمار و رتبه‌بندی', 'manage_options', 'visitor-stats', 'visitor_stats_page');
    add_submenu_page('visitors', 'تنظیمات پیامک', 'تنظیمات پیامک', 'manage_options', 'melipayamak-settings', 'melipayamak_settings_page');
    add_submenu_page('visitors', 'تنظیمات ذخیره تصاویر', 'ذخیره تصاویر', 'manage_options', 'visitor-upload-settings', 'visitor_upload_settings_page');
}

add_action('admin_enqueue_scripts', 'visitor_admin_enqueue_assets');
add_filter('admin_body_class', 'visitor_admin_body_class');

/**
 * شناسه صفحات ادمین پنل ویزیتور
 */
function visitor_admin_screen_ids() {
    return [
        'visitors',
        'visitor-colleagues',
        'visitor-shops',
        'visitor-orders',
        'visitor-stats',
        'melipayamak-settings',
        'visitor-upload-settings',
    ];
}

function visitor_admin_is_screen() {
    if (!is_admin() || !isset($_GET['page'])) {
        return false;
    }
    $page = sanitize_text_field(wp_unslash($_GET['page']));
    return in_array($page, visitor_admin_screen_ids(), true);
}

function visitor_admin_body_class($classes) {
    if (visitor_admin_is_screen()) {
        $classes .= ' visitor-panel-admin-screen';
    }
    return $classes;
}

function visitor_admin_resolve_path($relative) {
    $relative = ltrim(str_replace('\\', '/', $relative), '/');
    $candidates = [
        WP_CONTENT_DIR . '/../visitor-panel/' . $relative,
        ABSPATH . 'visitor-panel/' . $relative,
    ];
    foreach ($candidates as $path) {
        if (file_exists($path)) {
            return $path;
        }
    }
    return '';
}

function visitor_admin_enqueue_assets() {
    if (!visitor_admin_is_screen()) {
        return;
    }

    $relative = 'assets/visitor-admin.css';
    $path = visitor_admin_resolve_path($relative);
    $version = ($path !== '') ? (string) filemtime($path) : '1.0.0';
    $url = home_url('/visitor-panel/' . $relative);

    wp_enqueue_style('visitor-panel-admin', $url, [], $version);
}

function visitor_admin_page_header($title, $subtitle = '') {
    echo '<header class="vp-page-head"><h1>' . esc_html($title) . '</h1>';
    if ($subtitle !== '') {
        echo '<p class="vp-page-sub">' . wp_kses_post($subtitle) . '</p>';
    }
    echo '</header>';
}

function visitor_admin_toolbar_open() {
    echo '<div class="vp-toolbar">';
}

function visitor_admin_toolbar_close() {
    echo '</div>';
}

function visitor_admin_section_open($title) {
    echo '<section class="vp-section"><h2 class="vp-section-title">' . esc_html($title) . '</h2>';
}

function visitor_admin_section_close() {
    echo '</section>';
}

function visitor_admin_table_wrap_open($extra_class = '') {
    $class = 'vp-table-wrap';
    if ($extra_class !== '') {
        $class .= ' ' . esc_attr($extra_class);
    }
    echo '<div class="' . esc_attr($class) . '"><table class="vp-table wp-list-table widefat striped' . ($extra_class !== '' ? ' ' . esc_attr($extra_class) : '') . '">';
}

function visitor_admin_table_wrap_close() {
    echo '</table></div>';
}

function visitor_admin_form_card_open($title = '', $wide = false) {
    $class = 'vp-form-card' . ($wide ? ' vp-form-card-wide' : '');
    echo '<div class="' . esc_attr($class) . '">';
    if ($title !== '') {
        echo '<h2 class="vp-form-card-title">' . esc_html($title) . '</h2>';
    }
}

function visitor_admin_form_card_close() {
    echo '</div>';
}

// ---------- 2. صفحه مدیریت ویزیتورها ----------
function visitor_admin_page() {
    global $wpdb;
    $table_visitors = $wpdb->prefix . 'visitors';

    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_visitors)) != $table_visitors) {
        echo '<div class="notice notice-error"><p>جدول ویزیتورها وجود ندارد. لطفاً ابتدا دیتابیس را ایجاد کنید.</p></div>';
        return;
    }

    if (isset($_GET['action'], $_GET['id'], $_GET['_wpnonce'])) {
        $id = intval($_GET['id']);
        $action = sanitize_text_field($_GET['action']);

        if (!wp_verify_nonce($_GET['_wpnonce'], 'visitor_action_' . $id)) {
            wp_die('خطای امنیتی');
        }

        if ($action === 'delete') {
            $wpdb->delete($table_visitors, ['id' => $id]);
            wp_redirect(admin_url('admin.php?page=visitors&msg=deleted'));
            exit;

        } elseif ($action === 'deactivate') {
            $wpdb->update($table_visitors, ['status' => 'inactive'], ['id' => $id]);
            wp_redirect(admin_url('admin.php?page=visitors&msg=deactivated'));
            exit;

        } elseif ($action === 'activate') {
            $wpdb->update($table_visitors, ['status' => 'active'], ['id' => $id]);
            wp_redirect(admin_url('admin.php?page=visitors&msg=activated'));
            exit;

        } elseif ($action === 'reset_password') {
            $new_password = wp_generate_password(8, false, false);
            $new_hashed = password_hash($new_password, PASSWORD_DEFAULT);

            $updated = $wpdb->update($table_visitors, ['password_hash' => $new_hashed], ['id' => $id]);

            if ($updated !== false) {
                $visitor_info = $wpdb->get_row(
                    $wpdb->prepare("SELECT mobile, fullname FROM {$table_visitors} WHERE id = %d", $id)
                );

                if ($visitor_info && function_exists('send_visitor_credentials_via_pattern')) {
                    send_visitor_credentials_via_pattern($visitor_info->mobile, $visitor_info->fullname, $new_password);
                }

                set_transient('visitor_reset_password_' . $id, $new_password, 30);
                wp_redirect(admin_url('admin.php?page=visitors&msg=password_reset&visitor_id=' . $id));
                exit;
            } else {
                wp_redirect(admin_url('admin.php?page=visitors&msg=error_reset'));
                exit;
            }
        }
    }

    if (isset($_GET['msg'])) {
        $msg = sanitize_text_field($_GET['msg']);

        if ($msg === 'deleted') echo '<div class="notice notice-success"><p>ویزیتور حذف شد.</p></div>';
        if ($msg === 'deactivated') echo '<div class="notice notice-warning"><p>ویزیتور غیرفعال شد.</p></div>';
        if ($msg === 'activated') echo '<div class="notice notice-success"><p>ویزیتور فعال شد.</p></div>';
        if ($msg === 'added') echo '<div class="notice notice-success"><p>ویزیتور جدید اضافه شد.</p></div>';
        if ($msg === 'exists') echo '<div class="notice notice-warning"><p>کاربر با این شماره قبلاً ثبت‌نام کرده بود، نقش او به همکار تغییر کرد.</p></div>';

        if ($msg === 'password_reset' && isset($_GET['visitor_id'])) {
            $vid = intval($_GET['visitor_id']);
            $new_pass = get_transient('visitor_reset_password_' . $vid);

            if ($new_pass) {
                echo '<div class="notice notice-info"><p>رمز عبور جدید: <code>' . esc_html($new_pass) . '</code> (یک‌بار نمایش)</p></div>';
                delete_transient('visitor_reset_password_' . $vid);
            }
        }

        if ($msg === 'error_reset') {
            echo '<div class="notice notice-error"><p>خطا در تغییر رمز عبور.</p></div>';
        }
    }

    if (isset($_POST['add_visitor']) && isset($_POST['visitor_nonce']) && wp_verify_nonce($_POST['visitor_nonce'], 'add_visitor')) {
        $mobile   = sanitize_text_field($_POST['mobile']);
        $fullname = sanitize_text_field($_POST['fullname']);
        $password = wp_generate_password(8, false, false);
        $hashed   = password_hash($password, PASSWORD_DEFAULT);

        $existing_uid = function_exists('visitor_find_user_by_mobile')
            ? visitor_find_user_by_mobile($mobile)
            : 0;

        if ($existing_uid <= 0) {
            $user_exists = get_users([
                'meta_key'   => 'mobile',
                'meta_value' => $mobile,
                'number'     => 1,
            ]);
            if (!empty($user_exists)) {
                $existing_uid = (int) $user_exists[0]->ID;
            }
        }

        if ($existing_uid > 0) {
            if (function_exists('visitor_get_or_create_partner_user')) {
                visitor_get_or_create_partner_user([
                    'mobile'   => $mobile,
                    'fullname' => $fullname,
                    'send_sms' => false,
                ]);
            } else {
                (new WP_User($existing_uid))->set_role('partner');
            }
            wp_redirect(admin_url('admin.php?page=visitors&msg=exists'));
            exit;
        } else {
            $inserted = $wpdb->insert($table_visitors, [
                'mobile'        => $mobile,
                'fullname'      => $fullname,
                'password_hash' => $hashed,
                'role'          => 'visitor',
                'status'        => 'active'
            ]);

            if ($inserted) {
                if (function_exists('send_visitor_credentials_via_pattern')) {
                    send_visitor_credentials_via_pattern($mobile, $fullname, $password);
                }

                set_transient('visitor_added_password_' . $wpdb->insert_id, $password, 30);
                wp_redirect(admin_url('admin.php?page=visitors&msg=added'));
                exit;
            } else {
                echo '<div class="notice notice-error"><p>خطا در ثبت ویزیتور.</p></div>';
            }
        }
    }

    $visitors_db = $wpdb->get_results("SELECT id, mobile, fullname, role, status FROM {$table_visitors} ORDER BY id DESC");
    $wp_users = get_users(['role__in' => ['partner']]);
    $visitors_count = is_array($visitors_db) ? count($visitors_db) : 0;
    $partners_count = is_array($wp_users) ? count($wp_users) : 0;
    ?>
    <div class="wrap visitor-panel-admin">
        <?php visitor_admin_page_header(
            'مدیریت ویزیتورها / همکاران',
            '<strong>' . esc_html((string) $visitors_count) . '</strong> ویزیتور · <strong>' . esc_html((string) $partners_count) . '</strong> همکار وردپرس'
        ); ?>

        <?php visitor_admin_toolbar_open(); ?>
            <a href="<?php echo esc_url(admin_url('admin.php?page=visitor-export&type=visitors')); ?>" class="button button-primary">خروجی اکسل</a>
            <a href="<?php echo esc_url(admin_url('admin.php?page=visitor-colleagues')); ?>" class="button">لیست جذب‌شدگان</a>
            <a href="<?php echo esc_url(admin_url('admin.php?page=visitor-shops')); ?>" class="button">فروشگاه‌ها</a>
        <?php visitor_admin_toolbar_close(); ?>

        <?php visitor_admin_form_card_open('افزودن ویزیتور جدید'); ?>
        <form method="post">
            <?php wp_nonce_field('add_visitor', 'visitor_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th>شماره موبایل</th>
                    <td><input type="text" name="mobile" required class="regular-text" placeholder="09xxxxxxxxx"></td>
                </tr>
                <tr>
                    <th>نام و نام خانوادگی</th>
                    <td><input type="text" name="fullname" required class="regular-text"></td>
                </tr>
            </table>
            <?php submit_button('ثبت ویزیتور', 'primary', 'add_visitor'); ?>
        </form>
        <?php visitor_admin_form_card_close(); ?>

        <?php visitor_admin_section_open('لیست ویزیتورها (پنل مستقل)'); ?>
        <?php visitor_admin_table_wrap_open(); ?>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>نام</th>
                    <th>موبایل</th>
                    <th>نقش</th>
                    <th>وضعیت</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($visitors_db): ?>
                <?php foreach ($visitors_db as $v): ?>
                    <tr>
                        <td><?php echo esc_html($v->id); ?></td>
                        <td><?php echo esc_html($v->fullname); ?></td>
                        <td><?php echo esc_html($v->mobile); ?></td>
                        <td><?php echo esc_html($v->role); ?></td>
                        <td>
                            <?php if ($v->status === 'active'): ?>
                                <span class="vp-status vp-status-active">فعال</span>
                            <?php else: ?>
                                <span class="vp-status vp-status-inactive">غیرفعال</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php $nonce = wp_create_nonce('visitor_action_' . $v->id); ?>
                            <div class="vp-actions">
                                <a href="<?php echo esc_url('?page=visitors&action=deactivate&id=' . $v->id . '&_wpnonce=' . $nonce); ?>" class="button button-small" onclick="return confirm('غیرفعال شود؟')">غیرفعال</a>
                                <a href="<?php echo esc_url('?page=visitors&action=activate&id=' . $v->id . '&_wpnonce=' . $nonce); ?>" class="button button-small">فعال</a>
                                <a href="<?php echo esc_url('?page=visitors&action=reset_password&id=' . $v->id . '&_wpnonce=' . $nonce); ?>" class="button button-small vp-btn-warn">تغییر رمز</a>
                                <a href="<?php echo esc_url('?page=visitors&action=delete&id=' . $v->id . '&_wpnonce=' . $nonce); ?>" class="button button-small vp-btn-danger-text" onclick="return confirm('حذف شود؟')">حذف</a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="6">هیچ ویزیتوری یافت نشد.</td></tr>
            <?php endif; ?>
            </tbody>
        <?php visitor_admin_table_wrap_close(); ?>
        <?php visitor_admin_section_close(); ?>

        <?php visitor_admin_section_open('همکاران (کاربران وردپرس با نقش partner)'); ?>
        <?php visitor_admin_table_wrap_open(); ?>
            <thead>
                <tr>
                    <th>نام</th>
                    <th>موبایل</th>
                    <th>نقش</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($wp_users): ?>
                <?php foreach ($wp_users as $u): ?>
                    <tr>
                        <td><?php echo esc_html($u->display_name); ?></td>
                        <td><?php echo esc_html(get_user_meta($u->ID, 'mobile', true)); ?></td>
                        <td>همکار (partner)</td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="3">هیچ همکاری یافت نشد.</td></tr>
            <?php endif; ?>
            </tbody>
        <?php visitor_admin_table_wrap_close(); ?>
        <?php visitor_admin_section_close(); ?>
    </div>
    <?php
}

/**
 * نمایش توضیحات راهنما در انتهای صفحات ادمین
 *
 * @param string[] $sections بلوک‌های HTML
 */
function visitor_admin_render_footer_help(array $sections) {
    if (empty($sections)) {
        return;
    }
    echo '<div class="vp-help-section visitor-admin-page-help">';
    foreach ($sections as $html) {
        echo '<div class="vp-help-card">' . $html . '</div>';
    }
    echo '</div>';
}

// ---------- 3. لیست جذب‌شدگان (متفاوت از فروشگاه‌ها) ----------
function visitor_colleagues_page() {
    global $wpdb;

    if (function_exists('visitor_visitors_ensure_schema')) {
        visitor_visitors_ensure_schema();
    }

    if (isset($_POST['repair_partners_bulk']) && isset($_POST['repair_partners_nonce']) && wp_verify_nonce($_POST['repair_partners_nonce'], 'repair_partners_bulk')) {
        $result = function_exists('visitor_repair_partners_bulk')
            ? visitor_repair_partners_bulk()
            : ['created' => 0, 'synced' => 0, 'shops_linked' => 0, 'profiles_synced' => 0, 'skipped' => 0, 'failed' => 0];
        wp_redirect(admin_url(
            'admin.php?page=visitor-colleagues&msg=partners_repair'
            . '&created=' . (int) ($result['created'] ?? 0)
            . '&synced=' . (int) ($result['synced'] ?? 0)
            . '&shops_linked=' . (int) ($result['shops_linked'] ?? 0)
            . '&profiles=' . (int) ($result['profiles_synced'] ?? 0)
            . '&skipped=' . (int) ($result['skipped'] ?? 0)
            . '&failed=' . (int) ($result['failed'] ?? 0)
        ));
        exit;
    }

    if (isset($_POST['admin_add_colleague']) && isset($_POST['colleague_nonce']) && wp_verify_nonce($_POST['colleague_nonce'], 'admin_add_colleague')) {
        $recruiter_id = (int) ($_POST['recruiter_visitor_id'] ?? 0);
        $mobile = sanitize_text_field($_POST['colleague_mobile'] ?? '');
        $first = sanitize_text_field($_POST['colleague_first_name'] ?? '');
        $last = sanitize_text_field($_POST['colleague_last_name'] ?? '');

        if ($recruiter_id <= 0 || $mobile === '') {
            wp_redirect(admin_url('admin.php?page=visitor-colleagues&msg=colleague_error'));
            exit;
        }

        $result = function_exists('visitor_register_colleague')
            ? visitor_register_colleague($recruiter_id, [
                'mobile'     => $mobile,
                'first_name' => $first,
                'last_name'  => $last,
                'send_sms'   => !empty($_POST['colleague_send_sms']),
            ])
            : new WP_Error('missing', 'تابع ثبت همکار یافت نشد.');

        if (is_wp_error($result)) {
            wp_redirect(admin_url('admin.php?page=visitor-colleagues&msg=colleague_error&err=' . rawurlencode($result->get_error_message())));
            exit;
        }

        $msg = !empty($result['created']) ? 'colleague_created' : 'colleague_synced';
        wp_redirect(admin_url('admin.php?page=visitor-colleagues&msg=' . $msg));
        exit;
    }

    $colleague_page_notices = '';
    if (isset($_GET['msg'])) {
        $m = sanitize_text_field($_GET['msg']);
        if ($m === 'colleague_created') {
            $colleague_page_notices = '<div class="notice notice-success"><p>همکار جدید در کاربران وردپرس/ووکامرس ساخته شد.</p></div>';
        } elseif ($m === 'colleague_synced') {
            $colleague_page_notices = '<div class="notice notice-success"><p>کاربر از قبل وجود داشت؛ اطلاعات همگام شد و نقش همکار تنظیم شد.</p></div>';
        } elseif ($m === 'colleague_error') {
            $err = isset($_GET['err']) ? sanitize_text_field(wp_unslash($_GET['err'])) : 'خطا در ثبت همکار.';
            $colleague_page_notices = '<div class="notice notice-error"><p>' . esc_html($err) . '</p></div>';
        } elseif ($m === 'partners_repair') {
            $colleague_page_notices = '<div class="notice notice-success"><p>'
                . esc_html((int) ($_GET['created'] ?? 0)) . ' کاربر جدید ساخته شد، '
                . esc_html((int) ($_GET['synced'] ?? 0)) . ' همگام با حساب موجود، '
                . esc_html((int) ($_GET['shops_linked'] ?? 0)) . ' فروشگاه وصل شد، '
                . esc_html((int) ($_GET['profiles'] ?? 0)) . ' پروفایل WC به‌روز شد. '
                . 'رد شده: ' . esc_html((int) ($_GET['skipped'] ?? 0)) . ' — ناموفق: ' . esc_html((int) ($_GET['failed'] ?? 0))
                . '</p></div>';
        }
    }

    $visitors_list = $wpdb->get_results("SELECT id, fullname, mobile FROM {$wpdb->prefix}visitors WHERE status = 'active' ORDER BY fullname ASC");

    $partner_role_ok = function_exists('visitor_ensure_partner_role') ? visitor_ensure_partner_role() : (bool) get_role('partner');
    $partner_users = get_users(['role' => 'partner', 'number' => -1, 'fields' => 'ID']);
    $shops_no_mobile = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->prefix}visitor_shops
         WHERE (manager_mobile IS NULL OR manager_mobile = '')
         AND (shop_phone IS NULL OR shop_phone = '')"
    );
    $shops_with_mobile = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->prefix}visitor_shops
         WHERE manager_mobile IS NOT NULL AND manager_mobile != ''"
    );
    $shops_no_wp_user = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->prefix}visitor_shops
         WHERE (manager_user_id IS NULL OR manager_user_id = 0)
         AND manager_mobile IS NOT NULL AND manager_mobile != ''"
    );

    $colleagues = [];
    $colleagues_load_error = '';
    if (function_exists('visitor_get_all_colleagues_admin')) {
        $colleagues = visitor_get_all_colleagues_admin();
        if (!empty($wpdb->last_error)) {
            $colleagues_load_error = $wpdb->last_error;
        }
    } else {
        $colleagues_load_error = 'فایل functions.php پنل ویزیتور روی سرور به‌روز نیست.';
    }

    $colleagues_footer_help = [
        '<p><strong>وضعیت کاربران وردپرس (users.php):</strong></p>'
        . '<ul style="list-style:disc; margin-right:20px;">'
        . '<li>نقش <code>partner</code> (همکار): ' . ($partner_role_ok ? '✅ فعال' : '❌ وجود ندارد — فایل functions.php را آپلود کنید') . '</li>'
        . '<li>تعداد کاربران با نقش همکار: <strong>' . count($partner_users) . '</strong>'
        . ' — <a href="' . esc_url(admin_url('users.php?role=partner')) . '">مشاهده در کاربران</a></li>'
        . '<li>فروشگاه با موبایل مسئول: ' . esc_html($shops_with_mobile) . ' | '
        . 'بدون موبایل: ' . esc_html($shops_no_mobile) . ' | '
        . 'موبایل دارند ولی بدون کاربر WP: ' . esc_html($shops_no_wp_user) . '</li>'
        . '</ul>'
        . ($shops_no_wp_user > 0
            ? '<p>برای ساخت کاربر WP از روی فروشگاه‌های قبلی، دکمه <strong>همگام‌سازی همه همکاران/مسئولین قبلی</strong> را بزنید.</p>'
            : ''),
        '<p><strong>تفاوت با منوی «فروشگاه‌ها»:</strong></p>'
        . '<ul style="list-style:disc; margin-right:20px;">'
        . '<li><strong>فروشگاه‌ها</strong> = مکان فیزیکی + آدرس + GPS + تصاویر + مسئول فروشگاه.</li>'
        . '<li><strong>این صفحه</strong> = لیست کلی افرادی که ویزیتور جذب کرده (حساب partner یا ویزیتور زیرمجموعه).</li>'
        . '<li>جزئیات مسئول فروشگاه در <a href="' . esc_url(admin_url('admin.php?page=visitor-shops')) . '">فروشگاه‌ها → مشاهده جزئیات</a>.</li>'
        . '</ul>',
        '<p>اگر شماره قبلاً در ووکامرس ثبت‌نام کرده، همان حساب به‌روزرسانی می‌شود.</p>'
        . '<p>برای فروشگاه‌های قدیمی: همگام‌سازی مسئولین را بزنید؛ سپس در <a href="' . esc_url(admin_url('admin.php?page=visitor-orders')) . '">سفارشات</a> همگام WC و اتصال به حساب همکار.</p>',
    ];
    ?>
    <div class="wrap visitor-panel-admin">
        <?php visitor_admin_page_header(
            'لیست افراد جذب‌شده',
            '<strong>' . esc_html((string) count($colleagues)) . '</strong> همکار ثبت‌شده'
        ); ?>
        <?php echo wp_kses_post($colleague_page_notices); ?>
        <?php if ($colleagues_load_error !== ''): ?>
            <div class="notice notice-error"><p>خطا در بارگذاری لیست: <?php echo esc_html($colleagues_load_error); ?></p></div>
        <?php endif; ?>

        <?php visitor_admin_toolbar_open(); ?>
            <a href="<?php echo esc_url(admin_url('admin.php?page=visitor-export&type=colleagues')); ?>" class="button button-primary">خروجی اکسل</a>
            <a href="<?php echo esc_url(admin_url('admin.php?page=visitor-shops')); ?>" class="button">فروشگاه‌ها</a>
        <?php visitor_admin_toolbar_close(); ?>

        <div class="vp-search-wrap">
            <input type="search" id="visitorColleagueSearch" class="vp-search" placeholder="جستجو نام یا موبایل...">
        </div>
        <div class="vp-table-wrap">
        <table class="vp-table wp-list-table widefat striped" id="visitorColleaguesTable">
            <thead><tr><th>نام</th><th>موبایل</th><th>تاریخ عضویت</th><th>جذب‌کننده</th></tr></thead>
            <tbody>
            <?php if (!empty($colleagues)): ?>
                <?php foreach ($colleagues as $c):
                    $c_name = is_object($c) ? ($c->fullname ?? '') : ($c['fullname'] ?? '');
                    $c_mobile = is_object($c) ? ($c->mobile ?? '') : ($c['mobile'] ?? '');
                    $c_created = is_object($c) ? ($c->created_at ?? '') : ($c['created_at'] ?? '');
                    $c_recruiter = is_object($c) ? ($c->recruiter_name ?? '') : ($c['recruiter_name'] ?? '');
                    $c_date = $c_created ? date_i18n('Y/m/d', strtotime($c_created)) : '—';
                ?>
                    <tr data-name="<?php echo esc_attr($c_name); ?>" data-mobile="<?php echo esc_attr($c_mobile); ?>">
                        <td><?php echo esc_html($c_name); ?></td>
                        <td><?php echo esc_html($c_mobile); ?></td>
                        <td><?php echo esc_html($c_date); ?></td>
                        <td><?php echo esc_html($c_recruiter ?: '—'); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="4">هنوز همکاری ثبت نشده. از فرم پایین همکار اضافه کنید یا «همگام‌سازی» را بزنید.</td></tr>
            <?php endif; ?>
            </tbody>
        </table></div>
        <script>
        (function() {
            var input = document.getElementById('visitorColleagueSearch');
            if (!input) return;
            input.addEventListener('input', function() {
                var q = (input.value || '').trim().toLowerCase();
                document.querySelectorAll('#visitorColleaguesTable tbody tr[data-name]').forEach(function(row) {
                    var name = (row.getAttribute('data-name') || '').toLowerCase();
                    var mobile = (row.getAttribute('data-mobile') || '').toLowerCase();
                    row.style.display = (!q || name.indexOf(q) !== -1 || mobile.indexOf(q) !== -1) ? '' : 'none';
                });
            });
        })();
        </script>

        <hr class="vp-divider">

        <?php visitor_admin_form_card_open('تعریف همکار (کاربر WP + ووکامرس)'); ?>
        <form method="post">
            <?php wp_nonce_field('admin_add_colleague', 'colleague_nonce'); ?>
            <p class="vp-form-row">
                <label>ویزیتور جذب‌کننده *</label>
                <select name="recruiter_visitor_id" required>
                    <option value="">— انتخاب —</option>
                    <?php foreach ($visitors_list as $v): ?>
                        <option value="<?php echo (int) $v->id; ?>"><?php echo esc_html($v->fullname . ' (' . $v->mobile . ')'); ?></option>
                    <?php endforeach; ?>
                </select>
            </p>
            <p class="vp-form-row">
                <label>موبایل همکار *</label>
                <input type="tel" name="colleague_mobile" required class="regular-text" placeholder="09xxxxxxxxx">
            </p>
            <p class="vp-form-row">
                <label>نام</label>
                <input type="text" name="colleague_first_name" class="regular-text">
            </p>
            <p class="vp-form-row">
                <label>نام خانوادگی</label>
                <input type="text" name="colleague_last_name" class="regular-text">
            </p>
            <p class="vp-form-row">
                <label><input type="checkbox" name="colleague_send_sms" value="1"> ارسال پیامک نام کاربری/رمز (فقط کاربر جدید)</label>
            </p>
            <p><button type="submit" name="admin_add_colleague" class="button button-primary">ثبت همکار</button></p>
        </form>
        <?php visitor_admin_form_card_close(); ?>

        <?php visitor_admin_section_open('همگام‌سازی افراد قبلی'); ?>
        <form method="post">
            <?php wp_nonce_field('repair_partners_bulk', 'repair_partners_nonce'); ?>
            <button type="submit" name="repair_partners_bulk" class="button button-primary"
                    onclick="return confirm('همه مسئولین فروشگاه و همکاران قبلی با WP/WC همگام شوند؟');">
                همگام‌سازی همه همکاران/مسئولین قبلی
            </button>
        </form>
        <?php visitor_admin_section_close(); ?>

        <?php visitor_admin_render_footer_help($colleagues_footer_help); ?>
    </div>
    <?php
}

// ---------- 4. صفحه مدیریت فروشگاه‌ها ----------
function visitor_shops_admin_page() {
    global $wpdb;

    if (isset($_GET['view'])) {
        visitor_admin_shop_detail_page((int) $_GET['view']);
        return;
    }

    $shops = $wpdb->get_results("
        SELECT s.*, v.fullname as visitor_name
        FROM {$wpdb->prefix}visitor_shops s
        LEFT JOIN {$wpdb->prefix}visitors v ON s.visitor_id = v.id
        ORDER BY s.created_at DESC
    ");
    ?>
    <div class="wrap visitor-panel-admin">
        <?php visitor_admin_page_header('فروشگاه‌های ثبت‌شده', '<strong>' . esc_html((string) count($shops)) . '</strong> فروشگاه'); ?>
        <?php visitor_admin_toolbar_open(); ?>
            <a href="<?php echo esc_url(admin_url('admin.php?page=visitor-export&type=shops')); ?>" class="button button-primary">خروجی اکسل</a>
            <a href="<?php echo esc_url(admin_url('admin.php?page=visitor-orders')); ?>" class="button">سفارشات</a>
        <?php visitor_admin_toolbar_close(); ?>
        <?php visitor_admin_table_wrap_open(); ?>
            <thead>
                <tr>
                    <th style="width:70px;">گالری</th>
                    <th>نام فروشگاه</th>
                    <th>تلفن</th>
                    <th>مسئول فروشگاه</th>
                    <th>ویزیتور</th>
                    <th>تاریخ</th>
                    <th>جزئیات</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($shops as $shop):
                $images = function_exists('visitor_decode_shop_images')
                    ? visitor_decode_shop_images($shop->images ?? [])
                    : [];
                $cover = !empty($images[0]) ? $images[0] : '';
            ?>
                <tr>
                    <td>
                        <?php if ($cover): ?>
                            <img src="<?php echo esc_url($cover); ?>" alt="" class="vp-shop-thumb" loading="lazy">
                        <?php else: ?>
                            <span class="description">—</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo esc_html($shop->shop_name); ?></td>
                    <td><?php echo esc_html($shop->shop_phone); ?></td>
                    <td><?php echo esc_html(trim($shop->manager_first_name . ' ' . $shop->manager_last_name)); ?></td>
                    <td><?php echo esc_html($shop->visitor_name); ?></td>
                    <td><?php echo esc_html(date_i18n('Y/m/d', strtotime($shop->created_at))); ?></td>
                    <td>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=visitor-shops&view=' . (int) $shop->id)); ?>" class="button button-small">مشاهده جزئیات</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        <?php visitor_admin_table_wrap_close(); ?>
    </div>
    <?php
}

/**
 * جزئیات یک فروشگاه (مشابه فرم ویزیتور در dashboard.php?edit=)
 */
function visitor_admin_shop_detail_page($shop_id) {
    global $wpdb;
    $shop_id = (int) $shop_id;
    $shop = $wpdb->get_row($wpdb->prepare(
        "SELECT s.*, v.fullname AS visitor_name, v.mobile AS visitor_mobile
         FROM {$wpdb->prefix}visitor_shops s
         LEFT JOIN {$wpdb->prefix}visitors v ON s.visitor_id = v.id
         WHERE s.id = %d",
        $shop_id
    ));

    if (!$shop) {
        echo '<div class="wrap visitor-panel-admin"><div class="notice notice-error"><p>فروشگاه یافت نشد.</p></div></div>';
        return;
    }

    $images = function_exists('visitor_decode_shop_images')
        ? visitor_decode_shop_images($shop->images ?? [])
        : [];

    $orders = $wpdb->get_results($wpdb->prepare(
        "SELECT o.*, p.post_title AS product_title
         FROM {$wpdb->prefix}visitor_orders o
         LEFT JOIN {$wpdb->posts} p ON o.product_id = p.ID
         WHERE o.shop_id = %d
         ORDER BY o.created_at DESC",
        $shop_id
    ));

    $map_url = '';
    if (!empty($shop->shop_lat) && !empty($shop->shop_lng)) {
        $map_url = 'https://www.openstreetmap.org/?mlat=' . esc_attr($shop->shop_lat) . '&mlon=' . esc_attr($shop->shop_lng) . '#map=17/' . esc_attr($shop->shop_lat) . '/' . esc_attr($shop->shop_lng);
    }

    $panel_edit = '';
    if (defined('VISITOR_PANEL_URL')) {
        $panel_edit = VISITOR_PANEL_URL . '/dashboard.php?edit=' . $shop_id;
    } else {
        $panel_edit = home_url('/visitor-panel/dashboard.php?edit=' . $shop_id);
    }
    ?>
    <div class="wrap visitor-panel-admin visitor-shop-detail-admin">
        <?php visitor_admin_page_header('جزئیات فروشگاه: ' . $shop->shop_name); ?>
        <?php visitor_admin_toolbar_open(); ?>
            <a href="<?php echo esc_url(admin_url('admin.php?page=visitor-shops')); ?>" class="button">بازگشت به لیست</a>
            <a href="<?php echo esc_url($panel_edit); ?>" class="button button-primary" target="_blank" rel="noopener">مشاهده در پنل ویزیتور</a>
        <?php visitor_admin_toolbar_close(); ?>

        <div class="vp-grid">
            <div class="vp-card">
                <h2>اطلاعات فروشگاه</h2>
                <p><strong>نام:</strong> <?php echo esc_html($shop->shop_name); ?></p>
                <p><strong>تلفن:</strong> <?php echo esc_html($shop->shop_phone ?: '—'); ?></p>
                <p><strong>آدرس:</strong><br><?php echo nl2br(esc_html($shop->shop_address ?: '—')); ?></p>
                <p><strong>ساعات حضور:</strong> <?php echo esc_html($shop->visit_hours ?: '—'); ?></p>
                <p><strong>تاریخ ثبت:</strong> <?php echo esc_html(date_i18n('Y/m/d H:i', strtotime($shop->created_at))); ?></p>
                <?php if ($map_url): ?>
                    <p><a href="<?php echo esc_url($map_url); ?>" target="_blank" rel="noopener">موقعیت روی نقشه</a>
                    (<?php echo esc_html($shop->shop_lat); ?>, <?php echo esc_html($shop->shop_lng); ?>)</p>
                <?php endif; ?>
            </div>

            <div class="vp-card">
                <h2>مسئول فروشگاه (همکار / خریدار)</h2>
                <p><strong>نام:</strong> <?php echo esc_html(trim($shop->manager_first_name . ' ' . $shop->manager_last_name) ?: '—'); ?></p>
                <p><strong>موبایل:</strong> <?php echo esc_html($shop->manager_mobile ?: '—'); ?></p>
                <?php if (!empty($shop->manager_user_id)): ?>
                    <p><strong>کاربر وردپرس:</strong> #<?php echo (int) $shop->manager_user_id; ?></p>
                <?php endif; ?>
                <p><strong>ویزیتور ثبت‌کننده:</strong> <?php echo esc_html($shop->visitor_name); ?> (<?php echo esc_html($shop->visitor_mobile); ?>)</p>
            </div>
        </div>

        <?php if (!empty($images)): ?>
            <?php visitor_admin_section_open('گالری تصاویر (' . count($images) . ')'); ?>
            <div class="visitor-admin-gallery" id="adminShopGallery" data-images="<?php echo esc_attr(wp_json_encode(array_values($images))); ?>">
                <?php foreach ($images as $idx => $img): ?>
                    <button type="button" class="visitor-admin-gallery-item" data-index="<?php echo (int) $idx; ?>">
                        <img src="<?php echo esc_url($img); ?>" alt="" loading="lazy">
                    </button>
                <?php endforeach; ?>
            </div>
            <div id="visitorAdminLb"><button type="button" class="close" onclick="this.parentElement.classList.remove('active')">&times;</button><img src="" alt=""></div>
            <?php visitor_admin_section_close(); ?>
            <script>
            (function(){
                var gal = document.getElementById('adminShopGallery');
                var lb = document.getElementById('visitorAdminLb');
                if (!gal || !lb) return;
                var imgs = [];
                try { imgs = JSON.parse(gal.getAttribute('data-images') || '[]'); } catch(e) {}
                gal.querySelectorAll('.visitor-admin-gallery-item').forEach(function(btn){
                    btn.addEventListener('click', function(){
                        var i = parseInt(btn.getAttribute('data-index'), 10) || 0;
                        lb.querySelector('img').src = imgs[i] || '';
                        lb.classList.add('active');
                    });
                });
            })();
            </script>
        <?php else: ?>
            <p class="description">گالری تصویری ثبت نشده است.</p>
        <?php endif; ?>

        <?php visitor_admin_section_open('سفارشات این فروشگاه'); ?>
        <?php visitor_admin_table_wrap_open(); ?>
            <thead>
                <tr><th>#</th><th>محصول</th><th>تعداد</th><th>وضعیت</th><th>ووکامرس</th><th>تاریخ</th></tr>
            </thead>
            <tbody>
            <?php if ($orders): foreach ($orders as $o): ?>
                <tr>
                    <td><?php echo (int) $o->id; ?></td>
                    <td><?php echo esc_html($o->product_title); ?></td>
                    <td><?php echo (int) $o->quantity; ?></td>
                    <td><?php echo esc_html(function_exists('visitor_order_status_label') ? visitor_order_status_label($o->status) : $o->status); ?></td>
                    <td><?php echo !empty($o->wc_order_id) ? '#' . (int) $o->wc_order_id : '—'; ?></td>
                    <td><?php echo esc_html(date_i18n('Y/m/d H:i', strtotime($o->created_at))); ?></td>
                </tr>
            <?php endforeach; else: ?>
                <tr><td colspan="6">سفارشی ثبت نشده.</td></tr>
            <?php endif; ?>
            </tbody>
        <?php visitor_admin_table_wrap_close(); ?>
        <?php visitor_admin_section_close(); ?>
    </div>
    <?php
}

// ---------- 5. صفحه سفارشات ----------
function visitor_orders_admin_page() {
    global $wpdb;
    $table_orders = $wpdb->prefix . 'visitor_orders';

    if (function_exists('visitor_orders_ensure_wc_order_id_column')) {
        visitor_orders_ensure_wc_order_id_column();
    }

    if (isset($_POST['sync_wc_orders']) && isset($_POST['sync_wc_nonce']) && wp_verify_nonce($_POST['sync_wc_nonce'], 'sync_wc_orders')) {
        $sync_all = !empty($_POST['sync_wc_all']);
        $result = function_exists('visitor_sync_orders_to_wc_bulk')
            ? visitor_sync_orders_to_wc_bulk(500, $sync_all)
            : ['message' => 'تابع همگام‌سازی یافت نشد.', 'synced' => 0, 'linked' => 0, 'failed' => 0, 'remaining' => 0, 'customers_fixed' => 0];
        wp_redirect(admin_url(
            'admin.php?page=visitor-orders&msg=wc_sync'
            . '&synced=' . (int) ($result['synced'] ?? 0)
            . '&linked=' . (int) ($result['linked'] ?? 0)
            . '&failed=' . (int) ($result['failed'] ?? 0)
            . '&remaining=' . (int) ($result['remaining'] ?? 0)
            . '&customers_fixed=' . (int) ($result['customers_fixed'] ?? 0)
        ));
        exit;
    }

    if (isset($_POST['repair_wc_customers']) && isset($_POST['repair_wc_nonce']) && wp_verify_nonce($_POST['repair_wc_nonce'], 'repair_wc_customers')) {
        $result = function_exists('visitor_repair_wc_order_customers_bulk')
            ? visitor_repair_wc_order_customers_bulk(200, true)
            : ['fixed' => 0, 'skipped' => 0, 'failed' => 0];
        wp_redirect(admin_url(
            'admin.php?page=visitor-orders&msg=wc_customers'
            . '&fixed=' . (int) ($result['fixed'] ?? 0)
            . '&skipped=' . (int) ($result['skipped'] ?? 0)
            . '&failed=' . (int) ($result['failed'] ?? 0)
        ));
        exit;
    }

    if (isset($_POST['admin_delete_order'], $_POST['order_id']) && wp_verify_nonce($_POST['order_nonce'], 'admin_order_' . $_POST['order_id'])) {
        $order_id = (int) $_POST['order_id'];
        $result = function_exists('visitor_delete_order')
            ? visitor_delete_order($order_id, ['is_admin' => true])
            : new WP_Error('missing', 'تابع حذف یافت نشد.');

        if (is_wp_error($result)) {
            wp_redirect(admin_url('admin.php?page=visitor-orders&msg=order_error&err=' . rawurlencode($result->get_error_message())));
        } else {
            wp_redirect(admin_url('admin.php?page=visitor-orders&msg=order_deleted'));
        }
        exit;
    }

    if (isset($_POST['admin_edit_order'], $_POST['order_id']) && wp_verify_nonce($_POST['order_nonce'], 'admin_order_' . $_POST['order_id'])) {
        $order_id = (int) $_POST['order_id'];
        $result = function_exists('visitor_update_order')
            ? visitor_update_order($order_id, [
                'product_id'  => (int) ($_POST['product_id'] ?? 0),
                'quantity'    => (int) ($_POST['quantity'] ?? 0),
                'shop_id'     => (int) ($_POST['shop_id'] ?? 0),
                'status'      => sanitize_text_field($_POST['order_status'] ?? 'pending'),
                'referred_to' => isset($_POST['refer_to']) ? sanitize_text_field($_POST['refer_to']) : '',
                'admin_note'  => isset($_POST['admin_note']) ? sanitize_textarea_field($_POST['admin_note']) : '',
            ], ['is_admin' => true])
            : new WP_Error('missing', 'تابع ویرایش یافت نشد.');

        if (is_wp_error($result)) {
            wp_redirect(admin_url('admin.php?page=visitor-orders&msg=order_error&err=' . rawurlencode($result->get_error_message())));
        } else {
            wp_redirect(admin_url('admin.php?page=visitor-orders&msg=order_updated'));
        }
        exit;
    }

    if (isset($_POST['admin_delete_batch'], $_POST['batch_group_key'], $_POST['batch_line_ids'])
        && wp_verify_nonce($_POST['batch_nonce'], 'admin_delete_batch_' . sanitize_text_field(wp_unslash($_POST['batch_group_key'])))) {
        $ids = array_values(array_filter(array_map('intval', (array) $_POST['batch_line_ids'])));
        $result = function_exists('visitor_delete_orders_batch')
            ? visitor_delete_orders_batch($ids, ['is_admin' => true])
            : new WP_Error('missing', 'تابع حذف یافت نشد.');

        if (is_wp_error($result)) {
            wp_redirect(admin_url('admin.php?page=visitor-orders&msg=order_error&err=' . rawurlencode($result->get_error_message())));
        } else {
            wp_redirect(admin_url('admin.php?page=visitor-orders&msg=order_deleted'));
        }
        exit;
    }

    if (isset($_GET['msg']) && $_GET['msg'] === 'order_updated') {
        echo '<div class="notice notice-success"><p>سفارش ویرایش شد (پنل ویزیتور و در صورت وجود، ووکامرس).</p></div>';
    }
    if (isset($_GET['msg']) && $_GET['msg'] === 'order_deleted') {
        echo '<div class="notice notice-success"><p>سفارش حذف شد.</p></div>';
    }
    if (isset($_GET['msg']) && $_GET['msg'] === 'order_error') {
        $err = isset($_GET['err']) ? sanitize_text_field(wp_unslash($_GET['err'])) : 'خطا در عملیات.';
        echo '<div class="notice notice-error"><p>' . esc_html($err) . '</p></div>';
    }

    if (isset($_GET['msg']) && $_GET['msg'] === 'wc_sync') {
        $synced = isset($_GET['synced']) ? (int) $_GET['synced'] : 0;
        $linked = isset($_GET['linked']) ? (int) $_GET['linked'] : 0;
        $failed = isset($_GET['failed']) ? (int) $_GET['failed'] : 0;
        $remaining = isset($_GET['remaining']) ? (int) $_GET['remaining'] : 0;
        $customers_fixed = isset($_GET['customers_fixed']) ? (int) $_GET['customers_fixed'] : 0;
        $class = ($remaining > 0 || $failed > 0) ? 'notice-warning' : 'notice-success';
        echo '<div class="notice ' . esc_attr($class) . '"><p>';
        echo esc_html($synced) . ' سفارش جدید در ووکامرس ساخته شد، ';
        echo esc_html($linked) . ' به سفارش موجود وصل شد، ';
        echo esc_html($failed) . ' ناموفق. ';
        echo 'باقی‌مانده بدون WC: ' . esc_html($remaining);
        if ($customers_fixed > 0) {
            echo ' — ' . esc_html($customers_fixed) . ' سفارش به حساب همکار (My Account) وصل شد.';
        }
        echo '</p></div>';
    }

    if (isset($_GET['msg']) && $_GET['msg'] === 'wc_customers') {
        $fixed = isset($_GET['fixed']) ? (int) $_GET['fixed'] : 0;
        $skipped = isset($_GET['skipped']) ? (int) $_GET['skipped'] : 0;
        $failed = isset($_GET['failed']) ? (int) $_GET['failed'] : 0;
        echo '<div class="notice notice-success"><p>';
        echo esc_html($fixed) . ' سفارش به حساب همکار وصل شد. ';
        echo esc_html($skipped) . ' از قبل درست بود یا بدون کاربر. ';
        echo esc_html($failed) . ' ناموفق.';
        echo '</p></div>';
    }

    $unsynced_wc = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table_orders} WHERE wc_order_id IS NULL OR wc_order_id = 0");

    $orders = $wpdb->get_results("
        SELECT o.*, s.shop_name, v.fullname as visitor_name, p.post_title as product_title
        FROM {$table_orders} o
        LEFT JOIN {$wpdb->prefix}visitor_shops s ON o.shop_id = s.id
        LEFT JOIN {$wpdb->prefix}visitors v ON o.visitor_id = v.id
        LEFT JOIN {$wpdb->posts} p ON o.product_id = p.ID
        ORDER BY o.created_at DESC
    ");

    $admin_shops = $wpdb->get_results(
        "SELECT id, shop_name FROM {$wpdb->prefix}visitor_shops ORDER BY shop_name ASC"
    );
    $admin_products = [];
    if (function_exists('wc_get_products')) {
        foreach (wc_get_products(['limit' => -1, 'status' => 'publish', 'return' => 'ids']) as $pid) {
            $admin_products[(int) $pid] = get_the_title($pid);
        }
    }

    $orders_footer_help = [];
    if ($unsynced_wc > 0) {
        $orders_footer_help[] = '<p>سفارش‌های ثبت‌شده قبل از فعال‌سازی WC در لیست ووکامرس نیستند. دکمه <strong>همگام‌سازی همه سفارش‌های قدیمی</strong> را بزنید تا با تاریخ و وضعیت اصلی در WooCommerce → Orders ظاهر شوند (مبدا: ویزیتور - نام).</p>';
    }
    $orders_footer_help[] = '<p>برای نمایش سفارش‌ها در <strong>حساب کاربری همکار</strong> (<code>/my-account/orders/</code>)، دکمه <strong>اتصال سفارش‌ها به حساب همکار</strong> را بزنید. نام و موبایل مسئول فروشگاه با پروفایل وردپرس همگام می‌شود.</p>';
    $orders_footer_help[] = '<p>برای <strong>ویرایش</strong> روی دکمه «ویرایش» کنار هر قلم بزنید؛ فرم در پنل زیر همان کارت باز می‌شود (فروشگاه، محصول، تعداد، وضعیت، یادداشت). حذف هر قلم یا کل سفارش چندقلمی از همان کارت انجام می‌شود.</p>';

    $order_groups = function_exists('visitor_group_order_rows')
        ? visitor_group_order_rows(is_array($orders) ? $orders : [])
        : [];
    $total_lines = is_array($orders) ? count($orders) : 0;
    ?>
    <div class="wrap visitor-panel-admin visitor-orders-admin">
        <?php visitor_admin_page_header(
            'پیگیری سفارشات ویزیتورها',
            esc_html((string) count($order_groups)) . ' ثبت · ' . esc_html((string) $total_lines) . ' قلم'
        ); ?>

        <div class="vo-toolbar vp-toolbar">
            <a href="<?php echo esc_url(admin_url('admin.php?page=visitor-export&type=orders')); ?>" class="button button-primary">خروجی اکسل</a>
            <a href="<?php echo esc_url(admin_url('admin.php?page=wc-orders')); ?>" class="button">سفارشات ووکامرس</a>
            <?php if ($unsynced_wc > 0): ?>
            <form method="post" class="vo-toolbar-form">
                <?php wp_nonce_field('sync_wc_orders', 'sync_wc_nonce'); ?>
                <button type="submit" name="sync_wc_orders" class="button button-primary"
                        onclick="return confirm('همه <?php echo esc_js($unsynced_wc); ?> سفارش قدیمی در ووکامرس ساخته شوند؟');">
                    همگام‌سازی قدیمی‌ها (<?php echo esc_html($unsynced_wc); ?>)
                </button>
                <input type="hidden" name="sync_wc_all" value="1">
            </form>
            <?php else: ?>
            <span class="vo-sync-ok">همه سفارش‌ها با ووکامرس همگام هستند.</span>
            <?php endif; ?>
            <form method="post" class="vo-toolbar-form">
                <?php wp_nonce_field('repair_wc_customers', 'repair_wc_nonce'); ?>
                <button type="submit" name="repair_wc_customers" class="button button-secondary"
                        onclick="return confirm('سفارش‌های WC به حساب همکار (مسئول فروشگاه) وصل شوند؟');">
                    اتصال به حساب همکار
                </button>
            </form>
        </div>

        <?php if (!empty($order_groups)): ?>
        <div class="vo-list">
            <?php foreach ($order_groups as $group):
                $status = $group['status'];
                $badge_class = 'vo-badge-mixed';
                if ($status !== 'mixed' && function_exists('visitor_order_status_badge_class')) {
                    $map = [
                        'status-badge status-pending'   => 'vo-badge-pending',
                        'status-badge status-confirmed' => 'vo-badge-confirmed',
                        'status-badge status-rejected'  => 'vo-badge-rejected',
                        'status-badge status-referred'  => 'vo-badge-referred',
                    ];
                    $bc = visitor_order_status_badge_class($status);
                    $badge_class = $map[$bc] ?? 'vo-badge-mixed';
                }
                $created_ts = !empty($group['created_at']) ? strtotime($group['created_at']) : false;
                ?>
            <article class="vo-card" id="vo-group-<?php echo esc_attr($group['group_key']); ?>">
                <header class="vo-card-head">
                    <div class="vo-card-title">
                        <span class="vo-ref"><?php echo esc_html($group['display_ref']); ?></span>
                        <div class="vo-meta">
                            <strong><?php echo esc_html($group['visitor_name']); ?></strong>
                            <span class="vo-meta-sep">·</span>
                            <?php echo esc_html($group['shop_name']); ?>
                            <?php if ($created_ts): ?>
                            <span class="vo-meta-sep">·</span>
                            <time datetime="<?php echo esc_attr(gmdate('c', $created_ts)); ?>"><?php echo esc_html(date_i18n('Y/m/d H:i', $created_ts)); ?></time>
                            <?php endif; ?>
                            <?php if ((int) $group['item_count'] > 1): ?>
                            <span class="vo-meta-sep">·</span><?php echo esc_html((int) $group['item_count']); ?> قلم
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="vo-card-side">
                        <span class="vo-badge <?php echo esc_attr($badge_class); ?>"><?php echo esc_html($group['status_label']); ?></span>
                        <?php if (!empty($group['line_total'])): ?>
                        <span class="vo-total">جمع: <?php echo esc_html(function_exists('visitor_format_price') ? visitor_format_price($group['line_total']) : number_format((float) $group['line_total'])); ?></span>
                        <?php endif; ?>
                        <?php foreach ($group['wc_order_ids'] as $wc_id): ?>
                        <a class="vo-wc-link" href="<?php echo esc_url(admin_url('admin.php?page=wc-orders&action=edit&id=' . (int) $wc_id)); ?>">WC #<?php echo esc_html($wc_id); ?></a>
                        <?php endforeach; ?>
                    </div>
                </header>

                <table class="vo-lines">
                    <thead>
                        <tr>
                            <th>شناسه</th>
                            <th>محصول</th>
                            <th>تعداد</th>
                            <th>وضعیت</th>
                            <th>مبلغ</th>
                            <th style="text-align:left;">عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($group['items'] as $item):
                        $oid = (int) $item['id'];
                        $line_status = (string) ($item['status'] ?? 'pending');
                        $line_badge = 'vo-badge-mixed';
                        if (function_exists('visitor_order_status_badge_class')) {
                            $map = [
                                'status-badge status-pending'   => 'vo-badge-pending',
                                'status-badge status-confirmed' => 'vo-badge-confirmed',
                                'status-badge status-rejected'  => 'vo-badge-rejected',
                                'status-badge status-referred'  => 'vo-badge-referred',
                            ];
                            $line_badge = $map[visitor_order_status_badge_class($line_status)] ?? 'vo-badge-mixed';
                        }
                        ?>
                        <tr>
                            <td><span class="vo-line-id">#<?php echo esc_html($oid); ?></span></td>
                            <td><?php echo esc_html($item['product_title'] ?? '—'); ?></td>
                            <td><?php echo esc_html((int) ($item['quantity'] ?? 0)); ?></td>
                            <td><span class="vo-badge <?php echo esc_attr($line_badge); ?>"><?php echo esc_html(function_exists('visitor_order_status_label') ? visitor_order_status_label($line_status) : $line_status); ?></span></td>
                            <td><?php echo esc_html(function_exists('visitor_format_price') ? visitor_format_price($item['line_total'] ?? 0) : ''); ?></td>
                            <td>
                                <div class="vo-line-actions">
                                    <button type="button" class="vo-btn vo-btn-edit" data-vo-edit="<?php echo esc_attr($oid); ?>">ویرایش</button>
                                    <form method="post" style="display:inline;margin:0;" onsubmit="return confirm('این قلم حذف و در ووکامرس لغو شود؟');">
                                        <?php wp_nonce_field('admin_order_' . $oid, 'order_nonce'); ?>
                                        <input type="hidden" name="order_id" value="<?php echo esc_attr($oid); ?>">
                                        <button type="submit" name="admin_delete_order" class="vo-btn vo-btn-danger">حذف</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>

                <?php foreach ($group['items'] as $item):
                    $oid = (int) $item['id'];
                    $edit_status = (string) ($item['status'] ?? 'pending');
                    ?>
                <div class="vo-edit-panel" id="vo-edit-<?php echo esc_attr($oid); ?>" hidden>
                    <h4>ویرایش قلم #<?php echo esc_html($oid); ?></h4>
                    <form method="post" class="vo-edit-grid">
                        <?php wp_nonce_field('admin_order_' . $oid, 'order_nonce'); ?>
                        <input type="hidden" name="order_id" value="<?php echo esc_attr($oid); ?>">
                        <div class="vo-field">
                            <label for="shop_id_<?php echo esc_attr($oid); ?>">فروشگاه</label>
                            <select name="shop_id" id="shop_id_<?php echo esc_attr($oid); ?>">
                                <?php foreach ($admin_shops as $sh): ?>
                                    <option value="<?php echo (int) $sh->id; ?>" <?php selected((int) ($item['shop_id'] ?? 0), (int) $sh->id); ?>><?php echo esc_html($sh->shop_name); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="vo-field">
                            <label for="product_id_<?php echo esc_attr($oid); ?>">محصول</label>
                            <select name="product_id" id="product_id_<?php echo esc_attr($oid); ?>">
                                <?php if (!empty($admin_products)): ?>
                                    <?php foreach ($admin_products as $pid => $ptitle): ?>
                                        <option value="<?php echo (int) $pid; ?>" <?php selected((int) ($item['product_id'] ?? 0), (int) $pid); ?>><?php echo esc_html($ptitle); ?></option>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <option value="<?php echo (int) ($item['product_id'] ?? 0); ?>"><?php echo esc_html($item['product_title'] ?? ''); ?></option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="vo-field">
                            <label for="qty_<?php echo esc_attr($oid); ?>">تعداد</label>
                            <input type="number" name="quantity" id="qty_<?php echo esc_attr($oid); ?>" min="1" value="<?php echo (int) ($item['quantity'] ?? 1); ?>">
                        </div>
                        <div class="vo-field">
                            <label for="status_<?php echo esc_attr($oid); ?>">وضعیت</label>
                            <select name="order_status" id="status_<?php echo esc_attr($oid); ?>">
                                <option value="pending" <?php selected($edit_status, 'pending'); ?>>در انتظار</option>
                                <option value="confirmed" <?php selected($edit_status, 'confirmed'); ?>>تأیید شده</option>
                                <option value="rejected" <?php selected($edit_status, 'rejected'); ?>>رد شده</option>
                                <option value="referred" <?php selected($edit_status, 'referred'); ?>>ارجاع شده</option>
                            </select>
                        </div>
                        <div class="vo-field">
                            <label for="refer_<?php echo esc_attr($oid); ?>">ارجاع به</label>
                            <input type="text" name="refer_to" id="refer_<?php echo esc_attr($oid); ?>" value="<?php echo esc_attr($item['referred_to'] ?? ''); ?>">
                        </div>
                        <div class="vo-field vo-field-wide">
                            <label for="note_<?php echo esc_attr($oid); ?>">یادداشت مدیر</label>
                            <textarea name="admin_note" id="note_<?php echo esc_attr($oid); ?>" rows="2"><?php echo esc_textarea($item['admin_note'] ?? ''); ?></textarea>
                        </div>
                        <div class="vo-edit-actions">
                            <button type="submit" name="admin_edit_order" class="button button-primary">ذخیره تغییرات</button>
                            <button type="button" class="button vo-btn-cancel" data-vo-cancel="<?php echo esc_attr($oid); ?>">انصراف</button>
                        </div>
                    </form>
                </div>
                <?php endforeach; ?>

                <?php if ((int) $group['item_count'] > 1): ?>
                <footer class="vo-card-foot">
                    <form method="post" onsubmit="return confirm('همه اقلام این ثبت حذف شوند؟');">
                        <?php wp_nonce_field('admin_delete_batch_' . $group['group_key'], 'batch_nonce'); ?>
                        <input type="hidden" name="batch_group_key" value="<?php echo esc_attr($group['group_key']); ?>">
                        <?php foreach ($group['line_ids'] as $lid): ?>
                            <input type="hidden" name="batch_line_ids[]" value="<?php echo esc_attr((int) $lid); ?>">
                        <?php endforeach; ?>
                        <button type="submit" name="admin_delete_batch" class="vo-btn vo-btn-danger">حذف کل این ثبت (<?php echo esc_html((int) $group['item_count']); ?> قلم)</button>
                    </form>
                </footer>
                <?php endif; ?>
            </article>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div class="vp-empty vo-empty">هیچ سفارشی یافت نشد.</div>
        <?php endif; ?>

        <script>
        (function() {
            var root = document.querySelector('.visitor-orders-admin');
            if (!root) return;

            function closeAllPanels() {
                root.querySelectorAll('.vo-edit-panel').forEach(function(panel) {
                    panel.classList.remove('is-open');
                    panel.setAttribute('hidden', 'hidden');
                });
            }

            root.querySelectorAll('[data-vo-edit]').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    var id = btn.getAttribute('data-vo-edit');
                    var panel = document.getElementById('vo-edit-' + id);
                    if (!panel) return;
                    var isOpen = panel.classList.contains('is-open');
                    closeAllPanels();
                    if (!isOpen) {
                        panel.classList.add('is-open');
                        panel.removeAttribute('hidden');
                        panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                    }
                });
            });

            root.querySelectorAll('[data-vo-cancel]').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    var id = btn.getAttribute('data-vo-cancel');
                    var panel = document.getElementById('vo-edit-' + id);
                    if (panel) {
                        panel.classList.remove('is-open');
                        panel.setAttribute('hidden', 'hidden');
                    }
                });
            });

            <?php if (isset($_GET['edit_order'])): ?>
            var openId = <?php echo (int) $_GET['edit_order']; ?>;
            var autoPanel = document.getElementById('vo-edit-' + openId);
            if (autoPanel) {
                autoPanel.classList.add('is-open');
                autoPanel.removeAttribute('hidden');
            }
            <?php endif; ?>
        })();
        </script>

        <?php visitor_admin_render_footer_help($orders_footer_help); ?>
    </div>
    <?php
}

// ---------- 6. صفحه آمار و رتبه‌بندی ----------
function visitor_stats_page() {
    global $wpdb;
    $sms_notice = '';

    if (isset($_POST['send_incentive_sms']) && isset($_POST['incentive_nonce']) && wp_verify_nonce($_POST['incentive_nonce'], 'send_incentive_sms')) {
        $mobile = function_exists('melipayamak_normalize_mobile')
            ? melipayamak_normalize_mobile(sanitize_text_field($_POST['incentive_mobile']))
            : sanitize_text_field($_POST['incentive_mobile']);
        $name = sanitize_text_field($_POST['incentive_name'] ?? '');
        $extra = sanitize_text_field($_POST['incentive_extra'] ?? '');

        if (function_exists('send_incentive_sms') && melipayamak_is_valid_mobile($mobile)) {
            $result = send_incentive_sms($mobile, $name, $extra);
            $sms_notice = ($result === true)
                ? '<div class="notice notice-success"><p>پیامک تشویقی ارسال شد.</p></div>'
                : '<div class="notice notice-error"><p>' . esc_html($result) . '</p></div>';
        } else {
            $sms_notice = '<div class="notice notice-error"><p>شماره موبایل معتبر نیست.</p></div>';
        }
    }

    $stats = $wpdb->get_results("
        SELECT 
            v.id,
            v.fullname,
            v.mobile,
            COUNT(DISTINCT o.id) AS total_orders,
            COALESCE(SUM(o.quantity * CAST(pm.meta_value AS DECIMAL(15,2))), 0) AS total_sales,
            COUNT(DISTINCT s.id) AS total_shops,
            COALESCE(AVG(o.quantity * CAST(pm.meta_value AS DECIMAL(15,2))), 0) AS avg_order_value
        FROM {$wpdb->prefix}visitors v
        LEFT JOIN {$wpdb->prefix}visitor_orders o ON v.id = o.visitor_id
        LEFT JOIN {$wpdb->prefix}visitor_shops s ON v.id = s.visitor_id
        LEFT JOIN {$wpdb->postmeta} pm ON o.product_id = pm.post_id AND pm.meta_key = '_price'
        GROUP BY v.id
        ORDER BY total_sales DESC
    ");

    $sorted_by_orders = $stats;
    usort($sorted_by_orders, function ($a, $b) {
        return $b->total_orders - $a->total_orders;
    });

    $top_shops = function_exists('visitor_get_top_shops') ? visitor_get_top_shops(10, 'orders') : [];
    $top_buyers = function_exists('visitor_get_top_buyers') ? visitor_get_top_buyers(10) : [];

    $stats_footer_help = [
        '<p><strong>شورتکد برای صفحات سایت:</strong></p>'
        . '<code>[visitor_top_shops limit="5" order="orders" title="برترین فروشگاه‌ها"]</code><br>'
        . '<code>[visitor_top_visitors limit="5" title="برترین ویزیتورها"]</code>'
        . '<p>پترن تشویقی را در <a href="' . esc_url(admin_url('admin.php?page=melipayamak-settings')) . '">تنظیمات پیامک</a> تنظیم کنید (متغیر {0} = نام).</p>',
    ];
    ?>
    <div class="wrap visitor-panel-admin">
        <?php visitor_admin_page_header('آمار و رتبه‌بندی'); ?>
        <?php echo wp_kses_post($sms_notice); ?>
        <?php visitor_admin_toolbar_open(); ?>
            <a href="<?php echo esc_url(admin_url('admin.php?page=visitor-export&type=stats')); ?>" class="button button-primary">خروجی اکسل</a>
            <a href="<?php echo esc_url(admin_url('admin.php?page=visitor-shops')); ?>" class="button">فروشگاه‌ها</a>
            <a href="<?php echo esc_url(admin_url('admin.php?page=visitor-orders')); ?>" class="button">سفارشات</a>
        <?php visitor_admin_toolbar_close(); ?>

        <?php visitor_admin_form_card_open('ارسال پیامک تشویقی'); ?>
        <form method="post">
            <?php wp_nonce_field('send_incentive_sms', 'incentive_nonce'); ?>
            <p>
                <label>نام گیرنده</label><br>
                <input type="text" name="incentive_name" class="regular-text" required>
            </p>
            <p>
                <label>موبایل</label><br>
                <input type="tel" name="incentive_mobile" class="regular-text" placeholder="09123456789" required>
            </p>
            <p>
                <label>یادداشت کوتاه (اختیاری، داخل {0})</label><br>
                <input type="text" name="incentive_extra" class="regular-text" placeholder="رتبه ۱ فروش">
            </p>
            <?php submit_button('ارسال پیامک تشویقی', 'secondary', 'send_incentive_sms'); ?>
        </form>
        <?php visitor_admin_form_card_close(); ?>

        <?php visitor_admin_section_open('برترین فروشگاه‌ها'); ?>
        <?php visitor_admin_table_wrap_open(); ?>
            <thead><tr><th>رتبه</th><th>فروشگاه</th><th>سفارش</th><th>فروش</th><th>ویزیتور</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($top_shops as $i => $shop): ?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td><?php echo esc_html($shop->shop_name); ?></td>
                    <td><?php echo (int) $shop->order_count; ?></td>
                    <td><?php echo esc_html(number_format((float) $shop->total_sales)); ?></td>
                    <td><?php echo esc_html($shop->visitor_name); ?></td>
                    <td><a href="<?php echo esc_url(admin_url('admin.php?page=visitor-shops&view=' . (int) $shop->id)); ?>">جزئیات</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        <?php visitor_admin_table_wrap_close(); ?>
        <?php visitor_admin_section_close(); ?>

        <?php visitor_admin_section_open('برترین خریداران (مسئول فروشگاه)'); ?>
        <?php visitor_admin_table_wrap_open(); ?>
            <thead><tr><th>رتبه</th><th>نام</th><th>موبایل</th><th>سفارش WC</th><th>خرید</th></tr></thead>
            <tbody>
            <?php foreach ($top_buyers as $i => $buyer): ?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td><?php echo esc_html($buyer->name); ?></td>
                    <td><?php echo esc_html($buyer->mobile ?: '—'); ?></td>
                    <td><?php echo (int) $buyer->order_count; ?></td>
                    <td><?php echo esc_html(number_format((float) $buyer->total_spent)); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        <?php visitor_admin_table_wrap_close(); ?>
        <?php visitor_admin_section_close(); ?>

        <?php visitor_admin_section_open('برترین ویزیتورها'); ?>
        <p class="description" style="margin-bottom:12px;">شاخص‌ها: فروش کل، تعداد سفارش، میانگین ارزش سفارش، تعداد فروشگاه</p>
        <?php visitor_admin_table_wrap_open('stats-table'); ?>
            <thead>
                <tr>
                    <th>رتبه فروش</th>
                    <th>رتبه سفارش</th>
                    <th>نام</th>
                    <th>موبایل</th>
                    <th>فروش کل</th>
                    <th>تعداد سفارش</th>
                    <th>میانگین ارزش</th>
                    <th>فروشگاه</th>
                    <th>SMS</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $rank_sales = 1;
            $prev_sales = null;
            foreach ($stats as $index => $row):
                if ($prev_sales !== null && $row->total_sales < $prev_sales) {
                    $rank_sales = $index + 1;
                }
                $order_rank = 1;
                foreach ($sorted_by_orders as $j => $r) {
                    if ($r->id == $row->id) {
                        $order_rank = $j + 1;
                        break;
                    }
                }
            ?>
                <tr>
                    <td><?php echo esc_html($rank_sales); ?></td>
                    <td><?php echo esc_html($order_rank); ?></td>
                    <td><?php echo esc_html($row->fullname); ?></td>
                    <td><?php echo esc_html($row->mobile); ?></td>
                    <td><?php echo esc_html(number_format($row->total_sales ?: 0)); ?></td>
                    <td><?php echo (int) $row->total_orders; ?></td>
                    <td><?php echo esc_html(number_format($row->avg_order_value ?: 0)); ?></td>
                    <td><?php echo (int) $row->total_shops; ?></td>
                    <td>
                        <form method="post" style="display:inline;">
                            <?php wp_nonce_field('send_incentive_sms', 'incentive_nonce'); ?>
                            <input type="hidden" name="incentive_name" value="<?php echo esc_attr($row->fullname); ?>">
                            <input type="hidden" name="incentive_mobile" value="<?php echo esc_attr($row->mobile); ?>">
                            <input type="hidden" name="incentive_extra" value="رتبه <?php echo esc_attr($rank_sales); ?>">
                            <button type="submit" name="send_incentive_sms" class="button button-small">تشویق</button>
                        </form>
                    </td>
                </tr>
            <?php
                $prev_sales = $row->total_sales;
            endforeach;
            ?>
            </tbody>
        <?php visitor_admin_table_wrap_close(); ?>
        <?php visitor_admin_section_close(); ?>

        <?php visitor_admin_render_footer_help($stats_footer_help); ?>
    </div>
    <?php
}

// ---------- 7. تنظیمات پیامک پترن ----------
        // ---------- 7. تنظیمات پیامک (با قابلیت تست از طریق وب سرویس SOAP) ----------
function melipayamak_settings_page() {
    $test_result = '';

    // ذخیره تنظیمات
    if (isset($_POST['save_sms_settings']) && isset($_POST['sms_nonce']) && wp_verify_nonce($_POST['sms_nonce'], 'save_sms')) {
        update_option('melipayamak_username', sanitize_text_field($_POST['username']));
        update_option('melipayamak_password', sanitize_text_field($_POST['password']));
        update_option('melipayamak_body_id', intval($_POST['body_id']));
        update_option('melipayamak_test_body_id', intval($_POST['test_body_id']));
        update_option('melipayamak_contacts_enabled', isset($_POST['contacts_enabled']) ? 'yes' : 'no');
        update_option('melipayamak_contact_group_id', sanitize_text_field($_POST['contact_group_id'] ?? ''));
        update_option('melipayamak_incentive_body_id', intval($_POST['incentive_body_id'] ?? 0));

        wp_redirect(admin_url('admin.php?page=melipayamak-settings&msg=saved'));
        exit;
    }

    // ارسال پیام تست
    if (isset($_POST['test_sms']) && isset($_POST['test_nonce']) && wp_verify_nonce($_POST['test_nonce'], 'test_sms')) {
        $mobile = function_exists('melipayamak_normalize_mobile')
            ? melipayamak_normalize_mobile(sanitize_text_field($_POST['test_mobile']))
            : sanitize_text_field($_POST['test_mobile']);

        if (empty($mobile)) {
            $test_result = '<div class="notice notice-error"><p>شماره موبایل تست را وارد کنید.</p></div>';
        } elseif (function_exists('melipayamak_is_valid_mobile') && !melipayamak_is_valid_mobile($mobile)) {
            $test_result = '<div class="notice notice-error"><p>شماره موبایل معتبر نیست (فرمت: 09123456789).</p></div>';
        } else {
            $result = send_test_pattern_sms_from_settings($mobile);

            if ($result === true) {
                $test_result = '<div class="notice notice-success"><p>پیام تست با موفقیت ارسال شد.</p></div>';
            } else {
                $test_result = '<div class="notice notice-error"><p>ارسال ناموفق: ' . esc_html($result) . '</p></div>';
            }
        }
    }

    if (isset($_GET['msg']) && $_GET['msg'] === 'saved') {
        echo '<div class="notice notice-success"><p>تنظیمات ذخیره شد.</p></div>';
    }
    ?>
    <div class="wrap visitor-panel-admin">
        <?php visitor_admin_page_header('تنظیمات پیامک', 'ملی‌پیامک — SOAP'); ?>

        <?php visitor_admin_form_card_open('اتصال API', true); ?>
        <form method="post">
            <?php wp_nonce_field('save_sms', 'sms_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="username">نام کاربری (API)</label></th>
                    <td>
                        <input type="text" id="username" name="username"
                               value="<?php echo esc_attr(get_option('melipayamak_username')); ?>"
                               class="regular-text" required>
                    </td>
                </tr>

                <tr>
                    <th><label for="password">رمز عبور (API)</label></th>
                    <td>
                        <input type="password" id="password" name="password"
                               value="<?php echo esc_attr(get_option('melipayamak_password')); ?>"
                               class="regular-text" required>
                    </td>
                </tr>

                <tr>
                    <th><label for="body_id">Body ID / کد الگو</label></th>
                    <td>
                        <input type="number" id="body_id" name="body_id"
                               value="<?php echo esc_attr(get_option('melipayamak_body_id')); ?>"
                               class="regular-text" required>
                    </td>
                </tr>

                <tr>
                    <th><label for="test_body_id">Body ID پترن تست</label></th>
                    <td>
                        <input type="number" id="test_body_id" name="test_body_id"
                               value="<?php echo esc_attr(get_option('melipayamak_test_body_id')); ?>"
                               class="regular-text" required>
                    </td>
                </tr>

                <tr>
                    <th>دفترچه مخاطبین</th>
                    <td>
                        <label>
                            <input type="checkbox" name="contacts_enabled" value="1"
                                <?php checked(get_option('melipayamak_contacts_enabled'), 'yes'); ?>>
                            افزودن خودکار مسئول فروشگاه به دفترچه ملی‌پیامک
                        </label>
                        <p class="description" style="margin-top:8px;">
                            <label for="contact_group_id">شناسه گروه دفترچه (groupIds):</label><br>
                            <input type="text" id="contact_group_id" name="contact_group_id"
                                   value="<?php echo esc_attr(get_option('melipayamak_contact_group_id')); ?>"
                                   class="regular-text" placeholder="مثال: 12345">
                            <br>از پنل ملی‌پیامک → دفترچه تلفن → گروه‌ها.
                            <a href="https://www.melipayamak.com/api/addcontact2/" target="_blank" rel="noopener">مستندات AddContact2</a>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th><label for="incentive_body_id">Body ID پترن تشویقی</label></th>
                    <td>
                        <input type="number" id="incentive_body_id" name="incentive_body_id"
                               value="<?php echo esc_attr(get_option('melipayamak_incentive_body_id')); ?>"
                               class="regular-text">
                        <p class="description">
                            پترن کوتاه با یک متغیر <code>{0}</code> = نام (مثال: «{0} عزیز، عملکرد عالی داشتید»).
                            از صفحه <a href="<?php echo esc_url(admin_url('admin.php?page=visitor-stats')); ?>">آمار و رتبه‌بندی</a> ارسال می‌شود.
                        </p>
                    </td>
                </tr>
            </table>

            <?php submit_button('ذخیره تنظیمات', 'primary', 'save_sms_settings'); ?>
        </form>
        <?php visitor_admin_form_card_close(); ?>

        <?php visitor_admin_form_card_open('ارسال پیامک تست'); ?>
        <form method="post">
            <?php wp_nonce_field('test_sms', 'test_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="test_mobile">شماره موبایل گیرنده تست</label></th>
                    <td>
                        <input type="tel" id="test_mobile" name="test_mobile"
                               placeholder="مثال: 09123456789" required>
                    </td>
                </tr>
            </table>
            <?php submit_button('ارسال پیامک تست', 'secondary', 'test_sms'); ?>
        </form>
        <?php visitor_admin_form_card_close(); ?>

        <?php echo wp_kses_post($test_result); ?>
    </div>
    <?php
}

// ---------- 8. تنظیمات ذخیره تصاویر (هاست / URL دانلود) ----------
function visitor_upload_settings_page() {
    if (!function_exists('visitor_apply_upload_settings')) {
        $upload_settings = WP_CONTENT_DIR . '/../visitor-panel/includes/upload-settings.php';
        if (!file_exists($upload_settings)) {
            $upload_settings = ABSPATH . 'visitor-panel/includes/upload-settings.php';
        }
        if (file_exists($upload_settings)) {
            require_once $upload_settings;
        }
    }

    if (isset($_POST['save_upload_settings']) && isset($_POST['upload_nonce']) && wp_verify_nonce($_POST['upload_nonce'], 'save_upload_settings')) {
        visitor_save_upload_settings_from_post($_POST);
        wp_redirect(admin_url('admin.php?page=visitor-upload-settings&msg=saved'));
        exit;
    }

    if (isset($_GET['msg']) && $_GET['msg'] === 'saved') {
        echo '<div class="notice notice-success is-dismissible"><p>تنظیمات ذخیره تصاویر ذخیره شد.</p></div>';
    }

    $defaults = visitor_get_upload_defaults();
    $status = visitor_get_upload_status();

    $upload_dir = get_option('visitor_upload_dir', $defaults['upload_dir']);
    $upload_url = get_option('visitor_upload_url', '');
    $panel_url  = get_option('visitor_panel_url', '');
    $max_images = (int) get_option('visitor_max_images', $defaults['max_images']);
    $max_mb     = (float) get_option('visitor_max_file_size_mb', $defaults['max_file_size_mb']);
    $allowed    = get_option('visitor_allowed_extensions', $defaults['allowed_extensions']);

    if ($upload_url === '') {
        $upload_url = home_url('/visitor-panel/visitor-uploads');
    }
    if ($panel_url === '') {
        $panel_url = home_url('/visitor-panel');
    }

    $free_space_label = 'در این هاست در دسترس نیست';
    if ($status['free_space'] !== false && $status['free_space'] !== null && is_numeric($status['free_space'])) {
        $free_space_label = size_format((float) $status['free_space'], 2);
    }

    $upload_footer_help = [
        '<p><strong>فیلدهای فرم:</strong> مسیر فیزیکی = پوشه ذخیره روی سرور؛ URL دانلود = آدرس عمومی همان پوشه؛ URL پنل = آدرس پایه پنل ویزیتور.</p>',
        '<p><strong>هاست جدا (CDN / زیردامنه):</strong></p>'
        . '<ol style="margin-right:20px;">'
        . '<li>روی هاست/سرور دوم پوشه آپلود بسازید.</li>'
        . '<li>زیردامنه یا CDN تعریف کنید.</li>'
        . '<li><strong>مسیر فیزیکی</strong> و <strong>URL دانلود</strong> را مطابق همان سرور پر کنید.</li>'
        . '</ol>'
        . '<p>فایل‌ها با PHP روی سرور پنل ذخیره می‌شوند.</p>',
        '<p><strong>هاست محلی:</strong> پوشه <code>visitor-uploads</code> باید قابل نوشتن باشد. اگر تصویر دیده نمی‌شود، URL دانلود را با مسیر فیزیکی هماهنگ کنید.</p>',
    ];
    ?>
    <div class="wrap visitor-panel-admin">
        <?php visitor_admin_page_header('تنظیمات ذخیره تصاویر'); ?>

        <?php visitor_admin_form_card_open('مسیر و محدودیت‌ها', true); ?>
        <form method="post">
            <?php wp_nonce_field('save_upload_settings', 'upload_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="upload_dir">مسیر فیزیکی روی هاست</label></th>
                    <td>
                        <input type="text" id="upload_dir" name="upload_dir" class="large-text" dir="ltr"
                               value="<?php echo esc_attr($upload_dir); ?>"
                               placeholder="/home/username/public_html/visitor-panel/visitor-uploads">
                    </td>
                </tr>
                <tr>
                    <th><label for="upload_url">آدرس اینترنتی تصاویر (URL دانلود)</label></th>
                    <td>
                        <input type="url" id="upload_url" name="upload_url" class="large-text" dir="ltr"
                               value="<?php echo esc_attr($upload_url); ?>"
                               placeholder="https://example.com/visitor-panel/visitor-uploads">
                    </td>
                </tr>
                <tr>
                    <th><label for="panel_url">آدرس پنل ویزیتور</label></th>
                    <td>
                        <input type="url" id="panel_url" name="panel_url" class="large-text" dir="ltr"
                               value="<?php echo esc_attr($panel_url); ?>"
                               placeholder="https://example.com/visitor-panel">
                    </td>
                </tr>
                <tr>
                    <th><label for="max_images">حداکثر تصویر هر فروشگاه</label></th>
                    <td>
                        <input type="number" id="max_images" name="max_images" min="1" max="20"
                               value="<?php echo esc_attr($max_images); ?>" class="small-text">
                    </td>
                </tr>
                <tr>
                    <th><label for="max_file_size_mb">حداکثر حجم هر فایل (مگابایت)</label></th>
                    <td>
                        <input type="number" id="max_file_size_mb" name="max_file_size_mb" min="0.5" max="50" step="0.5"
                               value="<?php echo esc_attr($max_mb); ?>" class="small-text">
                    </td>
                </tr>
                <tr>
                    <th><label for="allowed_extensions">پسوندهای مجاز</label></th>
                    <td>
                        <input type="text" id="allowed_extensions" name="allowed_extensions" class="regular-text" dir="ltr"
                               value="<?php echo esc_attr($allowed); ?>"
                               placeholder="jpg,jpeg,png,webp">
                    </td>
                </tr>
            </table>

            <?php submit_button('ذخیره تنظیمات', 'primary', 'save_upload_settings'); ?>
        </form>
        <?php visitor_admin_form_card_close(); ?>

        <?php visitor_admin_section_open('وضعیت فعلی'); ?>
        <?php visitor_admin_table_wrap_open(); ?>
            <tbody>
                <tr><th scope="row">پوشه</th><td><code><?php echo esc_html($status['upload_dir']); ?></code>
                    — <?php echo $status['dir_exists'] ? '<span class="vp-status vp-status-active">موجود</span>' : '<span class="vp-status vp-status-inactive">وجود ندارد</span>'; ?>
                    — <?php echo $status['dir_writable'] ? '<span class="vp-status vp-status-active">قابل نوشتن</span>' : '<span class="vp-status vp-status-inactive">غیرقابل نوشتن</span>'; ?></td></tr>
                <tr><th scope="row">URL دانلود</th><td><code><?php echo esc_html($status['upload_url']); ?></code></td></tr>
                <tr><th scope="row">URL پنل</th><td><code><?php echo esc_html($status['panel_url']); ?></code></td></tr>
                <tr><th scope="row">تعداد فایل</th><td><?php echo (int) $status['file_count']; ?></td></tr>
                <tr><th scope="row">فضای خالی</th><td><?php echo esc_html($free_space_label); ?></td></tr>
            </tbody>
        <?php visitor_admin_table_wrap_close(); ?>
        <?php visitor_admin_section_close(); ?>

        <?php visitor_admin_render_footer_help($upload_footer_help); ?>
    </div>
    <?php
}
