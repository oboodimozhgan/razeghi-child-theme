<?php
// جلوگیری از دسترسی مستقیم به فایل
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ۱. ثبت فایل‌های Swiper (به صورت استاندارد وردپرس)
add_action( 'wp_enqueue_scripts', 'pro_tax_carousel_register_assets' );
function pro_tax_carousel_register_assets() {
    wp_register_style( 'swiper-css', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css', array(), '11.0.0' );
    wp_register_script( 'swiper-js', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js', array(), '11.0.0', true );
}

// ۲. تابع اصلی شورت‌کد
function render_pro_taxonomy_carousel( $atts ) {
    // تنظیمات پیش‌فرض شورت‌کد
    $atts = shortcode_atts( array(
        'taxonomy' => 'car_system', // تاکسونومی پیش‌فرض
        'limit'    => 10,           // محدودیت تعداد پیش‌فرض
    ), $atts, 'pro_tax_carousel' );

    $taxonomy = sanitize_text_field( $atts['taxonomy'] );
    $limit    = intval( $atts['limit'] );

    // لود کردن فایل‌های Swiper فقط زمانی که شورت‌کد استفاده شده است
    wp_enqueue_style( 'swiper-css' );
    wp_enqueue_script( 'swiper-js' );

    // ۳. سیستم کش (Transient) برای جلوگیری از فشار به دیتابیس
    $transient_key = 'pro_tax_carousel_data_' . $taxonomy . '_' . $limit;
    $terms = get_transient( $transient_key );

    if ( false === $terms ) {
        // دریافت دسته‌بندی‌ها
        $terms = get_terms( array(
            'taxonomy'   => $taxonomy,
            'hide_empty' => false,
            'number'     => $limit > 0 ? $limit : 0, // اعمال محدودیت تعداد
        ) );

        if ( ! is_wp_error( $terms ) ) {
            set_transient( $transient_key, $terms, 12 * HOUR_IN_SECONDS ); // کش برای ۱۲ ساعت
        }
    }

    // اگر دسته‌بندی یافت نشد
    if ( is_wp_error( $terms ) || empty( $terms ) ) {
        return '<p class="pro-tax-not-found" style="text-align:center; padding: 20px;">' . esc_html__( 'دسته بندی یافت نشد.', 'text-domain' ) . '</p>';
    }

    // ایجاد یک ID یکتا برای اسلایدر
    $slider_id = uniqid( 'pro-tax-slider-' );

    // شروع بافر خروجی
    ob_start();
    ?>

    <style>
        /* استایل‌های پایه و همچنین جلوگیری از پرش صفحه (FOUC) قبل از لود JS */
        .pro-tax-carousel-wrapper { max-width: 1200px; margin: 40px auto; padding: 0 20px; direction: rtl; }
        
        #<?php echo esc_attr( $slider_id ); ?> { overflow: hidden; padding-bottom: 30px; /* فضای پیجینیشن */ }
        #<?php echo esc_attr( $slider_id ); ?> .swiper-wrapper { display: flex !important; flex-wrap: nowrap !important; }
        #<?php echo esc_attr( $slider_id ); ?> .swiper-slide { flex-shrink: 0 !important; width: 12.5% !important; /* پیش‌فرض دسکتاپ 8 آیتم */ }
        
        .pro-tax-item-link { display: block; text-decoration: none; color: #333; background: transparent; padding: 10px; transition: all 0.3s ease; text-align: center; }
        .pro-tax-item-link:hover { transform: translateY(-5px); }
        .pro-tax-image-wrapper { height: 100px; display: flex; align-items: center; justify-content: center; margin-bottom: 15px; }
        .pro-tax-img { max-height: 100%; max-width: 100%; object-fit: contain; }
        .pro-tax-title { font-size: 15px; font-weight: bold; margin: 0; line-height: 1.4; }
        .no-image-placeholder { width: 80px; height: 80px; background: #f0f0f0; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #aaa; margin: 0 auto; }

        /* ریسپانسیو CSS برای FOUC */
        @media (max-width: 1200px) { #<?php echo esc_attr( $slider_id ); ?> .swiper-slide { width: 25% !important; } } /* 4 Items */
        @media (max-width: 992px) { #<?php echo esc_attr( $slider_id ); ?> .swiper-slide { width: 33.33% !important; } } /* 3 Items */
        @media (max-width: 768px) { #<?php echo esc_attr( $slider_id ); ?> .swiper-slide { width: 50% !important; } } /* 2 Items */
    </style>

    <div class="pro-tax-carousel-wrapper">
        <div id="<?php echo esc_attr( $slider_id ); ?>" class="swiper pro-tax-slider">
            <div class="swiper-wrapper">
                <?php foreach ( $terms as $term ) : 
                    $term_link = get_term_link( $term );
                    if ( is_wp_error( $term_link ) ) {
                        continue;
                    }

                    // بررسی وجود تصویر برای دسته‌بندی
                    $image_id  = get_term_meta( $term->term_id, 'taxonomy_image_id', true );
                    $image_url = $image_id ? wp_get_attachment_url( $image_id ) : false;
                    ?>
                    
                    <div class="swiper-slide">
                        <a href="<?php echo esc_url( $term_link ); ?>" class="pro-tax-item-link" title="<?php echo esc_attr( $term->name ); ?>">
                            <div class="pro-tax-image-wrapper">
                                <?php if ( $image_url ) : ?>
                                    <img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $term->name ); ?>" class="pro-tax-img" loading="lazy" width="100" height="100" />
                                <?php else : ?>
                                    <!-- نمایش یک آیکون/کادر ساده اگر عکسی وجود نداشت -->
                                    <div class="no-image-placeholder">
                                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <h3 class="pro-tax-title"><?php echo esc_html( $term->name ); ?></h3>
                        </a>
                    </div>

                <?php endforeach; ?>
            </div>
            
            <div class="swiper-pagination" style="bottom: 0px;"></div>
        </div>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var swiper_<?php echo str_replace('-', '_', $slider_id); ?> = null;
            
            if (typeof Swiper !== 'undefined') {
                swiper_<?php echo str_replace('-', '_', $slider_id); ?> = new Swiper('#<?php echo esc_js( $slider_id ); ?>', {
                    slidesPerView: 2, 
                    spaceBetween: 15,
                    loop: false, 
                    grabCursor: true,
                    autoplay: {
                        delay: 3000,
                        disableOnInteraction: false,
                    },
                    pagination: {
                        el: '#<?php echo esc_js( $slider_id ); ?> .swiper-pagination',
                        clickable: true,
                    },
                    breakpoints: {
                        480: { slidesPerView: 2, spaceBetween: 20 },
                        768: { slidesPerView: 3, spaceBetween: 20 },
                        992: { slidesPerView: 4, spaceBetween: 25 },
                        1200: { slidesPerView: 8, spaceBetween: 30 }
                    }
                });
            }
        });
    </script>

    <?php
    return ob_get_clean();
}
add_shortcode( 'pro_tax_carousel', 'render_pro_taxonomy_carousel' );

// ۴. پاک کردن خودکار کش در صورت ذخیره، ویرایش یا حذف دسته‌بندی
add_action( 'saved_term', 'pro_tax_carousel_clear_transient', 10, 3 );
add_action( 'delete_term', 'pro_tax_carousel_clear_transient', 10, 3 );
function pro_tax_carousel_clear_transient( $term_id, $tt_id, $taxonomy ) {
    global $wpdb;
    // پاک کردن کش فقط برای همین تکسونومی
    $wpdb->query( $wpdb->prepare( "DELETE FROM $wpdb->options WHERE option_name LIKE %s", '_transient_pro_tax_carousel_data_' . $taxonomy . '%' ) );
    $wpdb->query( $wpdb->prepare( "DELETE FROM $wpdb->options WHERE option_name LIKE %s", '_transient_timeout_pro_tax_carousel_data_' . $taxonomy . '%' ) );
}
