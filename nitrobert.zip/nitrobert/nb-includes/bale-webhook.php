<?php
/**
 * Webhook برای ربات بله (Bale) - تایید کاربران
 * مسیر: https://your-site.com/bale-webhook.php
 */

// بارگذاری وردپرس
//require_once('wp-load.php');//
require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))) . '/wp-load.php');

// ============================================
// 1. تنظیمات ربات بله
// ============================================

function get_bale_settings() {
    return array(
        'bot_token' => '1234567890:ABCDEFGHIJKLMNOPQRSTUVWXYZ', // توکن ربات بله
        'admin_chat_ids' => array(
            '123456789',  // چت آیدی ادمین اول
            '987654321',  // چت آیدی ادمین دوم
        ),
    );
}

// ============================================
// 2. توابع کمکی
// ============================================

// تابع تشخیص خزنده‌ها
function my_is_robot_bale() {
    $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    $robots = array(
        'Googlebot', 'bingbot', 'Slurp', 'DuckDuckBot', 'Baiduspider',
        'YandexBot', 'Sogou', 'Exabot', 'facebookexternalhit', 'Facebot',
        'Twitterbot', 'Applebot', 'AhrefsBot', 'SemrushBot', 'MJ12bot'
    );
    foreach ($robots as $robot) {
        if (stripos($user_agent, $robot) !== false) {
            return true;
        }
    }
    return false;
}

// بررسی ادمین سایت
function my_is_site_admin_bale($user_id = null) {
    if (!$user_id) {
        $user_id = get_current_user_id();
    }
    $admins = array(1, 5, 10); // ID ادمین‌های سایت را اینجا قرار دهید
    return in_array($user_id, $admins);
}

// بررسی تایید کاربر
function my_is_user_approved_bale($user_id = null) {
    if (!$user_id) {
        $user_id = get_current_user_id();
    }
    
    if (my_is_site_admin_bale($user_id)) {
        return true;
    }
    
    $is_approved = get_user_meta($user_id, 'user_approved', true);
    return ($is_approved === '1' || $is_approved === 1);
}

// ============================================
// 3. توابع اصلی مدیریت کاربران
// ============================================

function approve_user_bale($user_id) {
    update_user_meta($user_id, 'user_approved', '1');
    
    // ارسال ایمیل تایید
    $user = get_userdata($user_id);
    $subject = 'حساب کاربری شما تایید شد';
    $message = "سلام {$user->display_name}\n\n";
    $message .= "حساب کاربری شما در سایت " . get_bloginfo('name') . " تایید شد.\n";
    $message .= "اکنون می‌توانید به تمام بخش‌های سایت دسترسی داشته باشید.\n\n";
    $message .= "با تشکر، مدیریت سایت";
    wp_mail($user->user_email, $subject, $message);
    
    error_log("کاربر $user_id توسط ربات بله تایید شد");
}

function reject_user_bale($user_id) {
    delete_user_meta($user_id, 'user_approved');
    
    // ارسال ایمیل رد
    $user = get_userdata($user_id);
    $subject = 'حساب کاربری شما تایید نشد';
    $message = "سلام {$user->display_name}\n\n";
    $message .= "متاسفانه درخواست ثبت‌نام شما در سایت " . get_bloginfo('name') . " تایید نشد.\n";
    $message .= "برای اطلاعات بیشتر با پشتیبانی تماس بگیرید.\n\n";
    $message .= "با تشکر، مدیریت سایت";
    wp_mail($user->user_email, $subject, $message);
    
    error_log("کاربر $user_id توسط ربات بله رد شد");
}

// ============================================
// 4. ارسال پیام به ربات بله
// ============================================

function send_bale_message($chat_id, $message, $keyboard = null) {
    $settings = get_bale_settings();
    $bot_token = $settings['bot_token'];
    
    // API Bale (متفاوت از تلگرام)
    $url = "https://api.bale.ai/v1/bots/$bot_token/sendMessage";
    
    $data = array(
        'chat_id' => $chat_id,
        'text' => $message,
        'parse_mode' => 'Markdown'
    );
    
    // اضافه کردن دکمه‌های شیشه‌ای (Inline Keyboard)
    if ($keyboard) {
        $data['reply_markup'] = json_encode($keyboard);
    }
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    curl_close($ch);
    
    return $result;
}

// ============================================
// 5. ارسال درخواست تایید به ربات بله
// ============================================

add_action('user_register', 'send_approval_request_to_bale');

function send_approval_request_to_bale($user_id) {
    if (my_is_site_admin_bale($user_id)) {
        update_user_meta($user_id, 'user_approved', '1');
        return;
    }

    update_user_meta($user_id, 'user_approved', '0');
    
    $user_info = get_userdata($user_id);
    $settings = get_bale_settings();
    
    $message = "🔔 *درخواست تایید کاربر جدید*\n\n";
    $message .= "👤 *نام:* " . $user_info->display_name . "\n";
    $message .= "📧 *ایمیل:* " . $user_info->user_email . "\n";
    $message .= "🆔 *آیدی کاربر:* `" . $user_id . "`\n";
    $message .= "📅 *تاریخ ثبت:* " . date_i18n('Y/m/d H:i') . "\n\n";
    $message .= "لطفاً یکی از گزینه‌های زیر را انتخاب کنید:";
    
    // دکمه‌های شیشه‌ای برای بله
    $keyboard = array(
        'inline_keyboard' => array(
            array(
                array('text' => '✅ تایید', 'callback_data' => 'approve_' . $user_id),
                array('text' => '❌ رد', 'callback_data' => 'reject_' . $user_id),
            ),
            array(
                array('text' => 'ℹ️ اطلاعات بیشتر', 'callback_data' => 'info_' . $user_id),
            )
        )
    );
    
    foreach ($settings['admin_chat_ids'] as $chat_id) {
        send_bale_message($chat_id, $message, $keyboard);
    }
    
    error_log("درخواست تایید کاربر $user_id به ربات بله ارسال شد");
}

// ============================================
// 6. پردازش Webhook بله
// ============================================

// دریافت ورودی از بله
$content = file_get_contents('php://input');
$update = json_decode($content, true);

if (!$update) {
    http_response_code(400);
    exit('Invalid request');
}

// ============================================
// 7. پردازش Callback Query (دکمه‌های شیشه‌ای)
// ============================================

if (isset($update['callback_query'])) {
    $callback = $update['callback_query'];
    $chat_id = $callback['message']['chat']['id'];
    $callback_data = $callback['data'];
    
    // استخراج action و user_id از callback_data
    // فرمت: approve_123 یا reject_123 یا info_123
    $parts = explode('_', $callback_data);
    $action = isset($parts[0]) ? $parts[0] : '';
    $user_id = isset($parts[1]) ? intval($parts[1]) : 0;
    
    if ($action === 'approve') {
        approve_user_bale($user_id);
        send_bale_message($chat_id, "✅ کاربر $user_id با موفقیت تایید شد.");
        
        // حذف دکمه‌ها از پیام قبلی
        $edit_data = array(
            'chat_id' => $chat_id,
            'message_id' => $callback['message']['message_id'],
            'reply_markup' => json_encode(array('inline_keyboard' => array()))
        );
        // می‌توانید پیام را ویرایش کنید
        // send_bale_message(...)
        
    } elseif ($action === 'reject') {
        reject_user_bale($user_id);
        send_bale_message($chat_id, "❌ کاربر $user_id رد شد.");
        
    } elseif ($action === 'info') {
        $user = get_userdata($user_id);
        if ($user) {
            $info = "📋 *اطلاعات کاربر:*\n";
            $info .= "👤 نام: " . $user->display_name . "\n";
            $info .= "📧 ایمیل: " . $user->user_email . "\n";
            $info .= "📅 تاریخ ثبت: " . $user->user_registered . "\n";
            $info .= "🆔 آیدی: `" . $user_id . "`\n";
            $info .= "✅ وضعیت: " . (my_is_user_approved_bale($user_id) ? 'تایید شده' : 'در انتظار تایید');
            send_bale_message($chat_id, $info);
        } else {
            send_bale_message($chat_id, "❌ کاربر با این آیدی یافت نشد.");
        }
    }
    
    // پاسخ به بله
    http_response_code(200);
    exit;
}

// ============================================
// 8. پردازش پیام‌های متنی
// ============================================

if (isset($update['message'])) {
    $message = $update['message']['text'];
    $chat_id = $update['message']['chat']['id'];
    $user = $update['message']['from']['id'] ?? '';
    
    // دستورات متنی
    if (strpos($message, '/approve_') === 0) {
        $user_id = intval(str_replace('/approve_', '', $message));
        approve_user_bale($user_id);
        send_bale_message($chat_id, "✅ کاربر $user_id با موفقیت تایید شد.");
        
    } elseif (strpos($message, '/reject_') === 0) {
        $user_id = intval(str_replace('/reject_', '', $message));
        reject_user_bale($user_id);
        send_bale_message($chat_id, "❌ کاربر $user_id رد شد.");
        
    } elseif (strpos($message, '/info_') === 0) {
        $user_id = intval(str_replace('/info_', '', $message));
        $user_data = get_userdata($user_id);
        if ($user_data) {
            $info = "📋 *اطلاعات کاربر:*\n";
            $info .= "👤 نام: " . $user_data->display_name . "\n";
            $info .= "📧 ایمیل: " . $user_data->user_email . "\n";
            $info .= "📅 تاریخ ثبت: " . $user_data->user_registered . "\n";
            $info .= "🆔 آیدی: `" . $user_id . "`\n";
            $info .= "✅ وضعیت: " . (my_is_user_approved_bale($user_id) ? 'تایید شده' : 'در انتظار تایید');
            send_bale_message($chat_id, $info);
        } else {
            send_bale_message($chat_id, "❌ کاربر با این آیدی یافت نشد.");
        }
        
    } elseif ($message === '/start') {
        $welcome = "🤖 *ربات مدیریت کاربران بله*\n\n";
        $welcome .= "این ربات برای تایید کاربران سایت استفاده می‌شود.\n\n";
        $welcome .= "📌 *دستورات موجود:*\n";
        $welcome .= "/approve_[ID] - تایید کاربر\n";
        $welcome .= "/reject_[ID] - رد کاربر\n";
        $welcome .= "/info_[ID] - اطلاعات کاربر\n";
        $welcome .= "/pending - نمایش کاربران در انتظار تایید\n";
        $welcome .= "/help - راهنمای کامل";
        send_bale_message($chat_id, $welcome);
        
    } elseif ($message === '/pending') {
        global $wpdb;
        $pending_users = $wpdb->get_results("
            SELECT user_id 
            FROM {$wpdb->usermeta} 
            WHERE meta_key = 'user_approved' 
            AND meta_value = '0'
        ");
        
        if (empty($pending_users)) {
            send_bale_message($chat_id, "✅ هیچ کاربر در انتظار تاییدی وجود ندارد.");
        } else {
            $msg = "📋 *کاربران در انتظار تایید:*\n\n";
            foreach ($pending_users as $pending) {
                $user_info = get_userdata($pending->user_id);
                $msg .= "🆔 `" . $pending->user_id . "` - " . $user_info->display_name . "\n";
            }
            $msg .= "\nبرای تایید: /approve_[ID]";
            send_bale_message($chat_id, $msg);
        }
        
    } elseif ($message === '/help') {
        $help = "📖 *راهنمای کامل ربات بله*\n\n";
        $help .= "🔹 *تایید کاربر:*\n";
        $help .= "/approve_123 - تایید کاربر با آیدی 123\n\n";
        $help .= "🔹 *رد کاربر:*\n";
        $help .= "/reject_123 - رد کاربر با آیدی 123\n\n";
        $help .= "🔹 *اطلاعات کاربر:*\n";
        $help .= "/info_123 - نمایش اطلاعات کاربر 123\n\n";
        $help .= "🔹 *لیست کاربران منتظر:*\n";
        $help .= "/pending - نمایش همه کاربران در انتظار تایید\n\n";
        $help .= "🔹 *دکمه‌های شیشه‌ای:*\n";
        $help .= "وقتی کاربر جدید ثبت‌نام می‌کند، پیام با دکمه‌های تایید/رد ارسال می‌شود.";
        send_bale_message($chat_id, $help);
    }
}

// پاسخ موفق
http_response_code(200);
echo 'OK';