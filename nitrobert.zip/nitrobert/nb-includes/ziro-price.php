<?php
/**
 * WooCommerce Advanced Price Inquiry System (Phone Numbers Edition)
 */
class WC_Advanced_Price_Inquiry {

    private static $instance = null;

    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Admin Menu & Settings
        add_action( 'admin_menu', array( $this, 'add_admin_menu' ), 99 );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        
        // Product Meta Box (Single Product Setting)
        add_action( 'woocommerce_product_options_pricing', array( $this, 'add_product_meta' ) );
        add_action( 'woocommerce_process_product_meta', array( $this, 'save_product_meta' ) );
        
        // Price & Purchasing Logic
        add_filter( 'woocommerce_get_price_html', array( $this, 'modify_price_html' ), 100, 2 );
        add_filter( 'woocommerce_is_purchasable', array( $this, 'disable_purchasing' ), 10, 2 );
        
        // Add Phone Buttons to Single Product Page
        add_action( 'woocommerce_single_product_summary', array( $this, 'add_inquiry_phones_single' ), 31 );
        
        // Enqueue basic CSS
        add_action( 'wp_head', array( $this, 'enqueue_custom_styles' ) );
    }

    public function add_admin_menu() {
        add_submenu_page(
            'woocommerce',
            __( 'استعلام قیمت', 'woocommerce' ),
            __( 'استعلام قیمت', 'woocommerce' ),
            'manage_woocommerce',
            'wc-price-inquiry',
            array( $this, 'render_admin_page' )
        );
    }

    public function register_settings() {
        register_setting( 'wc_price_inquiry_group', 'wc_global_price_inquiry' );
        register_setting( 'wc_price_inquiry_group', 'wc_inquiry_categories' );
        register_setting( 'wc_price_inquiry_group', 'wc_inquiry_phone_numbers' );
    }

    public function render_admin_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) return;
        ?>
        <div class="wrap">
            <h1><?php _e( 'تنظیمات استعلام قیمت', 'woocommerce' ); ?></h1>
            <form method="post" action="options.php">
                <?php settings_fields( 'wc_price_inquiry_group' ); ?>
                <table class="form-table">
                    
                    <tr valign="top">
                        <th scope="row"><?php _e( 'فعال‌سازی برای همه محصولات', 'woocommerce' ); ?></th>
                        <td>
                            <input type="checkbox" name="wc_global_price_inquiry" value="yes" <?php checked( get_option( 'wc_global_price_inquiry' ), 'yes' ); ?> />
                            <p class="description"><?php _e( 'قیمت تمامی محصولات سایت به استعلامی تغییر می‌کند.', 'woocommerce' ); ?></p>
                        </td>
                    </tr>

                    <tr valign="top">
                        <th scope="row"><?php _e( 'فعال‌سازی بر اساس دسته‌بندی', 'woocommerce' ); ?></th>
                        <td>
                            <?php
                            $selected_cats = get_option( 'wc_inquiry_categories', array() );
                            if ( ! is_array( $selected_cats ) ) $selected_cats = array();
                            $product_categories = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
                            
                            if ( ! empty( $product_categories ) && ! is_wp_error( $product_categories ) ) {
                                echo '<select name="wc_inquiry_categories[]" multiple="multiple" style="width: 300px; height: 150px;">';
                                foreach ( $product_categories as $category ) {
                                    $selected = in_array( $category->term_id, $selected_cats ) ? 'selected="selected"' : '';
                                    echo '<option value="' . esc_attr( $category->term_id ) . '" ' . $selected . '>' . esc_html( $category->name ) . '</option>';
                                }
                                echo '</select>';
                                echo '<p class="description">' . __( 'برای انتخاب چند گزینه، کلید Ctrl (یا Cmd) را نگه دارید.', 'woocommerce' ) . '</p>';
                            }
                            ?>
                        </td>
                    </tr>

                    <!-- Phone Numbers Repeater -->
                    <tr valign="top">
                        <th scope="row"><?php _e( 'شماره تماس‌های استعلام', 'woocommerce' ); ?></th>
                        <td>
                            <div id="wc-phone-repeater">
                                <?php
                                $phones = get_option( 'wc_inquiry_phone_numbers', array() );
                                if ( empty( $phones ) || ! is_array( $phones ) ) {
                                    $phones = array( '' ); // حداقل یک فیلد خالی
                                }
                                foreach ( $phones as $phone ) : ?>
                                    <div class="phone-row" style="margin-bottom: 10px;">
                                        <input type="text" name="wc_inquiry_phone_numbers[]" value="<?php echo esc_attr( $phone ); ?>" placeholder="مثال: 02112345678" style="width: 200px;" dir="ltr" />
                                        <button type="button" class="button remove-phone" onclick="this.parentElement.remove();"><?php _e( 'حذف', 'woocommerce' ); ?></button>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <button type="button" class="button button-primary" id="add-phone-btn" style="margin-top: 5px;"><?php _e( '+ افزودن شماره جدید', 'woocommerce' ); ?></button>
                            <p class="description"><?php _e( 'این شماره‌ها در صفحه محصولات استعلامی جهت تماس کاربر نمایش داده می‌شوند.', 'woocommerce' ); ?></p>
                            
                            <script>
                                document.getElementById('add-phone-btn').addEventListener('click', function() {
                                    var container = document.getElementById('wc-phone-repeater');
                                    var row = document.createElement('div');
                                    row.className = 'phone-row';
                                    row.style.marginBottom = '10px';
                                    row.innerHTML = '<input type="text" name="wc_inquiry_phone_numbers[]" value="" placeholder="مثال: 02112345678" style="width: 200px;" dir="ltr" /> <button type="button" class="button remove-phone" onclick="this.parentElement.remove();"><?php _e( "حذف", "woocommerce" ); ?></button>';
                                    container.appendChild(row);
                                });
                            </script>
                        </td>
                    </tr>

                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    private function is_inquiry_product( $product ) {
        if ( ! is_a( $product, 'WC_Product' ) ) return false;
        
        if ( 'yes' === get_option( 'wc_global_price_inquiry', 'no' ) ) return true;

        $target_cats = get_option( 'wc_inquiry_categories', array() );
        if ( ! empty( $target_cats ) && is_array( $target_cats ) ) {
            $product_cats = $product->get_category_ids();
            if ( array_intersect( $product_cats, $target_cats ) ) return true;
        }

        if ( 'yes' === $product->get_meta( '_is_price_inquiry' ) ) return true;

        return false;
    }

    public function add_product_meta() {
        woocommerce_wp_checkbox( array(
            'id'            => '_is_price_inquiry',
            'wrapper_class' => 'show_if_simple show_if_variable',
            'label'         => __( 'وضعیت «استعلام قیمت»', 'woocommerce' ),
        ) );
    }

    public function save_product_meta( $post_id ) {
        $is_inquiry = isset( $_POST['_is_price_inquiry'] ) ? 'yes' : 'no';
        update_post_meta( $post_id, '_is_price_inquiry', $is_inquiry );
    }

    public function modify_price_html( $price, $product ) {
        if ( $this->is_inquiry_product( $product ) ) {
            return '<span class="wc-price-inquiry-text">' . __( 'استعلام قیمت', 'woocommerce' ) . '</span>';
        }
        return $price;
    }

    public function disable_purchasing( $purchasable, $product ) {
        if ( $this->is_inquiry_product( $product ) ) {
            return false;
        }
        return $purchasable;
    }

    public function add_inquiry_phones_single() {
        global $product;
        if ( $this->is_inquiry_product( $product ) ) {
            $phones = get_option( 'wc_inquiry_phone_numbers', array() );
            $phones = array_filter( $phones ); // حذف مقادیر خالی

            echo '<div class="wc-inquiry-phones-wrapper">';
            if ( ! empty( $phones ) ) {
                echo '<p><strong>' . __( 'برای استعلام قیمت تماس بگیرید:', 'woocommerce' ) . '</strong></p>';
                foreach ( $phones as $phone ) {
                    echo '<a href="tel:' . esc_attr( $phone ) . '" class="button alt wc-inquiry-phone-btn">📞 ' . esc_html( $phone ) . '</a>';
                }
            } else {
                echo '<p><strong>' . __( 'استعلام قیمت (شماره تماسی ثبت نشده است)', 'woocommerce' ) . '</strong></p>';
            }
            echo '</div>';
        }
    }

    public function enqueue_custom_styles() {
        ?>
        <style>
            .wc-price-inquiry-text { color: #e2401c; font-weight: bold; font-size: 1.2em; }
            .wc-inquiry-phones-wrapper { margin: 20px 0; padding: 15px; background: #f9f9f9; border: 1px solid #eee; border-radius: 5px; text-align: center;}
            .wc-inquiry-phone-btn { display: inline-block; margin: 5px; background-color: #28a745 !important; color: #fff !important; font-weight: bold; direction: ltr; }
            .wc-inquiry-phone-btn:hover { background-color: #218838 !important; }
        </style>
        <?php
    }
}

WC_Advanced_Price_Inquiry::get_instance();
