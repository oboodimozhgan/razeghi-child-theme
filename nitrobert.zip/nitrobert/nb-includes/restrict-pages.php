<?php


$is_webhook = (php_sapi_name() !== 'cli' && isset($_SERVER['REQUEST_METHOD']));

if ($is_webhook && !defined('ABSPATH')) {
    $root_path = dirname(dirname(dirname(dirname(__FILE__))));
    require_once($root_path . '/wp-load.php');
}



function get_bale_settings() {
    return array(
        'bot_token' => get_option('nb_bale_bot_token', '740730044:fKPc56Y4pcXsQqzX4JzIoQIkXG6MVQDACcc'),
        'admin_chat_ids' => explode(',', get_option('nb_bale_admin_chat_ids', '1656475446,1079435797')),
        'api_base' => 'https://tapi.bale.ai/bot'
    );
}

function get_sms_settings() {
    return array(
        'username' => get_option('nb_sms_username', '989175347869'),
        'password' => get_option('nb_sms_password', '79eadf15-502f-4b85-96f4-fe78d78b1982'),
        'from' => get_option('nb_sms_from', '3000500'),
        'group_id' => get_option('nb_sms_group_id', '12345'),
        'profile_body_id' => get_option('nb_sms_profile_body_id', '485946')
    );
}

function my_is_robot_bale() {
    $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    $robots = array(
        'Googlebot', 'bingbot', 'Slurp', 'DuckDuckBot', 'Baiduspider',
        'YandexBot', 'Sogou', 'Exabot', 'facebookexternalhit', 'Facebot',
        'Twitterbot', 'Applebot', 'AhrefsBot', 'SemrushBot', 'MJ12bot',
        'GPTBot', 'ChatGPT-User'
    );
    foreach ($robots as $robot) {
        if (stripos($user_agent, $robot) !== false) return true;
    }
    return false;
}

function is_allowed_role($user_id = null) {
    if (!$user_id) $user_id = get_current_user_id();
    $user = get_userdata($user_id);
    if (!$user) return false;
    $allowed_roles = array('administrator', 'editor', 'author', 'personnel');
    return (bool) array_intersect($user->roles, $allowed_roles);
}

function my_is_site_admin_bale($user_id = null) {
    if (!$user_id) $user_id = get_current_user_id();
    $user = get_userdata($user_id);
    return $user && in_array('administrator', $user->roles);
}

function my_is_user_approved_bale($user_id = null) {
    if (!$user_id) $user_id = get_current_user_id();
    if (is_allowed_role($user_id)) return true;
    $is_approved = get_user_meta($user_id, 'user_approved', true);
    return ($is_approved === '1' || $is_approved === 1);
}

function is_user_info_complete($user_id = null) {
    if (!$user_id) $user_id = get_current_user_id();
    $fields = array('billing_phone', 'store_name', 'store_address', 'national_code', 'store_type');
    foreach ($fields as $field) {
        if (empty(get_user_meta($user_id, $field, true))) return false;
    }
    return true;
}

function get_user_complete_info($user_id = null) {
    if (!$user_id) $user_id = get_current_user_id();
    return array(
        'display_name' => get_userdata($user_id)->display_name,
        'phone' => get_user_meta($user_id, 'billing_phone', true),
        'store_name' => get_user_meta($user_id, 'store_name', true),
        'store_address' => get_user_meta($user_id, 'store_address', true),
        'national_code' => get_user_meta($user_id, 'national_code', true),
        'store_type' => get_user_meta($user_id, 'store_type', true),
    );
}

/* رفع باگ وضعیت منوها: آیدی بله با آیدی وردپرس متفاوت است، لذا از transient استفاده می‌کنیم */
function get_user_bale_step($bot_user_id) {
    $step = get_transient('bale_step_' . $bot_user_id);
    return !empty($step) ? $step : 'start';
}

function set_user_bale_step($bot_user_id, $step) {
    set_transient('bale_step_' . $bot_user_id, $step, DAY_IN_SECONDS);
}

// ============================================
// بخش 4: کلاس ارسال پیامک و لاگ‌گیری دقیق
// ============================================

class MeliPayamak {
    private $username, $password, $from, $group_id, $profile_body_id;
    
    public function __construct() {
        $s = get_sms_settings();
        $this->username = $s['username'];
        $this->password = $s['password'];
        $this->from = $s['from'];
        $this->group_id = isset($s['group_id']) ? $s['group_id'] : '';
        $this->profile_body_id = isset($s['profile_body_id']) ? $s['profile_body_id'] : '';
    }
    
    public function sendSMS($to, $text) {
        if (empty($to)) return array('success' => false, 'error' => 'شماره خالی است');
        $to = preg_replace('/[^0-9]/', '', $to);
        if (strlen($to) < 10) return array('success' => false, 'error' => 'شماره نامعتبر است');
        
        $url = 'https://api.melipayamak.com/v1/send/';
        $data = array(
            'username' => $this->username,
            'password' => $this->password,
            'from' => $this->from,
            'to' => $to,
            'text' => $text
        );
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            error_log("❌ [پیامک عادی] خطای cURL: $error");
            return array('success' => false, 'error' => "خطای ارتباط: $error");
        }
        $response = json_decode($result, true);
        if (isset($response['status']) && $response['status'] === 'success') {
            return array('success' => true);
        }
        error_log("❌ [پیامک عادی] خطا از سمت API: " . print_r($response, true));
        return array('success' => false, 'error' => isset($response['message']) ? $response['message'] : 'خطای نامشخص از سمت درگاه');
    }

    public function sendByBaseNumber($to, $textArray, $bodyId = null) {
        if (empty($to)) return array('success' => false, 'error' => 'شماره خالی است');
        $to = preg_replace('/[^0-9]/', '', $to);
        
        if (!$bodyId) $bodyId = $this->profile_body_id;
        
        $url = 'https://rest.melipayamak.com/api/SendSMS/BaseServiceNumber';
        $data = array(
            'username' => $this->username,
            'password' => $this->password,
            'text'     => is_array($textArray) ? implode(';', $textArray) : $textArray,
            'to'       => $to,
            'bodyId'   => $bodyId
        );
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            error_log("❌ [پترن پیامک] خطای cURL: $error");
            return array('success' => false, 'error' => "خطای ارتباط: $error");
        }
        
        $response = json_decode($result, true);
        if (isset($response['Value']) && strlen($response['Value']) > 5) {
            return array('success' => true);
        }
        
        error_log("❌ [پترن پیامک] خطا از سمت API: " . print_r($response, true));
        return array('success' => false, 'error' => isset($response['StrRetStatus']) ? $response['StrRetStatus'] : 'خطا در ارسال پترن');
    }

    public function addContact($phone, $firstName, $lastName, $nationalCode = '') {
        if (empty($phone) || empty($this->group_id)) return false;
        $phone = preg_replace('/[^0-9]/', '', $phone);
        
        $url = 'https://rest.melipayamak.com/api/Contacts/AddContact';
        $data = array(
            'username'    => $this->username,
            'password'    => $this->password,
            'groupId'     => $this->group_id,
            'name'        => $firstName,
            'family'      => $lastName,
            'number'      => $phone,
            'description' => $nationalCode
        );
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_exec($ch);
        curl_close($ch);
        return true;
    }
}



function approve_user_bale($user_id) {
    update_user_meta($user_id, 'user_approved', '1');
    $user = get_userdata($user_id);
    if ($user) {
        $sms = new MeliPayamak();
        $phone = get_user_meta($user_id, 'billing_phone', true);
        $national = get_user_meta($user_id, 'national_code', true);
        
        if (!empty($phone)) {
            $sms->sendSMS($phone, "سلام {$user->display_name}\nحساب شما در " . get_bloginfo('name') . " تایید شد.");
            $parts = explode(' ', trim($user->display_name), 2);
            $sms->addContact($phone, $parts[0], isset($parts[1]) ? $parts[1] : '', $national);
        }
        wp_mail($user->user_email, '✅ حساب کاربری شما تایید شد', "سلام {$user->display_name}\nحساب شما تایید شد.");
    }
    $settings = get_bale_settings();
    foreach ($settings['admin_chat_ids'] as $chat_id) {
        send_bale_message(trim($chat_id), "✅ کاربر $user_id تایید شد.");
    }
    return true;
}

function reject_user_bale($user_id) {
    update_user_meta($user_id, 'user_approved', '0');
    $user = get_userdata($user_id);
    if ($user) {
        $sms = new MeliPayamak();
        $phone = get_user_meta($user_id, 'billing_phone', true);
        if (!empty($phone)) {
            $sms->sendSMS($phone, "سلام {$user->display_name}\nمتاسفانه درخواست شما رد شد.");
        }
        wp_mail($user->user_email, '❌ حساب کاربری شما تایید نشد', "سلام {$user->display_name}\nدرخواست شما رد شد.");
    }
    $settings = get_bale_settings();
    foreach ($settings['admin_chat_ids'] as $chat_id) {
        send_bale_message(trim($chat_id), "❌ کاربر $user_id رد شد.");
    }
    return true;
}



add_filter('views_users', 'nb_custom_pending_users_view');
function nb_custom_pending_users_view($views) {
    global $wpdb;
    $pending_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = 'user_approved' AND meta_value = '0'");
    $class = (isset($_GET['user_status']) && $_GET['user_status'] === 'pending') ? 'current' : '';
    $url = admin_url('users.php?user_status=pending');
    $views['pending_approval'] = "<a href='{$url}' class='{$class}'>در انتظار تایید <span class='count'>({$pending_count})</span></a>";
    return $views;
}

add_action('pre_get_users', 'nb_filter_pending_users_query');
function nb_filter_pending_users_query($query) {
    global $pagenow;
    if (is_admin() && $pagenow === 'users.php' && isset($_GET['user_status']) && $_GET['user_status'] === 'pending') {
        $query->set('meta_key', 'user_approved');
        $query->set('meta_value', '0');
    }
}

add_action('admin_notices', 'show_pending_users_notice_bale');
function show_pending_users_notice_bale() {
    if (!my_is_site_admin_bale()) return;
    
    // پنهان کردن اعلان وقتی مدیر داخل تب در انتظار تایید است
    if (isset($_GET['user_status']) && $_GET['user_status'] === 'pending') return;

    global $wpdb;
    $pending_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = 'user_approved' AND meta_value = '0'");
    if ($pending_count > 0) {
        echo '<div class="notice notice-warning is-dismissible"><p><strong>🔔 ' . $pending_count . ' کاربر در انتظار تایید هستند.</strong> <a href="' . admin_url('users.php?user_status=pending') . '">مشاهده و تایید کاربران</a></p></div>';
    }
}



function send_bale_message($chat_id, $message, $keyboard = null) {
    $settings = get_bale_settings();
    $url = $settings['api_base'] . $settings['bot_token'] . '/sendMessage';
    $data = array('chat_id' => $chat_id, 'text' => $message, 'parse_mode' => 'Markdown');
    if ($keyboard) $data['reply_markup'] = json_encode($keyboard);
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}

function send_bale_document($chat_id, $file_path, $caption = '') {
    $settings = get_bale_settings();
    $url = $settings['api_base'] . $settings['bot_token'] . '/sendDocument';
    $data = array('chat_id' => $chat_id, 'document' => new CURLFile($file_path), 'caption' => $caption);
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}

function export_users_csv() {
    $headers = array('شناسه', 'نام', 'ایمیل', 'شماره تماس', 'نام فروشگاه', 'آدرس فروشگاه', 'کد ملی', 'نوع فروشگاه', 'نقش', 'وضعیت', 'تاریخ ثبت');
    $users = get_users(array('orderby' => 'ID', 'order' => 'DESC'));
    $rows = array();
    
    foreach ($users as $user) {
        $phone = get_user_meta($user->ID, 'billing_phone', true);
        $store_name = get_user_meta($user->ID, 'store_name', true);
        $store_address = get_user_meta($user->ID, 'store_address', true);
        $national = get_user_meta($user->ID, 'national_code', true);
        $store_type = get_user_meta($user->ID, 'store_type', true);
        $is_approved = my_is_user_approved_bale($user->ID);
        
        $roles = implode('، ', array_map('translate_user_role', $user->roles));
        $status = is_allowed_role($user->ID) ? 'نقش مجاز' : ($is_approved ? 'تایید شده' : 'در انتظار تایید');
        
        $rows[] = array($user->ID, $user->display_name, $user->user_email, $phone ?: '—', $store_name ?: '—', $store_address ?: '—', $national ?: '—', $store_type ?: '—', $roles, $status, date_i18n('Y/m/d H:i', strtotime($user->user_registered)));
    }
    
    $upload_dir = wp_upload_dir();
    $temp_file = $upload_dir['path'] . '/users_export_' . date('Ymd_His') . '.csv';
    $temp_url = $upload_dir['url'] . '/users_export_' . date('Ymd_His') . '.csv';
    
    $fp = fopen($temp_file, 'w');
    if (!$fp) return false;
    fprintf($fp, chr(0xEF) . chr(0xBB) . chr(0xBF));
    fputcsv($fp, $headers);
    foreach ($rows as $row) fputcsv($fp, $row);
    fclose($fp);
    
    return array('path' => $temp_file, 'url' => $temp_url, 'count' => count($rows));
}


function get_main_menu_keyboard() {
    return array(
        'inline_keyboard' => array(
            array(array('text' => '👥 لیست کاربران منتظر', 'callback_data' => 'pending'), array('text' => '📈 آمار و گزارشات', 'callback_data' => 'stats')),
            array(array('text' => '🔍 جستجوی کاربران', 'callback_data' => 'search_user'), array('text' => '📥 خروجی کامل کاربران', 'callback_data' => 'export_users')),
            array(array('text' => '❓ راهنما و پشتیبانی', 'callback_data' => 'help')),
        )
    );
}

function get_user_action_keyboard($user_id) {
    return array(
        'inline_keyboard' => array(
            array(array('text' => '✅ تایید و فعال‌سازی', 'callback_data' => 'approve_' . $user_id), array('text' => '❌ رد و غیرفعال‌سازی', 'callback_data' => 'reject_' . $user_id)),
            array(array('text' => '🏠 بازگشت به منوی اصلی', 'callback_data' => 'back_to_menu'), array('text' => '👥 لیست منتظران', 'callback_data' => 'pending')),
        )
    );
}

function get_pending_users_keyboard($users, $page = 0) {
    $keyboard = array('inline_keyboard' => array());
    $per_page = 5;
    $start = $page * $per_page;
    $users_page = array_slice($users, $start, $per_page);
    
    foreach ($users_page as $user) {
        $user_info = get_userdata($user->user_id);
        $keyboard['inline_keyboard'][] = array(array('text' => '👤 ' . $user_info->display_name, 'callback_data' => 'info_' . $user->user_id));
    }
    
    $nav_buttons = array();
    if ($page > 0) $nav_buttons[] = array('text' => '⬅️ قبلی', 'callback_data' => 'pending_page_' . ($page - 1));
    $nav_buttons[] = array('text' => '📄 ' . ($page + 1), 'callback_data' => 'pending_page_' . $page);
    if (($start + $per_page) < count($users)) $nav_buttons[] = array('text' => '➡️ بعدی', 'callback_data' => 'pending_page_' . ($page + 1));
    if (!empty($nav_buttons)) $keyboard['inline_keyboard'][] = $nav_buttons;
    
    $keyboard['inline_keyboard'][] = array(array('text' => '🏠 منوی اصلی', 'callback_data' => 'back_to_menu'));
    return $keyboard;
}

function get_search_results_keyboard($users) {
    $keyboard = array('inline_keyboard' => array());
    foreach ($users as $user) $keyboard['inline_keyboard'][] = array(array('text' => '👤 ' . $user->display_name, 'callback_data' => 'info_' . $user->ID));
    $keyboard['inline_keyboard'][] = array(array('text' => '🏠 منوی اصلی', 'callback_data' => 'back_to_menu'), array('text' => '🔍 جستجوی جدید', 'callback_data' => 'search_user'));
    return $keyboard;
}

function send_main_menu($chat_id) {
    $welcome = "🤖 *ربات مدیریت کاربران سایت*\n\n✅ خوش آمدید! از طریق دکمه‌های زیر می‌توانید کاربران را مدیریت کنید:";
    send_bale_message($chat_id, $welcome, get_main_menu_keyboard());
}

function get_user_public_info($user_id) {
    $user = get_userdata($user_id);
    if (!$user) return null;
    
    $info = "📋 *مشخصات کاربر*\n━━━━━━━━━━━━━━\n";
    $info .= "👤 *نام:* " . $user->display_name . "\n";
    $info .= "📱 *شماره:* " . (get_user_meta($user_id, 'billing_phone', true) ?: 'ثبت نشده') . "\n";
    $info .= "🏪 *فروشگاه:* " . (get_user_meta($user_id, 'store_name', true) ?: 'ثبت نشده') . "\n";
    $info .= "📍 *آدرس:* " . (get_user_meta($user_id, 'store_address', true) ?: 'ثبت نشده') . "\n";
    $info .= "🆔 *کد ملی:* " . (get_user_meta($user_id, 'national_code', true) ?: 'ثبت نشده') . "\n";
    $info .= "📌 *نوع:* " . (get_user_meta($user_id, 'store_type', true) ?: 'ثبت نشده') . "\n";
    $info .= "━━━━━━━━━━━━━━\n";
    $info .= (is_user_info_complete($user_id) ? "✅ کامل" : "⚠️ ناقص") . "\n";
    
    if (is_allowed_role($user_id)) $info .= "👑 نقش مجاز\n";
    elseif (my_is_user_approved_bale($user_id)) $info .= "✅ تایید شده\n";
    else $info .= "⏳ در انتظار تایید\n";
    return $info;
}

function send_approval_request_to_bale($user_id) {
    if (is_allowed_role($user_id) || !is_user_info_complete($user_id)) return;
    
    update_user_meta($user_id, 'user_approved', '0');
    $user_info = get_userdata($user_id);
    $settings = get_bale_settings();
    
    $message = "🔔 *درخواست تایید کاربر جدید*\n\n👤 *نام:* " . $user_info->display_name . "\n";
    $message .= "📱 *شماره:* " . get_user_meta($user_id, 'billing_phone', true) . "\n";
    
    $keyboard = array('inline_keyboard' => array(
        array(array('text' => '✅ تایید', 'callback_data' => 'approve_' . $user_id), array('text' => '❌ رد', 'callback_data' => 'reject_' . $user_id)),
        array(array('text' => 'ℹ️ مشاهده مشخصات کامل', 'callback_data' => 'info_' . $user_id))
    ));
    
    foreach ($settings['admin_chat_ids'] as $chat_id) send_bale_message(trim($chat_id), $message, $keyboard);
}

add_action('template_redirect', 'restrict_unapproved_users_bale');
function restrict_unapproved_users_bale() {
    if (isset($_SERVER['REQUEST_URI']) && strpos($_SERVER['REQUEST_URI'], 'bale-integration.php') !== false) return;
    /*if (is_admin() || is_front_page() || my_is_robot_bale()) return;
    if (strpos($_SERVER['REQUEST_URI'], '/auth/') !== false) return;
    
    if (!is_user_logged_in()) {
        $login_url = add_query_arg('redirect_to', urlencode((is_ssl() ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']), home_url('/auth/'));
        wp_safe_redirect($login_url);
        exit;
    }*/
    if (is_admin() || my_is_robot_bale()) return;
    if (strpos($_SERVER['REQUEST_URI'], '/auth/') !== false) return;

    if (!is_user_logged_in()) {
    if (is_front_page()) return; // مهمون‌ها هوم رو بدون لاگین ببینن
    $login_url = add_query_arg('redirect_to', urlencode((is_ssl() ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']), home_url('/auth/'));
    wp_safe_redirect($login_url);
    exit;
    }
    if (is_allowed_role()) return;
    if (!my_is_user_approved_bale()) {
        $user_id = get_current_user_id();
        
        if (isset($_POST['update_info']) && wp_verify_nonce($_POST['_wpnonce'], 'update_user_info_' . $user_id)) {
            $phone = sanitize_text_field($_POST['billing_phone'] ?? '');
            $store_name = sanitize_text_field($_POST['store_name'] ?? '');
            $store_address = sanitize_textarea_field($_POST['store_address'] ?? '');
            $national = sanitize_text_field($_POST['national_code'] ?? '');
            $store_type = sanitize_text_field($_POST['store_type'] ?? '');
            
            if (!empty($phone)) update_user_meta($user_id, 'billing_phone', $phone);
            if (!empty($store_name)) {
                update_user_meta($user_id, 'store_name', $store_name);
                update_user_meta($user_id, 'billing_company', $store_name); // همگام‌سازی
            }
            if (!empty($store_address)) {
                update_user_meta($user_id, 'store_address', $store_address);
                update_user_meta($user_id, 'billing_address_1', $store_address); // همگام‌سازی
            }
            if (!empty($national)) update_user_meta($user_id, 'national_code', $national);
            if (!empty($store_type)) update_user_meta($user_id, 'store_type', $store_type);
            
            send_approval_request_to_bale($user_id);
            echo '<div class="message success">✅ اطلاعات شما با موفقیت ثبت و درخواست تایید مجدد ارسال شد.</div>';
        }
        
        if (isset($_GET['action']) && $_GET['action'] === 'resend' && wp_verify_nonce($_GET['_wpnonce'], 'resend_approval_request_' . $user_id)) {
            send_approval_request_to_bale($user_id);
            echo '<div class="message success">✅ درخواست تایید مجدداً برای ادمین ارسال شد.</div>';
        }
        
        $user_info = get_user_complete_info($user_id);
        $is_complete = is_user_info_complete($user_id);
   
        ?>
        <!DOCTYPE html>
        <html <?php language_attributes(); ?>>
        <head>
            <meta charset="<?php bloginfo('charset'); ?>">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>حساب کاربری در انتظار تایید</title>
            <style>
                @font-face { font-family: 'IRANSansX'; src: url('https://razeghiparts.com/wp-content/themes/asbpart/fonts/IRANSansXFaNum-Regular.woff') format('woff'); }
                * { box-sizing: border-box; margin: 0; padding: 0; }
                body { font-family: 'IRANSansX', sans-serif; background: #fff5f5; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; direction: rtl; }
                .container { max-width: 580px; width: 100%; background: #ffffff; border-radius: 24px; padding: 40px 35px; box-shadow: 0 20px 60px rgba(226, 35, 26, 0.12); border-top: 6px solid #E2231A; }
                h1 { color: #E2231A; font-size: 24px; text-align: center; }
                .user-info { background: #fef6f5; border-radius: 16px; padding: 20px; margin: 20px 0; }
                .form-group { margin-bottom: 16px; }
                .form-group input, .form-group textarea { width: 100%; padding: 12px; border: 2px solid #fde0dd; border-radius: 12px; }
                .btn-primary { background: #E2231A; color: #fff; padding: 12px 28px; border: none; border-radius: 50px; width: 100%; cursor: pointer; }
                .store-type-options {
    display: flex;
    flex-direction: column;
    gap: 15px;
    margin-top: 10px;
}

.store-type-options label {
    display: flex;
    align-items: center;
    justify-content: flex-start;
    gap: 8px;
    cursor: pointer;
    direction: rtl;
}

.store-type-options input[type="radio"] {
    margin: 0;
    width: auto;
}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>در انتظار تایید حساب کاربری</h1>
                <p style="text-align:center;"><?php echo $is_complete ? 'در انتظار تایید ادمین' : 'لطفاً اطلاعات خود را تکمیل کنید'; ?></p>

                <?php if (!$is_complete): ?>
                <form method="post" action="" style="margin-top: 16px;">
                    <?php wp_nonce_field('update_user_info_' . $user_id); ?>
                    <input type="hidden" name="update_info" value="1">
                    
                    <div class="form-group">
                        <label>شماره تماس</label>
                        <input type="tel" name="billing_phone" value="<?php echo esc_attr($user_info['phone']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>نام فروشگاه</label>
                        <input type="text" name="store_name" value="<?php echo esc_attr($user_info['store_name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>آدرس فروشگاه</label>
                        <textarea name="store_address" required><?php echo esc_textarea($user_info['store_address']); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label>کد ملی</label>
                        <input type="text" name="national_code" value="<?php echo esc_attr($user_info['national_code']); ?>">
                    </div>
                    <div class="form-group">
                        <label>نوع فروشگاه:</label>
                        <div>
                            <div class="store-type-options">
<label>
    <input type="radio" name="store_type" value="خرده فروش" <?php echo ($user_info['store_type'] == 'خرده فروش') ? 'checked' : ''; ?> required>
    <span>خرده‌فروش</span>
</label>

<label>
    <input type="radio" name="store_type" value="عمده فروش" <?php echo ($user_info['store_type'] == 'عمده فروش') ? 'checked' : ''; ?> required>
    <span>عمده‌فروش</span>
</label>

<label>
    <input type="radio" name="store_type" value="پخش کننده" <?php echo ($user_info['store_type'] == 'پخش کننده') ? 'checked' : ''; ?> required>
    <span>پخش‌کننده</span>
</label>

</div>
                        </div>
                    </div>
                    <button type="submit" class="btn-primary">ثبت اطلاعات</button>
                </form>
                <?php else: ?>
                <div style="margin-top: 16px; text-align:center;">
                    <a href="<?php echo add_query_arg(array('action' => 'resend', '_wpnonce' => wp_create_nonce('resend_approval_request_' . $user_id))); ?>" style="color:#E2231A;">ارسال مجدد درخواست</a>
                </div>
                <?php endif; ?>
            </div>
        </body>
        </html>
        <?php
        exit;
    }
}


$is_webhook_request = (isset($_SERVER['REQUEST_METHOD']) && strpos($_SERVER['REQUEST_URI'], 'bale-integration.php') !== false);

if ($is_webhook_request) {
    $content = file_get_contents('php://input');
    $update = json_decode($content, true);
    
    if (!$update) { http_response_code(400); exit('Invalid request'); }
    $settings = get_bale_settings();
    
    if (isset($update['callback_query'])) {
        $callback = $update['callback_query'];
        $chat_id = $callback['message']['chat']['id'];
        $bot_user_id = $callback['from']['id']; // این آیدی بله است، نه وردپرس
        $callback_data = $callback['data'];
        
        // پاسخ به Callback برای برداشتن حالت لودینگ دکمه
        $ch = curl_init($settings['api_base'] . $settings['bot_token'] . '/answerCallbackQuery');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(array('callback_query_id' => $callback['id'])));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_exec($ch);
        curl_close($ch);
        
        switch ($callback_data) {
            case 'back_to_menu':
                set_user_bale_step($bot_user_id, 'start');
                send_main_menu($chat_id);
                break;
                
            case 'pending':
                global $wpdb;
                $pending_users = $wpdb->get_results("SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = 'user_approved' AND meta_value = '0' ORDER BY user_id DESC");
                if (empty($pending_users)) {
                    send_bale_message($chat_id, "✅ هیچ کاربر در انتظار تاییدی وجود ندارد.", get_main_menu_keyboard());
                } else {
                    send_bale_message($chat_id, "👥 *لیست منتظران*\nتعداد: " . count($pending_users), get_pending_users_keyboard($pending_users, 0));
                }
                set_user_bale_step($bot_user_id, 'start');
                break;
                
            case 'search_user':
                set_user_bale_step($bot_user_id, 'searching');
                send_bale_message($chat_id, "🔍 *جستجو*\nلطفاً نام یا شماره تماس را وارد کنید:", array('inline_keyboard' => array(array(array('text' => '🏠 بازگشت', 'callback_data' => 'back_to_menu')))));
                break;
                
            default:
                $parts = explode('_', $callback_data);
                $action = $parts[0] ?? '';
                $wp_user_id = isset($parts[1]) ? intval($parts[1]) : 0;
                
                if ($action === 'approve' && $wp_user_id > 0) {
                    approve_user_bale($wp_user_id);
                    send_bale_message($chat_id, "✅ کاربر تایید شد.\n\n" . get_user_public_info($wp_user_id), get_user_action_keyboard($wp_user_id));
                } elseif ($action === 'reject' && $wp_user_id > 0) {
                    reject_user_bale($wp_user_id);
                    send_bale_message($chat_id, "❌ کاربر رد شد.\n\n" . get_user_public_info($wp_user_id), get_user_action_keyboard($wp_user_id));
                } elseif ($action === 'info' && $wp_user_id > 0) {
                    send_bale_message($chat_id, get_user_public_info($wp_user_id), get_user_action_keyboard($wp_user_id));
                }
                set_user_bale_step($bot_user_id, 'start');
                break;
        }
        http_response_code(200); echo 'OK'; exit;
    }
    
    if (isset($update['message'])) {
        $text = trim($update['message']['text'] ?? '');
        $chat_id = $update['message']['chat']['id'];
        $bot_user_id = $update['message']['from']['id'];
        $step = get_user_bale_step($bot_user_id);
        
        if ($text === '/start') {
            set_user_bale_step($bot_user_id, 'start');
            send_main_menu($chat_id);
        } elseif ($step === 'searching' && !empty($text)) {
            global $wpdb;
            $users = $wpdb->get_results($wpdb->prepare("
                SELECT DISTINCT u.ID, u.display_name 
                FROM {$wpdb->users} u
                LEFT JOIN {$wpdb->usermeta} um ON u.ID = um.user_id 
                WHERE u.display_name LIKE %s OR (um.meta_key = 'billing_phone' AND um.meta_value LIKE %s)
                LIMIT 20
            ", '%' . $text . '%', '%' . $text . '%'));
            
            if (empty($users)) {
                send_bale_message($chat_id, "❌ یافت نشد. دوباره تلاش کنید:", array('inline_keyboard' => array(array(array('text' => '🏠 بازگشت', 'callback_data' => 'back_to_menu')))));
            } else {
                send_bale_message($chat_id, "🔍 نتایج جستجو:", get_search_results_keyboard($users));
                set_user_bale_step($bot_user_id, 'start');
            }
        }
    }
    http_response_code(200); echo 'OK'; exit;
}


add_filter('manage_users_columns', 'add_custom_user_columns');
function add_custom_user_columns($columns) {
    $columns['store_name'] = 'نام فروشگاه';
    $columns['store_address'] = 'آدرس فروشگاه';
    $columns['nb_actions'] = 'عملیات'; 
    return $columns;
}

add_action('manage_users_custom_column', 'show_custom_user_column_content', 10, 3);
function show_custom_user_column_content($value, $column_name, $user_id) {
    if ($column_name === 'store_name') return esc_html(get_user_meta($user_id, 'store_name', true)) ?: '—';
    if ($column_name === 'store_address') return esc_html(get_user_meta($user_id, 'store_address', true)) ?: '—';
    
    if ($column_name === 'nb_actions') {
        if (!my_is_site_admin_bale()) return '—';
        $is_approved = get_user_meta($user_id, 'user_approved', true);
        $phone = get_user_meta($user_id, 'billing_phone', true);
        $nonce = wp_create_nonce('bale_user_action_nonce');
        
        $html = '<div style="display:flex; flex-direction:column; gap:4px; max-width:140px;">';
        if (!is_allowed_role($user_id)) {
            if ($is_approved === '0' || $is_approved === '') {
                $html .= "<button type='button' class='button button-primary nb-approve-btn' data-id='{$user_id}' data-nonce='{$nonce}'>✅ تایید</button>";
                $html .= "<button type='button' class='button nb-reject-btn' data-id='{$user_id}' data-nonce='{$nonce}' style='color:#E2231A;'>❌ رد</button>";
                if (!empty($phone)) {
                    $html .= "<button type='button' class='button nb-sms-btn' data-id='{$user_id}' data-nonce='{$nonce}'>📩 پیامک تکمیل</button>";
                }
            } else {
                $html .= "<button type='button' class='button nb-reject-btn' data-id='{$user_id}' data-nonce='{$nonce}' style='color:#E2231A;'>لغو دسترسی</button>";
            }
        } else {
            $html .= '<span style="color:#888;">نقش مجاز</span>';
        }
        $html .= '</div>';
        return $html;
    }
    return $value;
}

add_action('wp_ajax_bale_approve_user', 'handle_bale_approve_user_ajax');
function handle_bale_approve_user_ajax() {
    if (!wp_verify_nonce($_POST['nonce'], 'bale_user_action_nonce')) wp_send_json_error('امنیت تایید نشد');
    $user_id = intval($_POST['user_id']);
    wp_send_json(approve_user_bale($user_id) ? array('success' => true, 'data' => 'تایید شد') : array('success' => false));
}

add_action('wp_ajax_bale_reject_user', 'handle_bale_reject_user_ajax');
function handle_bale_reject_user_ajax() {
    if (!wp_verify_nonce($_POST['nonce'], 'bale_user_action_nonce')) wp_send_json_error('امنیت تایید نشد');
    $user_id = intval($_POST['user_id']);
    wp_send_json(reject_user_bale($user_id) ? array('success' => true, 'data' => 'رد شد') : array('success' => false));
}

add_action('wp_ajax_bale_send_sms_user', 'handle_bale_send_sms_ajax');
function handle_bale_send_sms_ajax() {
    if (!wp_verify_nonce($_POST['nonce'], 'bale_user_action_nonce')) wp_send_json_error('امنیت تایید نشد');
    $user_id = intval($_POST['user_id']);
    $phone = get_user_meta($user_id, 'billing_phone', true);
    
    if ($phone) {
        $sms = new MeliPayamak();
        $user_info = get_userdata($user_id);
        $name = $user_info ? $user_info->display_name : 'کاربر';
        $sms_settings = get_sms_settings();
        
        if(!empty($sms_settings['profile_body_id'])) {
            $res = $sms->sendByBaseNumber($phone, array($name), $sms_settings['profile_body_id']);
        } else {
            $res = $sms->sendSMS($phone, "{$name} عزیز، لطفا فرم پروفایل را تکمیل کنید.");
        }
        
        if ($res['success']) wp_send_json_success('پیامک ارسال شد');
        else wp_send_json_error($res['error']);
    } else {
        wp_send_json_error('شماره تماس کاربر موجود نیست');
    }
}

add_action('admin_footer', 'nb_user_actions_ajax_script');
function nb_user_actions_ajax_script() {
    global $pagenow;
    if ($pagenow !== 'users.php') return;
    ?>
    <script>
    jQuery(document).ready(function($) {
        $('.nb-approve-btn, .nb-reject-btn, .nb-sms-btn').on('click', function(e) {
            e.preventDefault();
            var btn = $(this);
            var userId = btn.data('id');
            var nonce = btn.data('nonce');
            
            var action = 'bale_approve_user';
            if (btn.hasClass('nb-reject-btn')) action = 'bale_reject_user';
            if (btn.hasClass('nb-sms-btn')) action = 'bale_send_sms_user';
            
            var originalText = btn.text();
            btn.prop('disabled', true).text('صبر کنید...');
            
            $.post(ajaxurl, { action: action, user_id: userId, nonce: nonce }, function(response) {
                if(response.success) {
                    if (action === 'bale_send_sms_user') {
                        alert(response.data);
                        btn.prop('disabled', false).text('✅ ارسال شد');
                    } else {
                        location.reload();
                    }
                } else {
                    alert(response.data || 'خطایی رخ داد.');
                    btn.prop('disabled', false).text(originalText);
                }
            }).fail(function() {
                alert('خطا در ارتباط با سرور.');
                btn.prop('disabled', false).text(originalText);
            });
        });
    });
    </script>
    <?php
}

add_action('admin_menu', 'nb_bale_integration_menu');
function nb_bale_integration_menu() {
    add_menu_page('تنظیمات پیامک و ربات', 'تنظیمات ربات/پیامک', 'manage_options', 'nb-bale-settings', 'nb_bale_settings_page_html', 'dashicons-smartphone', 55);
}

function nb_bale_settings_page_html() {
    if (isset($_POST['nb_save_settings'])) {
        update_option('nb_sms_username', sanitize_text_field($_POST['nb_sms_username']));
        update_option('nb_sms_password', sanitize_text_field($_POST['nb_sms_password']));
        update_option('nb_sms_from', sanitize_text_field($_POST['nb_sms_from']));
        update_option('nb_sms_group_id', sanitize_text_field($_POST['nb_sms_group_id']));
        update_option('nb_sms_profile_body_id', sanitize_text_field($_POST['nb_sms_profile_body_id']));
        update_option('nb_bale_bot_token', sanitize_text_field($_POST['nb_bale_bot_token']));
        update_option('nb_bale_admin_chat_ids', sanitize_text_field($_POST['nb_bale_admin_chat_ids']));
        echo '<div class="updated"><p>تنظیمات ذخیره شد.</p></div>';
    }
    $sms = get_sms_settings();
    $bale = get_bale_settings();
    ?>
    <div class="wrap">
        <h1>تنظیمات ربات بله و پیامک</h1>
        <form method="post" action="">
            <table class="form-table">
                <tr><th>توکن ربات بله</th><td><input type="text" name="nb_bale_bot_token" value="<?php echo esc_attr($bale['bot_token']); ?>" class="regular-text"></td></tr>
                <tr><th>آیدی چت ادمین‌ها (با کاما جدا شود)</th><td><input type="text" name="nb_bale_admin_chat_ids" value="<?php echo esc_attr(implode(',', $bale['admin_chat_ids'])); ?>" class="regular-text"></td></tr>
                <tr><th>نام کاربری ملی‌پیامک</th><td><input type="text" name="nb_sms_username" value="<?php echo esc_attr($sms['username']); ?>" class="regular-text"></td></tr>
                <tr><th>کلمه عبور ملی‌پیامک</th><td><input type="password" name="nb_sms_password" value="<?php echo esc_attr($sms['password']); ?>" class="regular-text"></td></tr>
                <tr><th>شماره خط ارسال</th><td><input type="text" name="nb_sms_from" value="<?php echo esc_attr($sms['from']); ?>" class="regular-text"></td></tr>
                <tr><th>شناسه گروه دفترچه تلفن</th><td><input type="text" name="nb_sms_group_id" value="<?php echo esc_attr($sms['group_id']); ?>" class="regular-text"></td></tr>
                <tr><th>کد پترن (تکمیل پروفایل)</th><td><input type="text" name="nb_sms_profile_body_id" value="<?php echo esc_attr($sms['profile_body_id']); ?>" class="regular-text"></td></tr>
            </table>
            <p class="submit">
                <input type="submit" name="nb_save_settings" class="button button-primary" value="ذخیره تنظیمات">
                <button type="button" id="nb_test_sms" class="button button-secondary">تست ارسال پیامک به ادمین</button>
            </p>
        </form>
    </div>
    <script>
    jQuery('#nb_test_sms').on('click', function() {
        var btn = jQuery(this);
        var phone = prompt("شماره موبایل جهت تست ارسال پیامک را وارد کنید:");
        if(!phone) return;
        btn.prop('disabled', true).text('در حال ارسال...');
        jQuery.post(ajaxurl, { action: 'nb_test_sms_ajax', phone: phone }, function(res) {
            alert(res.data);
            btn.prop('disabled', false).text('تست ارسال پیامک به ادمین');
        });
    });
    </script>
    <?php
}

add_action('wp_ajax_nb_test_sms_ajax', 'nb_test_sms_ajax_handler');
function nb_test_sms_ajax_handler() {
    if (!current_user_can('manage_options')) wp_send_json_error('دسترسی ندارید');
    $phone = sanitize_text_field($_POST['phone']);
    $sms = new MeliPayamak();
    $res = $sms->sendSMS($phone, "تست ارتباط از سیستم وردپرس");
    if ($res['success']) wp_send_json_success('تست موفقیت آمیز بود.');
    else wp_send_json_error('خطا در تست: ' . $res['error']);
}

add_action('personal_options_update', 'save_custom_user_profile_fields');
add_action('edit_user_profile_update', 'save_custom_user_profile_fields');
function save_custom_user_profile_fields($user_id) {
    if (!current_user_can('edit_user', $user_id)) return false;

    $fields = array('store_name', 'store_address', 'national_code', 'store_type');
    $changed = false;
    
    foreach ($fields as $key) {
        if (isset($_POST[$key])) {
            $old_value = get_user_meta($user_id, $key, true);
            $new_value = sanitize_text_field($_POST[$key]);
            
            if ($old_value !== $new_value) {
                update_user_meta($user_id, $key, $new_value);
                
                // همگام سازی با آدرس صورت‌حساب ووکامرس
                if ($key === 'store_address') update_user_meta($user_id, 'billing_address_1', $new_value);
                if ($key === 'store_name') update_user_meta($user_id, 'billing_company', $new_value);
                
                $changed = true;
            }
        }
    }

    if ($changed && my_is_user_approved_bale($user_id) && !is_allowed_role($user_id)) {
        update_user_meta($user_id, 'user_approved', '0');
        send_approval_request_to_bale($user_id);
    }
}

add_action('woocommerce_save_account_details', 'save_custom_edit_account_fields', 10, 1);
function save_custom_edit_account_fields($user_id) {
    save_custom_user_profile_fields($user_id); // استفاده از تابع یکپارچه برای همگام‌سازی
}

add_action('user_register', 'set_default_unapproved_bale', 5);
function set_default_unapproved_bale($user_id) {
    update_user_meta($user_id, 'user_approved', is_allowed_role($user_id) ? '1' : '0');
}

add_action('init', 'add_personnel_role');
function add_personnel_role() {
    if (!get_role('personnel')) add_role('personnel', 'پرسنل', array('read' => true));
}