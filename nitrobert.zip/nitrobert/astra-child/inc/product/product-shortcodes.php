<?php
/**
 * Product Shortcodes Wrapper
 * This file converts all existing template parts into Elementor-ready shortcodes.
 * [product_gallery]
[product_price]
[product_meta_fields]
[product_specs]
[product_attributes]
[product_tags]
[product_actions]
[product_header]
[product_stock]
[product_related]

 */

if (!defined('ABSPATH')) exit;

/**
 * Helper function to load template parts safely.
 */
function ap_load_part($path) {
    $file = ASTRA_CHILD_DIR . $path;
    if (file_exists($file)) {
        ob_start();
        include $file;
        return ob_get_clean();
    }
    return '';
}

/*--------------------------------------
 * 1. Product Gallery
--------------------------------------*/
add_shortcode('product_gallery', function () {
    return ap_load_part('/template-parts/product/gallery.php');
});

/*--------------------------------------
 * 2. Product Price
--------------------------------------*/
add_shortcode('product_price', function () {
    return ap_load_part('/template-parts/product/price.php');
});

/*--------------------------------------
 * 3. Product Meta Fields
--------------------------------------*/
add_shortcode('product_meta_fields', function () {
    return ap_load_part('/template-parts/product/meta-fields.php');
});

/*--------------------------------------
 * 4. Product Specifications
--------------------------------------*/
add_shortcode('product_specs', function () {
    return ap_load_part('/template-parts/product/specs.php');
});

/*--------------------------------------
 * 5. Product Attributes
--------------------------------------*/
add_shortcode('product_attributes', function () {
    return ap_load_part('/template-parts/product/attributes.php');
});

/*--------------------------------------
 * 6. Product Tags
--------------------------------------*/
add_shortcode('product_tags', function () {
    return ap_load_part('/template-parts/product/tags.php');
});

/*--------------------------------------
 * 7. Product Actions (Add to cart & etc)
--------------------------------------*/
add_shortcode('product_actions', function () {
    return ap_load_part('/template-parts/product/actions.php');
});

/*--------------------------------------
 * 8. Product Stock (optional)
--------------------------------------*/
add_shortcode('product_stock', function () {
    return ap_load_part('/template-parts/product/stock.php');
});

/*--------------------------------------
 * 9. Product Header (optional)
--------------------------------------*/
add_shortcode('product_header', function () {
    return ap_load_part('/template-parts/product/header.php');
});

/*--------------------------------------
 * 10. Related Products
--------------------------------------*/
add_shortcode('product_related', function () {
    return ap_load_part('/template-parts/product/related.php');
});

/**
 * ALL TEMPLATE PARTS ARE NOW USABLE IN ELEMENTOR
 */
