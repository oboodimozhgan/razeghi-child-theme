<?php
/**
 * Astra Child Theme - Auto Parts
 * 
 * @package Astra Child
 */

defined('ABSPATH') || exit;

/**
 * تعریف ثابت‌ها
 */
define('ASTRA_CHILD_VERSION', '1.0.0');
define('ASTRA_CHILD_DIR', get_stylesheet_directory());
define('ASTRA_CHILD_URI', get_stylesheet_directory_uri());

/**
 * Enqueue استایل‌ها و اسکریپت‌ها
 */
function astra_child_enqueue_styles() {
    // استایل پدر
    wp_enqueue_style('astra-parent', get_template_directory_uri() . '/style.css', [], ASTRA_CHILD_VERSION);
    
    // استایل چایلد
    wp_enqueue_style('astra-child', get_stylesheet_uri(), ['astra-parent'], ASTRA_CHILD_VERSION);
    
    // استایل صفحه محصول (کاملا ایزوله)
    if (is_product()) {
        $isolated_css_path = ASTRA_CHILD_DIR . '/assets/css/product-page-isolated.css';

        // استایل ایزوله صفحه محصول (Scoped to ap-* classes)
        wp_enqueue_style(
            'ap-product-page-isolated',
            ASTRA_CHILD_URI . '/assets/css/product-page-isolated.css',
            ['astra-child'],
            file_exists($isolated_css_path) ? filemtime($isolated_css_path) : ASTRA_CHILD_VERSION,
            'all'
        );
    }
}
add_action('wp_enqueue_scripts', 'astra_child_enqueue_styles');

/**
 * پشتیبانی از WooCommerce
 */
function astra_child_woocommerce_support() {
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');
}
add_action('after_setup_theme', 'astra_child_woocommerce_support');

/**
 * بارگذاری کلاس‌ها و هوک‌ها
 */
require_once ASTRA_CHILD_DIR . '/inc/product/class-product-meta.php';
require_once ASTRA_CHILD_DIR . '/inc/product/class-product-schema.php';
require_once ASTRA_CHILD_DIR . '/inc/product/class-product-partner.php';
require_once ASTRA_CHILD_DIR . '/inc/product/product-hooks.php';
require_once ASTRA_CHILD_DIR . '/meta-fild.php';
require_once ASTRA_CHILD_DIR . '/inc/product/product-shortcodes.php';

/**
 * اضافه کردن نقش Partner
 */
function astra_child_add_partner_role() {
    if (!get_role('partner')) {
        add_role('partner', 'همکار', [
            'read' => true,
            'edit_posts' => false,
            'delete_posts' => false,
        ]);
    }
}
add_action('init', 'astra_child_add_partner_role');

/**
 * غیرفعال کردن sidebar در صفحه محصول
 */
function astra_child_remove_product_sidebar($layout) {
    if (is_product()) {
        return 'no-sidebar';
    }
    return $layout;
}
add_filter('astra_page_layout', 'astra_child_remove_product_sidebar');
