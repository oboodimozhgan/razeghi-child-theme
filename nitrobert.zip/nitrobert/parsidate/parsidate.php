<?php

// Include the jdf.php file
require_once(__DIR__ . '/jdf.php');

// Function to convert WordPress dates to Persian dates
function convert_to_persian_date($date, $format = 'j F Y') {
    if (empty($date)) {
        return '';
    }

    // Convert the date to timestamp
    $timestamp = strtotime($date);

    // Check if conversion was successful
    if ($timestamp === false) {
        return $date; // Return original date if conversion fails
    }

    // Use jdf to convert the timestamp to Persian date
    return jdate($format, $timestamp);
}

// Filter the WordPress date functions
function setup_persian_date_filters() {
    // Filter post dates
    add_filter('the_time', function($time) {
        return convert_to_persian_date($time);
    });

    add_filter('get_the_date', function($date) {
        return convert_to_persian_date($date);
    });

    add_filter('get_the_time', function($time) {
        return convert_to_persian_date($time);
    });

    add_filter('get_comment_date', function($date) {
        return convert_to_persian_date($date);
    });

    add_filter('get_comment_time', function($time) {
        return convert_to_persian_date($time);
    });

    // Filter archive titles
    add_filter('get_the_archive_title', function($title) {
        if (is_date()) {
            return convert_to_persian_date($title);
        }
        return $title;
    });
}

// Hook into WordPress to apply the filters
add_action('init', 'setup_persian_date_filters');

// Handle Elementor widgets content
add_action('elementor/widget/render_content', function($content) {
    return preg_replace_callback('/\d{1,2}\s[A-Za-z]+\s\d{4}/', function($matches) {
        return convert_to_persian_date($matches[0]);
    }, $content);
}, 10, 1);

// Handle Elementor dynamic tags for post date
add_filter('elementor_pro/dynamic_tags/get_value', function($value, $tag) {
    if ($tag->get_name() === 'post-date') {
        return convert_to_persian_date($value);
    }
    return $value;
}, 10, 2);

?>
