<?php
/**
 * Astra Child Theme – Product System + Elementor Shortcodes
 */

defined('ABSPATH') || exit;

/*----------------------------------------------
| ثابت‌ها
----------------------------------------------*/
define('ASTRA_CHILD_VERSION', '1.0.0');
define('ASTRA_CHILD_DIR', get_stylesheet_directory());
define('ASTRA_CHILD_URI', get_stylesheet_directory_uri());

/*----------------------------------------------
| استایل‌ها
----------------------------------------------*/
add_action('wp_enqueue_scripts', function () {


    $is_login_page = ( isset($GLOBALS['pagenow']) && in_array($GLOBALS['pagenow'], ['wp-login.php', 'wp-register.php']) );


    if ( is_admin() || $is_login_page ) {
        return;
    }


    wp_enqueue_style(
        'astra-parent',
        get_template_directory_uri() . '/style.css',
        [],
        ASTRA_CHILD_VERSION
    );

 
    wp_enqueue_style(
        'astra-child',
        get_stylesheet_uri(),
        ['astra-parent'],
        ASTRA_CHILD_VERSION
    );


    if (is_product()) {
        $file = ASTRA_CHILD_DIR . '/assets/css/product-page-isolated.css';
        wp_enqueue_style(
            'ap-product-page-isolated',
            ASTRA_CHILD_URI . '/assets/css/product-page-isolated.css',
            ['astra-child'],
            file_exists($file) ? filemtime($file) : ASTRA_CHILD_VERSION
        );
    }
});

add_action('after_setup_theme', function () {
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');
});


require_once ASTRA_CHILD_DIR . '/inc/product/class-product-meta.php';
require_once ASTRA_CHILD_DIR . '/inc/product/class-product-schema.php';
require_once ASTRA_CHILD_DIR . '/inc/product/class-product-partner.php';
require_once ASTRA_CHILD_DIR . '/inc/product/product-hooks.php';
require_once ASTRA_CHILD_DIR . '/meta-fild.php';
require_once ASTRA_CHILD_DIR . '/inc/product/product-shortcodes.php';
require_once ASTRA_CHILD_DIR . '/nb-includes/mnu-cat.php';


add_action('init', function () {
    if (!get_role('partner')) {
        add_role('partner', 'همکار', [
            'read'         => true,
            'edit_posts'   => false,
            'delete_posts' => false,
        ]);
    }
});


add_filter('astra_page_layout', function ($layout) {
    return is_product() ? 'no-sidebar' : $layout;
});


add_action('woocommerce_checkout_update_order_meta', function ($order_id) {

    if (!$order = wc_get_order($order_id)) return;

    $state = $order->get_shipping_state();
    $city  = $order->get_shipping_city();

    if ($city || $state) {
        $order->add_order_note("شهر مقصد: {$city} - استان: {$state}");
    }
});

function nb_custom_mini_cart()
{
    ob_start(); ?>

    <div class="nb-mini-cart">
        <div class="nb-basket-item-count">
            <span class="nb-cart-items-count">
                <?php echo esc_html(WC()->cart->get_cart_contents_count()); ?>
            </span>
        </div>

        <div class="nb-dropdown-menu-mini-cart">
            <div class="nb-widget-shopping-cart-content">
                <?php woocommerce_mini_cart(); ?>
            </div>
        </div>
    </div>

<?php
    return ob_get_clean();
}
add_shortcode('quadlayers-mini-cart', 'nb_custom_mini_cart');


add_shortcode('cart_item_count_only', function () {
    if (class_exists('WooCommerce') && WC()->cart)
        return WC()->cart->get_cart_contents_count();
    return 0;
});

add_filter('mime_types', function ($mime_types) {
    $mime_types['webp'] = 'image/webp';
    $mime_types['avif'] = 'image/avif';
    return $mime_types;
});

add_filter('wp_check_filetype_and_ext', function ($checked, $file, $filename, $mimes) {
    $ft = wp_check_filetype($filename, $mimes);
    if ($ft['ext'] === 'avif') {
        return [
            'ext'             => $ft['ext'],
            'type'            => $ft['type'],
            'proper_filename' => $filename,
        ];
    }
    return $checked;
}, 10, 4);


add_filter('use_block_editor_for_post', '__return_false');
add_filter('use_widgets_block_editor', '__return_false');



require_once __DIR__ . "/nb-includes/me-code-customize.php";
require_once __DIR__ . "/nb-includes/costom-dashboard.php";
require_once __DIR__ . "/nb-includes/woo-custom.php";
//require_once __DIR__ . "/nb-includes/visitor-dashboard.php";
require_once __DIR__ . "/nb-includes/full-slider.php";
require_once __DIR__ . "/nb-includes/restrict-pages.php";



require_once __DIR__ . "/nb-includes/ziro-price.php";
//require_once __DIR__ . "/nb-includes/pro-tax-carousel.php";
require_once __DIR__ . "/nb-includes/product-taxonomy-manager.php";
require_once __DIR__ . "/nb-includes/pro-tax-grid.php";




add_filter( 'gettext', 'find_source_of_nothing_found_string', 999, 3 );
function find_source_of_nothing_found_string( $translated_text, $text, $domain ) {
    if ( strpos( $translated_text, 'چیزی در اینجا پیدا نشد' ) !== false ) {
        return $translated_text . ' <span style="color:red;font-weight:bold;">[منبع: ' . $domain . ']</span>';
    }
    return $translated_text;
}

// فارسی کردن متن سبد خرید خالی
add_filter('gettext', function($translated_text, $text, $domain) {

    if ($text === 'No products in the cart.') {
        return 'سبد خرید شما خالی است.';
    }

    return $translated_text;

}, 20, 3);


add_filter( 'woocommerce_related_products', 'custom_car_related_products_by_model', 10, 3 );

function custom_car_related_products_by_model( $related_posts, $product_id, $args ) {
    


    $car_models = wp_get_post_terms( $product_id, 'car_model', array( 'fields' => 'ids' ) );
    
 
    if ( empty( $car_models ) || is_wp_error( $car_models ) ) {
        return $related_posts; 
    }

    $custom_args = array(
        'post_type'      => 'product',
        'post_status'    => 'publish',
        'posts_per_page' => 4, 
        'post__not_in'   => array( $product_id ), 
        'tax_query'      => array(
            array(
                'taxonomy' => 'car_model',
                'field'    => 'term_id',
                'terms'    => $car_models,
                'operator' => 'IN', 
            ),
  
        ),
    );

    $custom_query = new WP_Query( $custom_args );
    
    $custom_related_ids = wp_list_pluck( $custom_query->posts, 'ID' );

    if ( ! empty( $custom_related_ids ) ) {
        return $custom_related_ids;
    }

    return $related_posts;
}




add_action('admin_menu', 'native_car_groups_menu');
function native_car_groups_menu() {
    add_menu_page(
        'گروه‌بندی قطعات مشترک', 
        'گروه قطعات', 
        'manage_options', 
        'native-car-groups', 
        'native_car_groups_page_html', 
        'dashicons-networking', 
        55
    );
}

add_action('admin_init', 'native_car_groups_settings_init');
function native_car_groups_settings_init() {
    register_setting('native_car_groups_plugin', 'native_car_groups_data');
}

function native_car_groups_page_html() {
    if (!current_user_can('manage_options')) return;

    $groups = get_option('native_car_groups_data', array());
    if (!is_array($groups)) $groups = array();

    $car_models = get_terms(array(
        'taxonomy'   => 'car_model',
        'hide_empty' => false,
    ));
    ?>
    <style>
        .car-checkbox-list {
            max-height: 150px;
            overflow-y: auto;
            border: 1px solid #ccd0d4;
            padding: 10px;
            background: #fff;
            border-radius: 4px;
            width: 100%;
            max-width: 350px;
            box-shadow: inset 0 1px 2px rgba(0,0,0,.07);
        }
        .car-checkbox-list label {
            display: block;
            margin-bottom: 6px;
            font-size: 13px;
        }
        .car-checkbox-list input[type="checkbox"] {
            margin-left: 5px;
        }
        .saved-cars-preview {
            margin-top: 8px;
            font-size: 11px;
            color: #50575e;
            background: #f0f0f1;
            padding: 6px 10px;
            border-radius: 4px;
            border: 1px solid #c3c4c7;
            line-height: 1.6;
            max-width: 25em;
        }
    </style>

    <div class="wrap">
        <h1>گروه‌بندی قطعات مشترک</h1>
        <p>گروه‌های خودرویی که قطعات مشترک دارند را با تیک زدن خودروها مشخص کنید.</p>
        
        <form action="options.php" method="post">
            <?php settings_fields('native_car_groups_plugin'); ?>
            
            <table class="form-table" id="car-groups-table">
                <thead>
                    <tr>
                        <th style="text-align: right; width: 35%;">نام گروه</th>
                        <th style="text-align: right;">خودروهای زیرمجموعه (انتخاب با تیک)</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody id="car-groups-tbody">
                    <?php 
                    $row_index = 0;
                    if (!empty($groups)) {
                        foreach ($groups as $group) { 
                            $group_name = isset($group['name']) ? esc_attr($group['name']) : '';
                            $selected_cars = isset($group['cars']) ? (array) $group['cars'] : array();
                            
                            $selected_car_names = array();
                            if (!empty($selected_cars) && !is_wp_error($car_models)) {
                                foreach ($car_models as $term) {
                                    if (in_array($term->term_id, $selected_cars)) {
                                        $selected_car_names[] = esc_html($term->name);
                                    }
                                }
                            }
                            ?>
                            <tr data-index="<?php echo $row_index; ?>">
                                <td style="vertical-align: top;">
                                    <input type="text" name="native_car_groups_data[<?php echo $row_index; ?>][name]" value="<?php echo $group_name; ?>" class="regular-text" placeholder="مثلا: گروه TU5" required style="width: 100%; max-width: 25em;" />
                                    
                                    <?php if (!empty($selected_car_names)): ?>
                                        <div class="saved-cars-preview">
                                            <strong>شامل:</strong> <?php echo implode('، ', $selected_car_names); ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="car-checkbox-list">
                                        <?php 
                                        if (!is_wp_error($car_models) && !empty($car_models)) {
                                            foreach ($car_models as $term) {
                                                $checked = in_array($term->term_id, $selected_cars) ? 'checked' : '';
                                                echo '<label>';
                                                echo '<input type="checkbox" name="native_car_groups_data[' . $row_index . '][cars][]" value="' . esc_attr($term->term_id) . '" ' . $checked . '>';
                                                echo esc_html($term->name);
                                                echo '</label>';
                                            }
                                        }
                                        ?>
                                    </div>
                                </td>
                                <td style="vertical-align: top;">
                                    <button type="button" class="button remove-row" style="color: #d63638; border-color: #d63638;">حذف گروه</button>
                                </td>
                            </tr>
                            <?php 
                            $row_index++;
                        }
                    }
                    ?>
                </tbody>
            </table>
            
            <p style="margin-top: 20px;">
                <button type="button" class="button button-primary" id="add-group-row">افزودن گروه جدید +</button>
            </p>
            
            <hr>
            <?php submit_button('ذخیره تغییرات'); ?>
        </form>
    </div>

    <script>
    jQuery(document).ready(function($) {
        var rowIndex = <?php echo $row_index; ?>;
        
        $('#add-group-row').on('click', function() {
            var newRow = `
                <tr data-index="${rowIndex}">
                    <td style="vertical-align: top;">
                        <input type="text" name="native_car_groups_data[${rowIndex}][name]" value="" class="regular-text" placeholder="مثلا: گروه جدید" required style="width: 100%; max-width: 25em;" />
                    </td>
                    <td>
                        <div class="car-checkbox-list">
                            <?php 
                            if (!is_wp_error($car_models) && !empty($car_models)) {
                                foreach ($car_models as $term) {
                                    echo '<label>';
                                    echo '<input type="checkbox" name="native_car_groups_data[${rowIndex}][cars][]" value="' . esc_attr($term->term_id) . '">';
                                    echo esc_html($term->name);
                                    echo '</label>';
                                }
                            }
                            ?>
                        </div>
                    </td>
                    <td style="vertical-align: top;">
                        <button type="button" class="button remove-row" style="color: #d63638; border-color: #d63638;">حذف گروه</button>
                    </td>
                </tr>
            `;
            $('#car-groups-tbody').append(newRow);
            rowIndex++;
        });

        $(document).on('click', '.remove-row', function() {
            if(confirm('آیا از حذف این گروه مطمئن هستید؟')) {
                $(this).closest('tr').remove();
            }
        });
    });
    </script>
    <?php
}

add_action('elementor/query/shared_car_parts', 'nitrobert_elementor_shared_cars_query');

function nitrobert_elementor_shared_cars_query($query) {
  
    if (!is_singular('product')) {
        return;
    }

    $product_id = get_the_ID();
    $product_terms = wp_get_post_terms($product_id, 'car_model', array('fields' => 'ids'));
    

    if (empty($product_terms) || is_wp_error($product_terms)) {
        $query->set('post__in', array(0));
        return;
    }

 
    $car_groups = get_option('native_car_groups_data', array());
    $target_term_ids = array();

    if (!empty($car_groups) && is_array($car_groups)) {
        foreach ($car_groups as $row) {
            if (isset($row['cars']) && is_array($row['cars'])) {
                $group_cars = array_map('intval', $row['cars']);
                $intersect = array_intersect($product_terms, $group_cars);
                
                if (!empty($intersect)) {
                    $target_term_ids = array_merge($target_term_ids, $group_cars);
                }
            }
        }
    }

    $target_term_ids = array_unique($target_term_ids);
    if (empty($target_term_ids)) {
        $target_term_ids = $product_terms;
    }

 
    $tax_query = $query->get('tax_query') ?: array();
    
    $tax_query[] = array(
        'taxonomy' => 'car_model',
        'field'    => 'term_id',
        'terms'    => $target_term_ids,
        'operator' => 'IN',
    );

    $query->set('tax_query', $tax_query);
    $query->set('post__not_in', array($product_id)); // محصول فعلی را نشان نده
}



function asbpart_auto_categorize_products_v2() {
    if ( ! isset( $_GET['run_asbpart_categorize'] ) || ! current_user_can( 'manage_options' ) ) {
        return;
    }

    global $wpdb;
    $taxonomy = 'product_cat';

 
    $categories_map = [
        1951 => [ 
            'کمک فنر و پایه کمک' => ['کمک فنر', 'پایه کمک'],
            'سیبک ها'           => ['سیبک'],
            'بوش ها'            => ['بوش'],
            'پلوس و مشعلی'       => ['پلوس', 'مشعلی', 'گردگیر پلوس'],
            'میل موج گیر'        => ['موجگیر', 'موج گیر', 'میل تعادل'],
            'جعبه فرمان'         => ['جعبه فرمان', 'شیر فرمان'],
            'طبق جلو و عقب'      => ['طبق'],
        ],
        1954 => [ // قطعات موتوری
            'تسمه ها'            => ['تسمه تایم', 'تسمه دینام', 'تسمه کولر', 'تسمه'],
            'واشرها'            => ['واشر سرسیلندر', 'واشر درب', 'واشر اگزوز', 'واشر'],
            'واتر پمپ و اویل پمپ'=> ['واتر پمپ', 'اویل پمپ', 'واترپمپ', 'اویل‌پمپ'],
            'پیستون و رینگ'      => ['پیستون', 'رینگ پیستون', 'گژنپین'],
            'یاتاقان'           => ['یاتاقان'],
            'سوپاپ'             => ['سوپاپ', 'لاستیک ساق'],
            'دسته موتورها'       => ['دسته موتور'],
        ],
        1956 => [ // قطعات تزئینی و بدنه
            'چراغ ها'            => ['چراغ', 'خطر', 'مه شکن', 'پروژکتور'],
            'سپر و دیاق'         => ['سپر', 'دیاق'],
            'آینه بغل'           => ['آینه'],
            'جلو پنجره و آرم'    => ['جلو پنجره', 'آرم'],
            'گلگیر و کاپوت'      => ['گلگیر', 'کاپوت', 'درب'],
            'زه و نوارهای لاستیکی'=> ['زه', 'نوار لاستیکی'],
            'تزئینات کابین'      => ['داشبورد', 'روکش', 'دستگیره'],
        ],
        1950 => [ // قطعات برقی
            'سنسورها'           => ['سنسور'],
            'کوئل و شمع'         => ['کوئل', 'کویل', 'شمع', 'وایر'],
            'استارت'            => ['استارت'],
            'دینام و آفتامات'    => ['دینام', 'آفتامات'],
            'پمپ بنزین'         => ['پمپ بنزین', 'مغزی پمپ'],
            'رله ها و فیوزها'    => ['رله', 'فیوز'],
            'موتور برف پاک کن'   => ['برف پاک کن', 'شیشه شور', 'شیشه‌شور'],
        ],
        // دو دسته زیر در تصاویر نبودند اما در دیتابیس شما وجود دارند (با آیدی‌های جدید اضافه شد)
        2040 => [ // سیستم رادیاتور
            'رادیاتور آب'        => ['رادیاتور آب', 'رادیاتور پژو', 'رادیاتور سمند', 'رادیاتور پراید'],
            'رادیاتور کولر'      => ['کندانسور', 'رادیاتور کولر'],
            'رادیاتور بخاری'     => ['رادیاتور بخاری'],
            'موتور فن و پروانه'  => ['موتور فن', 'پروانه', 'دیاق فن'],
            'ترموستات'          => ['ترموستات', 'هوزینگ'],
            'شیلنگ‌ها'           => ['شیلنگ', 'لوله'],
        ],
        2041 => [ // قطعات سیستم بلبرینگ
            'بلبرینگ چرخ'        => ['بلبرینگ چرخ'],
            'بلبرینگ کلاچ'       => ['بلبرینگ کلاچ', 'پمپ کلاچ'],
            'بلبرینگ دینام'      => ['بلبرینگ دینام'],
            'بلبرینگ گیربکس'     => ['بلبرینگ گیربکس'],
            'هرزگردها'           => ['هرزگرد', 'تسمه سفت کن'],
            'رولبرینگ‌ها'         => ['رولبرینگ'],
        ],
    ];

    $log = [];

    foreach ( $categories_map as $parent_id => $subcategories ) {
        foreach ( $subcategories as $subcat_name => $keywords ) {
            
            $term_exists = term_exists( $subcat_name, $taxonomy, $parent_id );
            
            if ( ! $term_exists ) {
                $inserted_term = wp_insert_term( $subcat_name, $taxonomy, array( 'parent' => $parent_id ) );
                if ( is_wp_error( $inserted_term ) ) continue;
                $term_id = $inserted_term['term_id'];
            } else {
                $term_id = is_array( $term_exists ) ? $term_exists['term_id'] : $term_exists;
            }

            foreach ( $keywords as $keyword ) {
                $query = $wpdb->prepare( "
                    SELECT ID FROM {$wpdb->posts} 
                    WHERE post_type = 'product' 
                    AND post_status IN ('publish', 'draft', 'pending') 
                    AND post_title LIKE %s
                ", '%' . $wpdb->esc_like( $keyword ) . '%' );
                
                $post_ids = $wpdb->get_col( $query );

                if ( ! empty( $post_ids ) ) {
                    foreach ( $post_ids as $post_id ) {
                        wp_set_object_terms( (int) $post_id, (int) $term_id, $taxonomy, true );
                    }
                    $log[] = "کلمه '{$keyword}': اتصال " . count( $post_ids ) . " محصول به '{$subcat_name}'.";
                }
            }
        }
    }

    clean_term_cache( '', $taxonomy );

    echo '<div style="background:#121212; color:#fff; border:2px solid #e63946; padding:20px; margin:20px; direction:rtl; font-family:tahoma;">';
    echo '<h3 style="color:#e63946;">عملیات با موفقیت انجام شد!</h3><ul>';
    foreach ( $log as $message ) { echo "<li>{$message}</li>"; }
    echo '</ul><p><b>لطفا پارامتر run_asbpart_categorize=1 را از URL حذف کنید.</b></p></div>';
    die();
}
add_action( 'admin_init', 'asbpart_auto_categorize_products_v2' );


//******//
function custom_auth_user_button_shortcode() {
    // بررسی اینکه آیا کاربر وارد حساب خود شده است یا خیر
    if ( is_user_logged_in() ) {
        
        // آدرس برگه پنل کاربری خود را اینجا وارد کنید (مثلا /my-account یا /panel)
        $panel_url = home_url('/my-account'); 
        
        $output = '
        <div class="button-group">
            <a href="' . esc_url($panel_url) . '" class="button-colored">پنل کاربری</a>
        </div>
        ';
        
    } else {
        // اگر کاربر وارد نشده بود (حالت مهمان)
        $output = '
        <div class="button-group">
            <a href="https://razeghiparts.com/auth" class="button-colored">ورود | ثبت‌نام</a>
        </div>
        ';
    }
    
    return $output;
}
add_shortcode( 'user_auth_button', 'custom_auth_user_button_shortcode' );

function redirect_anonymous_users_to_login() {
 
    if ( ! is_user_logged_in() && is_page('my-account') ) {
        
     
        $login_url = 'https://razeghiparts.com/auth';
        
  
        wp_redirect( $login_url );
        exit;
    }
}

add_action( 'template_redirect', 'redirect_anonymous_users_to_login' );



class WP_Advanced_Taxonomy_Tree {

    public static function get_full_tree() {
        global $wpdb;

 
        $taxonomies = array( 'product_cat', 'car_brand', 'car_model', 'part_brand' );
        $placeholders = implode( ',', array_fill( 0, count( $taxonomies ), '%s' ) );

        $query = $wpdb->prepare("
            SELECT tr.object_id, tt.taxonomy, t.term_id, t.name 
            FROM {$wpdb->term_relationships} tr
            INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
            INNER JOIN {$wpdb->terms} t ON tt.term_id = t.term_id
            WHERE tt.taxonomy IN ($placeholders)
        ", $taxonomies);

        $results = $wpdb->get_results( $query );

        $products_data = array();
        if ( $results ) {
            foreach ( $results as $row ) {
                $products_data[ $row->object_id ][ $row->taxonomy ][] = array(
                    'id'   => $row->term_id,
                    'name' => $row->name
                );
            }
        }

        $tree = array();

        foreach ( $products_data as $product_id => $data ) {
            // استفاده از نامک صحیح product_cat
            if ( empty( $data['product_cat'] ) ) continue;

            $cats     = $data['product_cat'];
            $brands   = isset( $data['car_brand'] ) ? $data['car_brand'] : array();
            $models   = isset( $data['car_model'] ) ? $data['car_model'] : array();
            $p_brands = isset( $data['part_brand'] ) ? $data['part_brand'] : array();

            foreach ( $cats as $cat ) {
                $c_id = $cat['id'];
                if ( ! isset( $tree[ $c_id ] ) ) {
                    $tree[ $c_id ] = array( 'name' => $cat['name'], 'car_brands' => array() );
                }

                foreach ( $brands as $brand ) {
                    $b_id = $brand['id'];
                    if ( ! isset( $tree[ $c_id ]['car_brands'][ $b_id ] ) ) {
                        $tree[ $c_id ]['car_brands'][ $b_id ] = array( 'name' => $brand['name'], 'car_models' => array() );
                    }

                    foreach ( $models as $model ) {
                        $m_id = $model['id'];
                        if ( ! isset( $tree[ $c_id ]['car_brands'][ $b_id ]['car_models'][ $m_id ] ) ) {
                            $tree[ $c_id ]['car_brands'][ $b_id ]['car_models'][ $m_id ] = array( 'name' => $model['name'], 'part_brands' => array() );
                        }

                        foreach ( $p_brands as $pb ) {
                            $pb_id = $pb['id'];
                            $tree[ $c_id ]['car_brands'][ $b_id ]['car_models'][ $m_id ]['part_brands'][ $pb_id ] = $pb['name'];
                        }
                    }
                }
            }
        }

        $final_tree = array();
        foreach ( $tree as $cat ) {
            $cat_data = array( 'category' => $cat['name'], 'brands' => array() );
            
            foreach ( $cat['car_brands'] as $brand ) {
                $brand_data = array( 'brand' => $brand['name'], 'models' => array() );
                
                foreach ( $brand['car_models'] as $model ) {
                    $brand_data['models'][] = array(
                        'model'       => $model['name'],
                        'part_brands' => array_values( $model['part_brands'] )
                    );
                }
                $cat_data['brands'][] = $brand_data;
            }
            $final_tree[] = $cat_data;
        }

        return $final_tree;
    }
}

// ========================================================================
// بخش نمایش با شورت‌کد
// استفاده: [parts_taxonomy_tree]
// ========================================================================
add_shortcode( 'parts_taxonomy_tree', 'render_parts_taxonomy_tree' );
function render_parts_taxonomy_tree() {
    $data = WP_Advanced_Taxonomy_Tree::get_full_tree();

    ob_start();
    // استایل مینیمال و سایبر-نئون برای خوانایی بهتر توسعه‌دهنده
    echo '<div dir="ltr" style="background: #0a0a0f; color: #a5b4fc; padding: 25px; border-radius: 12px; border: 1px solid #00ffcc; font-family: monospace; overflow-x: auto; max-height: 600px; overflow-y: auto; margin-bottom: 20px; box-shadow: 0 4px 20px rgba(0, 255, 204, 0.1);">';
    echo '<h3 style="color: #00ffcc; border-bottom: 1px solid #1f2937; padding-bottom: 12px; margin-top: 0;">خروجی روابط ۴ سطحی قطعات</h3>';
    echo '<pre style="white-space: pre-wrap; word-wrap: break-word; font-size: 14px;">';
    print_r( $data );
    echo '</pre>';
    echo '</div>';
    
    return ob_get_clean();
}

// ========================================================================
// بخش لینک مستقیم (Endpoint) برای دریافت دیتا با فرمت JSON
// نمونه لینک: yoursite.com/?export_parts_tree=true
// ========================================================================
add_action( 'template_redirect', 'handle_parts_tree_endpoint' );
function handle_parts_tree_endpoint() {
    if ( isset( $_GET['export_parts_tree'] ) && $_GET['export_parts_tree'] === 'true' ) {
        $data = WP_Advanced_Taxonomy_Tree::get_full_tree();

        nocache_headers();
        header( 'Content-Type: application/json; charset=utf-8' );
        
        echo wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
        exit;
    }
}




add_filter( 'woocommerce_product_description_heading', '__return_false' );


add_filter( 'woocommerce_product_additional_information_heading', '__return_false' );


add_filter( 'woocommerce_reviews_title', '__return_false' );




add_action('wp_head', 'nitrobert_developer_signature');

function nitrobert_developer_signature() {
 
    echo "\n<!-- 🚀 Designed & Developed by Nitrobert Team | https://nitrobert.com | Phone: [09175347869] -->\n";
    
 
    echo "<script>
        console.log(
            '%c💻 Developed & Optimized by Nitrobert Team \\n🌐 Website: https://nitrobert.com \\n📞 Contact:[09175347869]', 
            'color: #ffffff; background: #1a1a1a; font-size: 13px; padding: 12px 16px; border-radius: 6px; border-right: 4px solid #0073aa; line-height: 1.6; font-family: monospace;'
        );
    </script>\n";
}



/**
 * افزودن دکمه شناور با اطلاعات تماس و شبکه‌های اجتماعی (قابل جمع‌شدن)
 * در گوشه پایین سمت چپ صفحه - مخفی در موبایل + افکت موج با قطر کمتر و مخفی شدن در حالت باز
 */
function floating_contact_toggle() {
    // اطلاعات تماس (قابل ویرایش)
    $phone_numbers = [
        '09170555640',
        '09170555740',
        '09170555840'
    ];
    $addresses = [
        'شیراز، دروازه قرآن، روبروی آبزنگی',
        'بوشهر، بلوار طالقانی، نبش خیابان جمهوری اسلامی'
    ];
    
    // لینک‌های شبکه‌های اجتماعی (آیکون‌های Font Awesome)
    $social_links = [
        'fa-instagram' => 'https://instagram.com/ghatat_khodro_razeghi',
    ];

    ?>
    <!-- Font Awesome (برای آیکون‌ها) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        /* استایل دکمه شناور و کارت اطلاعات */
        .floating-toggle-container {
            position: fixed;
            bottom: 30px;
            left: 30px;
            z-index: 9999;
            direction: rtl;
            font-family: 'IRANSans', Tahoma, Arial, sans-serif;
        }

        /* دکمه اصلی (آیکون) - رنگ قرمز ثابت */
        .floating-toggle-btn {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: #e2231a !important;
            color: #fff;
            border: none;
            box-shadow: 0 4px 15px rgba(226, 35, 26, 0.4);
            font-size: 28px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            z-index: 2;
        }
        .floating-toggle-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 6px 20px rgba(226, 35, 26, 0.6);
        }
        .floating-toggle-btn i {
            transition: transform 0.4s ease;
        }
        .floating-toggle-btn.open i {
            transform: rotate(45deg);
        }

        /* ===== افکت موج ===== */
        .ripple {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 70px;
            height: 70px;
            border-radius: 50%;
            border: 3px solid #e2231a;
            opacity: 0.7;
            pointer-events: none;
            z-index: 1;
            animation: ripple-anim 4s ease-out infinite;
        }
        .ripple:nth-of-type(2) {
            animation-delay: 1.3s;
        }
        .ripple:nth-of-type(3) {
            animation-delay: 2.6s;
        }

        @keyframes ripple-anim {
            0% {
                transform: translate(-50%, -50%) scale(1);
                opacity: 0.8;
            }
            100% {
                transform: translate(-50%, -50%) scale(2.2); /* قطر کمتر */
                opacity: 0;
            }
        }

        /* مخفی کردن امواج زمانی که دکمه باز است (کارت نمایش داده می‌شود) */
        .floating-toggle-btn.open ~ .ripple {
            opacity: 0 !important;
            animation: none !important;
        }
        /* ============================== */

        /* کارت اطلاعات */
        .floating-info-card {
            position: absolute;
            bottom: 52px;
            left: 44px;
            background: #ffffff;
            border-radius: 16px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.2);
            padding: 5px 5px;
            min-width: 250px;
            max-width: 300px;
            opacity: 0;
            visibility: hidden;
            transform: translateY(20px) scale(0.95);
            transition: all 0.35s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid #f0f0f0;
            pointer-events: none;
        }
        .floating-info-card.active {
            opacity: 1;
            visibility: visible;
            transform: translateY(0) scale(1);
            pointer-events: auto;
        }
        .floating-info-card .contact-item {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
            color: #444;
            margin: 8px 0;
            line-height: 1.6;
            flex-direction: row-reverse;
            justify-content: flex-start;
        }
        .floating-info-card .contact-item i {
            width: 22px;
            color: #555;
            font-size: 16px;
            text-align: center;
        }
        .floating-info-card .contact-item a {
            color: #1a73e8;
            text-decoration: none;
            transition: 0.2s;
        }
        .floating-info-card .contact-item a:hover {
            color: #0d47a1;
            text-decoration: underline;
        }
        .floating-info-card .divider {
            border-top: 1px solid #eee;
            margin: 10px 0;
        }
        .floating-info-card .social-icons {
            display: flex;
            justify-content: center;
            gap: 14px;
            margin-top: 10px;
        }
        .floating-info-card .social-icons a {
            color: #555;
            font-size: 22px;
            transition: 0.2s;
        }
        .floating-info-card .social-icons a:hover {
            color: #000;
            transform: scale(1.15);
        }

        /* ============================================= */
        /* مخفی‌سازی کامل در موبایل */
        @media (max-width: 768px) {
            .floating-toggle-container {
                display: none !important;
            }
        }
        /* ============================================= */
    </style>

    <div class="floating-toggle-container">
        <!-- دکمه شناور -->
        <button class="floating-toggle-btn" id="floatingToggleBtn" onclick="toggleFloatingCard()">
            <i class="fas fa-phone"></i>
        </button>

        <!-- سه حلقه موج (بعد از دکمه قرار گرفته‌اند تا با selector ~ کنترل شوند) -->
        <div class="ripple"></div>
        <div class="ripple"></div>
        <div class="ripple"></div>

        <!-- کارت اطلاعات (پنهان در ابتدا) -->
        <div class="floating-info-card" id="floatingInfoCard">
            <!-- شماره‌های تماس -->
            <?php foreach ($phone_numbers as $phone): ?>
                <div class="contact-item">
                    <i class="fas fa-phone"></i>
                    <a href="tel:<?php echo esc_attr($phone); ?>">
                        <?php echo esc_html($phone); ?>
                    </a>
                </div>
            <?php endforeach; ?>

            <div class="divider"></div>

            <!-- آدرس‌ها -->
            <?php foreach ($addresses as $address): ?>
                <div class="contact-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <span><?php echo esc_html($address); ?></span>
                </div>
            <?php endforeach; ?>

            <div class="divider"></div>

            <!-- شبکه‌های اجتماعی -->
            <div class="social-icons">
                <?php foreach ($social_links as $icon => $link): ?>
                    <a href="<?php echo esc_url($link); ?>" target="_blank" rel="noopener noreferrer">
                        <i class="fab <?php echo esc_attr($icon); ?>"></i>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <script>
        function toggleFloatingCard() {
            var card = document.getElementById('floatingInfoCard');
            var btn = document.getElementById('floatingToggleBtn');
            card.classList.toggle('active');
            btn.classList.toggle('open');
        }

        // بستن کارت با کلیک بیرون از آن
        document.addEventListener('click', function(event) {
            var container = document.querySelector('.floating-toggle-container');
            var card = document.getElementById('floatingInfoCard');
            var btn = document.getElementById('floatingToggleBtn');
            if (!container.contains(event.target) && card.classList.contains('active')) {
                card.classList.remove('active');
                btn.classList.remove('open');
            }
        });
    </script>
    <?php
}
add_action('wp_footer', 'floating_contact_toggle');


/**
 * =====================================================
 * شورت‌کد Hero Section - ارتفاع اتوماتیک
 * =====================================================
 */
add_shortcode('custom_hero', 'astra_child_custom_hero_shortcode');
function astra_child_custom_hero_shortcode($atts) {
    $atts = shortcode_atts(array(
        'title'    => '',
        'image_id' => 0,
        'align'    => 'bottom',
    ), $atts);

    // کش
    $cache_key = 'hero_' . md5(serialize($atts) . get_the_ID() . get_queried_object_id());
    $html = wp_cache_get($cache_key);
    if (false !== $html) {
        return $html;
    }

    // ---- تشخیص نوع صفحه ----
    $title = '';
    $hero_image_id = 0;
    $breadcrumb_html = '';

    if (is_singular('product')) {
        $product_id = get_the_ID();
        $title = get_the_title($product_id);
        $hero_image_id = get_post_meta($product_id, '_hero_image', true);
        $breadcrumb_html = astra_child_get_product_breadcrumb($product_id);
    } 
    elseif (is_tax()) {
        $term = get_queried_object();
        $title = $term->name;
        $hero_image_id = get_term_meta($term->term_id, 'hero_image_id', true);
        if (empty($hero_image_id)) {
            $hero_image_id = get_term_meta($term->term_id, 'taxonomy_image_id', true);
        }
        $breadcrumb_html = astra_child_get_custom_tax_breadcrumb($term);
    } 
    elseif (is_shop() || is_post_type_archive('product')) {
        $title = __('محصولات', 'astra-child');
        $hero_image_id = 0;
        $breadcrumb_html = astra_child_get_shop_breadcrumb();
    } 
    elseif (is_archive()) {
        $title = get_the_archive_title();
        $hero_image_id = $atts['image_id'] ?: get_post_thumbnail_id();
        $breadcrumb_html = astra_child_get_default_breadcrumb();
    } 
    else {
        $title = $atts['title'] ?: get_the_title();
        $hero_image_id = $atts['image_id'] ?: get_post_thumbnail_id();
        $breadcrumb_html = astra_child_get_default_breadcrumb();
    }

    if (empty($hero_image_id) && !is_tax() && !is_shop() && !is_post_type_archive('product')) {
        $hero_image_id = get_post_thumbnail_id();
    }

    // استایل بک‌گراند
    $bg_style = astra_child_get_hero_background_style($hero_image_id);
    $align_class = 'hero-align-' . esc_attr($atts['align']);

    ob_start();
    ?>
    <div class="custom-hero-fullwidth">
        <div class="custom-hero-section <?php echo $align_class; ?>" style="<?php echo $bg_style; ?>">
            <div class="custom-hero-overlay">
                <div class="custom-hero-content">
                    <h1 class="custom-hero-title"><?php echo esc_html($title); ?></h1>
                    <?php if (!empty($breadcrumb_html)) : ?>
                        <div class="custom-hero-breadcrumb">
                            <?php echo $breadcrumb_html; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php

    $html = ob_get_clean();
    wp_cache_set($cache_key, $html, '', HOUR_IN_SECONDS);

    global $astra_child_hero_used;
    $astra_child_hero_used = true;

    return $html;
}

/**
 * تولید استایل بک‌گراند (گرادینت قرمز-مشکی در صورت نبود تصویر)
 */
function astra_child_get_hero_background_style($image_id) {
    if (!empty($image_id)) {
        $image_url = wp_get_attachment_image_url($image_id, 'full');
        if ($image_url) {
            return 'background-image: url(' . esc_url($image_url) . '); background-size: cover; background-position: center center; background-repeat: no-repeat;';
        }
    }
    // گرادینت قرمز-مشکی
    return 'background: linear-gradient(135deg, #2c0000 0%, #4a0000 30%, #1a0000 100%); background-size: cover;';
}

// ================================================================
//  بردکرامپ تاکسونومی (نمایش والدین)
// ================================================================
function astra_child_get_custom_tax_breadcrumb($term) {
    $cache_key = 'breadcrumb_custom_tax_' . $term->term_id;
    $html = wp_cache_get($cache_key);
    if (false !== $html) return $html;

    $breadcrumb = array();
    $breadcrumb[] = '<a href="' . home_url() . '">' . __('خانه', 'astra-child') . '</a>';

    // نمایش والدین
    if ($term->parent) {
        $ancestors = array_reverse(get_ancestors($term->term_id, $term->taxonomy));
        foreach ($ancestors as $ancestor_id) {
            $ancestor = get_term($ancestor_id, $term->taxonomy);
            if ($ancestor && !is_wp_error($ancestor)) {
                $breadcrumb[] = '<a href="' . get_term_link($ancestor) . '">' . esc_html($ancestor->name) . '</a>';
            }
        }
    }

    $breadcrumb[] = '<span>' . esc_html($term->name) . '</span>';

    $html = '<nav class="custom-breadcrumb">' . implode(' <span class="sep">›</span> ', $breadcrumb) . '</nav>';
    wp_cache_set($cache_key, $html);
    return $html;
}

// ================================================================
//  سایر بردکرامپ‌ها
// ================================================================
function astra_child_get_product_breadcrumb($product_id) {
    $cache_key = 'breadcrumb_product_' . $product_id;
    $html = wp_cache_get($cache_key);
    if (false !== $html) return $html;

    $product = wc_get_product($product_id);
    if (!$product) return '';

    $terms = wp_get_post_terms($product_id, 'product_cat');
    $breadcrumb = array();
    $breadcrumb[] = '<a href="' . home_url() . '">' . __('خانه', 'astra-child') . '</a>';
    $shop_page_id = wc_get_page_id('shop');
    if ($shop_page_id) {
        $breadcrumb[] = '<a href="' . esc_url(get_permalink($shop_page_id)) . '">' . __('محصولات', 'astra-child') . '</a>';
    }

    if (!empty($terms) && !is_wp_error($terms)) {
        $depth = -1; $deep_term = null;
        foreach ($terms as $term) {
            $ancestors = get_ancestors($term->term_id, 'product_cat');
            if (count($ancestors) > $depth) {
                $depth = count($ancestors);
                $deep_term = $term;
            }
        }
        if ($deep_term) {
            $term_chain = array_reverse(get_ancestors($deep_term->term_id, 'product_cat'));
            $term_chain[] = $deep_term->term_id;
            foreach ($term_chain as $term_id) {
                $term_obj = get_term($term_id, 'product_cat');
                if ($term_obj) {
                    $breadcrumb[] = '<a href="' . get_term_link($term_obj) . '">' . esc_html($term_obj->name) . '</a>';
                }
            }
        }
    }

    $breadcrumb[] = '<span>' . get_the_title($product_id) . '</span>';
    $html = '<nav class="custom-breadcrumb">' . implode(' <span class="sep">›</span> ', $breadcrumb) . '</nav>';
    wp_cache_set($cache_key, $html);
    return $html;
}

function astra_child_get_shop_breadcrumb() {
    $cache_key = 'breadcrumb_shop';
    $html = wp_cache_get($cache_key);
    if (false !== $html) return $html;
    $breadcrumb = array();
    $breadcrumb[] = '<a href="' . home_url() . '">' . __('خانه', 'astra-child') . '</a>';
    $breadcrumb[] = '<span>' . __('محصولات', 'astra-child') . '</span>';
    $html = '<nav class="custom-breadcrumb">' . implode(' <span class="sep">›</span> ', $breadcrumb) . '</nav>';
    wp_cache_set($cache_key, $html);
    return $html;
}

function astra_child_get_default_breadcrumb() {
    $cache_key = 'breadcrumb_default_' . get_the_ID();
    $html = wp_cache_get($cache_key);
    if (false !== $html) return $html;
    $breadcrumb = array();
    $breadcrumb[] = '<a href="' . home_url() . '">' . __('خانه', 'astra-child') . '</a>';
    $breadcrumb[] = '<span>' . get_the_title() . '</span>';
    $html = '<nav class="custom-breadcrumb">' . implode(' <span class="sep">›</span> ', $breadcrumb) . '</nav>';
    wp_cache_set($cache_key, $html);
    return $html;
}

// ================================================================
//  استایل‌های ریسپانسیو (ارتفاع اتوماتیک)
// ================================================================
add_action('wp_head', 'astra_child_hero_styles', 99);
function astra_child_hero_styles() {
    global $astra_child_hero_used;
    if (empty($astra_child_hero_used)) return;

    echo '<style id="astra-child-hero-styles">';
    ?>
    .custom-hero-fullwidth {
        width: 100%;
        margin: 0;
        padding: 0;
    }

    /* ===== دسکتاپ ===== */
    .custom-hero-section {
        position: relative;
        width: 100%;
        height: 317px; /* ارتفاع اتوماتیک بر اساس محتوا */
        min-height: 400px; /* حداقل ارتفاع 400px (در صورت کم بودن محتوا) */
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
        background-size: cover !important;
        background-position: center center !important;
        background-repeat: no-repeat !important;
        background-color: #2c0000;
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        overflow: hidden;
    }

    .custom-hero-overlay {
        position: relative;
        z-index: 1;
        width: 100%;
        min-height: inherit; /* هم‌ارتفاع با بخش اصلی */
        background: rgba(0, 0, 0, 0.35);
        backdrop-filter: blur(2px);
        display: flex;
        align-items: flex-end;
        justify-content: flex-end;
        padding: 50px 30px; /* فاصله داخلی برای ایجاد ارتفاع بیشتر */
        box-sizing: border-box;
    }

    .custom-hero-content {
        position: relative;
        z-index: 2;
        width: 100%;
        max-width: 1200px;
        margin: 0 auto;
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        color: #fff;
        text-shadow: 0 2px 10px rgba(0, 0, 0, 0.6);
        padding: 0 10px;
    }

    .custom-hero-title {
        font-size: 3.2rem;
        font-weight: 700;
        margin: 0 0 10px 0;
        line-height: 1.2;
        text-align: right;
        width: 100%;
    }

    .custom-hero-breadcrumb {
        font-size: 1rem;
        background: rgba(0, 0, 0, 0.3);
        padding: 8px 18px;
        border-radius: 30px;
        backdrop-filter: blur(4px);
        display: inline-block;
        direction: rtl;
        text-align: right;
        margin-top: 5px;
    }

    .custom-hero-breadcrumb a,
    .custom-hero-breadcrumb span {
        color: #fff;
        text-decoration: none;
        font-weight: 400;
        opacity: 0.95;
    }
    .custom-hero-breadcrumb a:hover {
        opacity: 1;
        text-decoration: underline;
    }
    .custom-hero-breadcrumb .sep {
        margin: 0 6px;
        opacity: 0.7;
    }

    .hero-align-top .custom-hero-overlay { align-items: flex-start; }
    .hero-align-center .custom-hero-overlay { align-items: center; }
    .hero-align-bottom .custom-hero-overlay { align-items: flex-end; }

    /* ===== موبایل (عرض کمتر از 768px) ===== */
    @media (max-width: 767px) {
        .custom-hero-section {
            height: auto !important;
            min-height: 0 !important;
            background: none !important;
            background-color: #fff !important;
            display: flex;
            flex-direction: column;
        }

        .custom-hero-section::before {
            content: '';
            display: block;
            width: 100%;
            height: 40vh; /* ارتفاع تصویر در موبایل */
            background: <?php echo astra_child_get_hero_background_style(get_post_meta(get_the_ID(), '_hero_image', true) ?: 0); ?>;
            background-size: cover !important;
            background-position: center center !important;
            background-repeat: no-repeat !important;
            flex-shrink: 0;
        }

        .custom-hero-overlay {
            background: #fff !important;
            backdrop-filter: none !important;
            padding: 20px 15px !important;
            min-height: auto !important;
            align-items: flex-start;
            justify-content: flex-start;
        }

        .custom-hero-content {
            color: #333 !important;
            text-shadow: none !important;
            align-items: flex-start;
        }

        .custom-hero-title {
            color: #222;
            font-size: 1.8rem;
            text-align: right;
        }

        .custom-hero-breadcrumb {
            background: #f0f0f0;
            color: #333;
            backdrop-filter: none;
        }
        .custom-hero-breadcrumb a,
        .custom-hero-breadcrumb span {
            color: #333;
            opacity: 1;
        }
        .custom-hero-breadcrumb a:hover {
            opacity: 0.7;
        }
        .custom-hero-breadcrumb .sep {
            color: #666;
        }
    }

    /* ===== تبلت ===== */
    @media (min-width: 768px) and (max-width: 1024px) {
        .custom-hero-section {
            min-height: 400px;
        }
        .custom-hero-title {
            font-size: 2.8rem;
        }
    }
    <?php
    echo '</style>';
}



// کد بازاریاب

add_action('init', 'save_affiliate_ref_cookie');

function save_affiliate_ref_cookie(){

    if(isset($_GET['ref'])){

        setcookie(
            'affiliate_ref',
            sanitize_text_field($_GET['ref']),
            time()+30*DAY_IN_SECONDS,
            COOKIEPATH,
            COOKIE_DOMAIN
        );

    }

}


add_action('voorodak_after_do_register', 'save_referrer_for_voorodak_user');

function save_referrer_for_voorodak_user($user_id){

    if(isset($_COOKIE['affiliate_ref'])){

        update_user_meta(
            $user_id,
            'introduced_by',
            sanitize_text_field($_COOKIE['affiliate_ref'])
        );

    }

}


// نمایش بازاریاب معرفی کننده در لیست کاربران

add_filter('manage_users_columns', 'raz_add_referrer_column');

function raz_add_referrer_column($columns){

    $columns['introduced_by'] = 'معرفی شده توسط';

    return $columns;
}


add_action('manage_users_custom_column', 'raz_show_referrer_column', 10, 3);

function raz_show_referrer_column($output, $column_name, $user_id){

    if($column_name == 'introduced_by'){

        $ref_id = get_user_meta($user_id, 'introduced_by', true);

        if(empty($ref_id)){
            return '---';
        }

        $ref_user = get_user_by('id', $ref_id);

        if($ref_user){

            return $ref_user->display_name . ' (ID: '.$ref_id.')';

        } else {

            return 'بازاریاب پیدا نشد (ID: '.$ref_id.')';

        }

    }

    return $output;
}

/**
 * اندازه‌گیری خودکار ارتفاع منوی پایین موبایل و نوار قیمت محصول
 */
add_action('wp_footer', function () {
    if (!is_product()) return;
    ?>
    <script>
    (function() {
        function setStickyHeights() {
            var nav = document.querySelector('.elementor-element-bdf37ac');
            var navHeight = nav ? nav.offsetHeight : 60;
            document.documentElement.style.setProperty('--nb-bottom-nav-height', navHeight + 'px');

            var priceBar = document.querySelector('.elementor-element-3ce6c39:not(.elementor-sticky__spacer)');
            var priceBarHeight = priceBar ? priceBar.offsetHeight : 110;
            document.documentElement.style.setProperty('--nb-price-bar-height', priceBarHeight + 'px');
        }
        window.addEventListener('load', setStickyHeights);
        window.addEventListener('resize', setStickyHeights);
        setStickyHeights();
    })();
    </script>
    <?php
});

?>