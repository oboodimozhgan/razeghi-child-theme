<?php
/**
 * ثبت تاکسونومی‌های محصول
 */
add_action('init', 'astra_child_register_product_taxonomies');
function astra_child_register_product_taxonomies() {
    
    // برند خودرو
    register_taxonomy('car_brand', 'product', array(
        'label' => 'برند خودرو',
        'hierarchical' => true,
        'show_in_rest' => true,
        'show_admin_column' => true,
        'rewrite' => array('slug' => 'car-brand')
    ));
    
    // مدل خودرو
    register_taxonomy('car_model', 'product', array(
        'label' => 'مدل خودرو',
        'hierarchical' => true,
        'show_in_rest' => true,
        'show_admin_column' => true,
        'rewrite' => array('slug' => 'car-model')
    ));
    
    // نسل خودرو
    register_taxonomy('car_generation', 'product', array(
        'label' => 'نسل خودرو',
        'hierarchical' => true,
        'show_in_rest' => true,
        'rewrite' => array('slug' => 'generation')
    ));
    
    // برند قطعه
    register_taxonomy('part_brand', 'product', array(
        'label' => 'برند قطعه',
        'hierarchical' => true,
        'show_in_rest' => true,
        'show_admin_column' => true,
        'rewrite' => array('slug' => 'brand')
    ));
    
    // سیستم خودرو
    register_taxonomy('car_system', 'product', array(
        'label' => 'سیستم خودرو',
        'hierarchical' => true,
        'show_in_rest' => true,
        'show_admin_column' => true,
        'rewrite' => array('slug' => 'system')
    ));
    
    // درجه کیفیت
    register_taxonomy('quality_grade', 'product', array(
        'label' => 'درجه کیفیت',
        'hierarchical' => true,
        'show_in_rest' => true,
        'show_admin_column' => true
    ));
    
    // محل نصب
    register_taxonomy('install_position', 'product', array(
        'label' => 'محل نصب',
        'hierarchical' => true,
        'show_in_rest' => true
    ));
}

/**
 * ثبت متافیلدهای محصول
 */
add_action('init', 'astra_child_register_product_meta');
function astra_child_register_product_meta() {
    
    // شناسایی محصول
    $identification_fields = array(
        '_oem_code' => 'شماره فنی OEM',
        '_part_number' => 'شماره قطعه',
        '_barcode' => 'بارکد',
        '_internal_code' => 'کد داخلی',
        '_alternate_part_numbers' => 'شماره‌های جایگزین'
    );
    
    // موجودی
    $stock_fields = array(
        '_stock_source' => 'منبع موجودی',
        '_availability_type' => 'نوع موجودی',
        '_restock_date' => 'تاریخ تامین مجدد'
    );
    
    // مشخصات فنی
    $spec_fields = array(
        '_manufacturer' => 'تولیدکننده',
        '_country_of_origin' => 'کشور سازنده',
        '_quality_grade_text' => 'درجه کیفیت',
        '_material' => 'جنس',
        '_warranty_period' => 'مدت گارانتی'
    );
    
    // سازگاری خودرو
    $compatibility_fields = array(
        '_engine_type' => 'نوع موتور',
        '_engine_code' => 'کد موتور',
        '_year_from' => 'سال شروع',
        '_year_to' => 'سال پایان'
    );
    
    // موقعیت نصب
    $position_fields = array(
        '_side' => 'سمت',
        '_axle' => 'محور'
    );
    
    // اطلاعات فروش
    $sales_fields = array(
        '_installation_time' => 'زمان نصب',
        '_difficulty_level' => 'سختی نصب',
        '_replacement_interval' => 'زمان تعویض'
    );
    
    // محتوایی
    $content_fields = array(
        '_short_features' => 'ویژگی‌های کوتاه',
        '_installation_guide' => 'راهنمای نصب',
        '_maintenance_tips' => 'نکات نگهداری',
        '_common_failures' => 'علائم خرابی',
        '_video_url' => 'لینک ویدیو'
    );
    
    // نمایش
    $display_fields = array(
        '_show_partner_price' => 'نمایش قیمت همکار',
        '_featured_badge' => 'نشان ویژه',
        '_sale_badge_text' => 'متن تخفیف'
    );
    
    // لجستیک
    $shipping_fields = array(
        '_package_weight' => 'وزن بسته',
        '_package_length' => 'طول بسته',
        '_package_width' => 'عرض بسته',
        '_package_height' => 'ارتفاع بسته',
        '_fragile' => 'شکننده'
    );
    
    // ترکیب همه فیلدها (بدون قیمت)
    $all_fields = array_merge(
        $identification_fields,
        $stock_fields,
        $spec_fields,
        $compatibility_fields,
        $position_fields,
        $sales_fields,
        $content_fields,
        $display_fields,
        $shipping_fields
    );
    
    // ثبت متافیلدها
    foreach ($all_fields as $key => $label) {
        register_post_meta('product', $key, array(
            'type' => 'string',
            'description' => $label,
            'single' => true,
            'show_in_rest' => true,
            'auth_callback' => function() {
                return current_user_can('edit_posts');
            }
        ));
    }
}

/**
 * اضافه کردن متاباکس برای متافیلدها
 */
add_action('add_meta_boxes', 'astra_child_add_product_meta_boxes');
function astra_child_add_product_meta_boxes() {
    
    add_meta_box(
        'product_identification',
        'شناسایی محصول',
        'astra_child_render_identification_meta',
        'product',
        'normal',
        'high'
    );
    
    add_meta_box(
        'product_compatibility',
        'سازگاری خودرو',
        'astra_child_render_compatibility_meta',
        'product',
        'normal',
        'default'
    );
}

// رندر متاباکس شناسایی
function astra_child_render_identification_meta($post) {
    wp_nonce_field('product_meta_nonce', 'product_meta_nonce');
    
    $oem = get_post_meta($post->ID, '_oem_code', true);
    $part_number = get_post_meta($post->ID, '_part_number', true);
    $barcode = get_post_meta($post->ID, '_barcode', true);
    ?>
    <p>
        <label>شماره فنی OEM:</label>
        <input type="text" name="_oem_code" value="<?php echo esc_attr($oem); ?>" style="width:100%">
    </p>
    <p>
        <label>شماره قطعه:</label>
        <input type="text" name="_part_number" value="<?php echo esc_attr($part_number); ?>" style="width:100%">
    </p>
    <p>
        <label>بارکد:</label>
        <input type="text" name="_barcode" value="<?php echo esc_attr($barcode); ?>" style="width:100%">
    </p>
    <?php
}

// رندر متاباکس سازگاری
function astra_child_render_compatibility_meta($post) {
    $engine_type = get_post_meta($post->ID, '_engine_type', true);
    $year_from = get_post_meta($post->ID, '_year_from', true);
    $year_to = get_post_meta($post->ID, '_year_to', true);
    ?>
    <p>
        <label>نوع موتور:</label>
        <input type="text" name="_engine_type" value="<?php echo esc_attr($engine_type); ?>" style="width:100%">
    </p>
    <p>
        <label>از سال:</label>
        <input type="number" name="_year_from" value="<?php echo esc_attr($year_from); ?>" style="width:48%;margin-left:2%">
        <label>تا سال:</label>
        <input type="number" name="_year_to" value="<?php echo esc_attr($year_to); ?>" style="width:48%">
    </p>
    <?php
}

/**
 * ذخیره متافیلدها
 */
add_action('save_post_product', 'astra_child_save_product_meta');
function astra_child_save_product_meta($post_id) {
    
    if (!isset($_POST['product_meta_nonce']) || !wp_verify_nonce($_POST['product_meta_nonce'], 'product_meta_nonce')) {
        return;
    }
    
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    $fields = array(
        '_oem_code', '_part_number', '_barcode',
        '_engine_type', '_year_from', '_year_to'
    );
    
    foreach ($fields as $field) {
        if (isset($_POST[$field])) {
            update_post_meta($post_id, $field, sanitize_text_field($_POST[$field]));
        }
    }
}


// اضافه کردن فیلدهای قیمت همکار
add_action('woocommerce_product_options_pricing', 'astra_child_add_partner_price_fields');
function astra_child_add_partner_price_fields() {
    echo '<div class="options_group">';
    
    woocommerce_wp_text_input(array(
        'id' => '_partner_price',
        'label' => 'قیمت همکار (تومان)',
        'placeholder' => '',
        'desc_tip' => true,
        'description' => 'قیمت ویژه برای کاربران با نقش همکار',
        'type' => 'number',
        'custom_attributes' => array(
            'step' => 'any',
            'min' => '0'
        )
    ));
    
    woocommerce_wp_text_input(array(
        'id' => '_partner_sale_price',
        'label' => 'قیمت با تخفیف همکار (تومان)',
        'placeholder' => '',
        'desc_tip' => true,
        'description' => 'قیمت تخفیف‌خورده برای همکاران (اختیاری)',
        'type' => 'number',
        'custom_attributes' => array(
            'step' => 'any',
            'min' => '0'
        )
    ));
    
    echo '</div>';
}

add_action('woocommerce_process_product_meta', 'astra_child_save_partner_price_fields');
function astra_child_save_partner_price_fields($post_id) {
    $partner_price = isset($_POST['_partner_price']) ? sanitize_text_field($_POST['_partner_price']) : '';
    $partner_sale_price = isset($_POST['_partner_sale_price']) ? sanitize_text_field($_POST['_partner_sale_price']) : '';
    
    update_post_meta($post_id, '_partner_price', $partner_price);
    update_post_meta($post_id, '_partner_sale_price', $partner_sale_price);
}
