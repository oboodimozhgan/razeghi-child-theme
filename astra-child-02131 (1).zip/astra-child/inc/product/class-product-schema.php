<?php
/**
 * Product Schema Markup Generator
 * 
 * @package Astra_Child
 */

if (!defined('ABSPATH')) {
    exit;
}

class Astra_Child_Product_Schema {
    
    /**
     * تولید Schema Markup برای محصول
     * 
     * @param WC_Product $product Product object
     * @return string JSON-LD Schema markup
     */
    public static function generate($product) {
        if (!$product || !is_a($product, 'WC_Product')) {
            return '';
        }
        
        $schema = array(
            '@context' => 'https://schema.org/',
            '@type' => 'Product',
            'name' => $product->get_name(),
            'description' => wp_strip_all_tags($product->get_short_description() ?: $product->get_description()),
            'url' => get_permalink($product->get_id()),
        );
        
        // افزودن SKU
        if ($product->get_sku()) {
            $schema['sku'] = $product->get_sku();
        }
        
        // افزودن تصویر
        $image_id = $product->get_image_id();
        if ($image_id) {
            $image_url = wp_get_attachment_image_url($image_id, 'full');
            if ($image_url) {
                $schema['image'] = $image_url;
            }
        }
        
        // افزودن قیمت و موجودی
        $schema['offers'] = array(
            '@type' => 'Offer',
            'url' => get_permalink($product->get_id()),
            'priceCurrency' => 'IRR',
            'price' => $product->get_price(),
            'priceValidUntil' => date('Y-12-31'),
            'availability' => $product->is_in_stock() ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
        );
        
        // افزودن رتبه‌بندی
        $average_rating = $product->get_average_rating();
        $review_count = $product->get_review_count();
        
        if ($average_rating && $review_count > 0) {
            $schema['aggregateRating'] = array(
                '@type' => 'AggregateRating',
                'ratingValue' => $average_rating,
                'reviewCount' => $review_count,
                'bestRating' => '5',
                'worstRating' => '1',
            );
        }
        
        // افزودن برند
        $brand = get_post_meta($product->get_id(), '_product_brand', true);
        if (!empty($brand)) {
            $schema['brand'] = array(
                '@type' => 'Brand',
                'name' => $brand,
            );
        }
        
        // افزودن دسته‌بندی
        $categories = wp_get_post_terms($product->get_id(), 'product_cat', array('fields' => 'names'));
        if (!empty($categories) && !is_wp_error($categories)) {
            $schema['category'] = implode(', ', $categories);
        }
        
        return '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . '</script>';
    }
}
