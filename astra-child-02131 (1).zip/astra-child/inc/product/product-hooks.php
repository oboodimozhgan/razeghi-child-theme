<?php
/**
 * Product Hooks and Filters
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * حذف هوک‌های پیش‌فرض ووکامرس در صفحه محصول
 */
function astra_child_remove_default_product_hooks() {
    // حذف عناصری که در template parts خودمان پیاده‌سازی کردیم
    remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_title', 5);
    remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10);
    remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_price', 10);
    remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20);
    remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40);
    remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_sharing', 50);
}
add_action('init', 'astra_child_remove_default_product_hooks');

/**
 * اضافه کردن Schema Markup به صفحه محصول
 */
function astra_child_add_product_schema() {
    if (is_product()) {
        global $product;
        if ($product) {
            echo Astra_Child_Product_Schema::generate($product);
        }
    }
}
add_action('wp_footer', 'astra_child_add_product_schema');

/**
 * فیلتر برای تغییر ساختار URL محصولات
 */
function astra_child_product_permalink($permalink, $post) {
    if ($post->post_type !== 'product') {
        return $permalink;
    }
    
    $product_meta = new Astra_Child_Product_Meta($post->ID);
    $seo_url = $product_meta->get_seo_url();
    
    return $seo_url ?: $permalink;
}
add_filter('post_type_link', 'astra_child_product_permalink', 10, 2);

/**
 * اضافه کردن کلاس سفارشی به body در صفحات محصول
 */
function astra_child_product_body_class($classes) {
    if (is_product()) {
        $classes[] = 'astra-child-single-product';
        
        if (current_user_can('partner')) {
            $classes[] = 'partner-user';
        }
    }
    return $classes;
}
add_filter('body_class', 'astra_child_product_body_class');

/**
 * تنظیم تعداد محصولات مرتبط
 */
function astra_child_related_products_args($args) {
    $args['posts_per_page'] = 6;
    $args['columns'] = 3;
    return $args;
}
add_filter('woocommerce_output_related_products_args', 'astra_child_related_products_args');

/**
 * افزودن متا باکس برای قیمت همکار در پنل ادمین
 */
function astra_child_add_partner_price_meta_box() {
    add_meta_box(
        'partner_price_meta_box',
        'قیمت همکار',
        'astra_child_partner_price_meta_box_callback',
        'product',
        'side',
        'default'
    );
}
add_action('add_meta_boxes', 'astra_child_add_partner_price_meta_box');

function astra_child_partner_price_meta_box_callback($post) {
    $partner_price = get_post_meta($post->ID, '_partner_price', true);
    wp_nonce_field('partner_price_nonce', 'partner_price_nonce_field');
    ?>
    <p>
        <label for="partner_price">قیمت همکار (تومان):</label>
        <input type="number" id="partner_price" name="partner_price" value="<?php echo esc_attr($partner_price); ?>" style="width: 100%;" />
    </p>
    <?php
}

function astra_child_save_partner_price_meta($post_id) {
    if (!isset($_POST['partner_price_nonce_field']) || !wp_verify_nonce($_POST['partner_price_nonce_field'], 'partner_price_nonce')) {
        return;
    }
    
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    if (isset($_POST['partner_price'])) {
        update_post_meta($post_id, '_partner_price', sanitize_text_field($_POST['partner_price']));
    }
}
add_action('save_post_product', 'astra_child_save_partner_price_meta');


add_filter( 'woocommerce_get_price_html', 'update_product_card_price_for_partners', 100, 2 );

function update_product_card_price_for_partners( $price_html, $product ) {
    // عدم تغییر قیمت در پنل مدیریت وردپرس
    if ( is_admin() ) {
        return $price_html;
    }

    // بررسی اینکه آیا کاربر مجاز به دیدن قیمت همکار است
    if ( ! AP_Product_Partner::can_see_partner_price() ) {
        return $price_html; // نمایش قیمت عادی قالب برای کاربران معمولی
    }

    $product_id = $product->get_id();
    
    // دریافت مقادیر قیمت همکار
    $partner_price      = get_post_meta( $product_id, '_partner_price', true );
    $partner_sale_price = get_post_meta( $product_id, '_partner_sale_price', true );

    // اگر قیمت با تخفیف همکار وجود داشت (اولویت اول)
    if ( ! empty( $partner_sale_price ) && is_numeric( $partner_sale_price ) ) {
        // نمایش قیمت خط خورده همکار و قیمت جدید
        $price_html  = '<del aria-hidden="true"><span class="woocommerce-Price-amount amount"><bdi>' . wc_price( $partner_price ) . '</bdi></span></del>';
        $price_html .= ' <ins><span class="woocommerce-Price-amount amount"><bdi>' . wc_price( $partner_sale_price ) . '</bdi></span></ins>';
        $price_html .= ' <span class="partner-badge" style="font-size:0.8em; color:#d62828;">(همکار)</span>';
    } 
    // اگر فقط قیمت عادی همکار وجود داشت
    elseif ( ! empty( $partner_price ) && is_numeric( $partner_price ) ) {
        $price_html = '<span class="woocommerce-Price-amount amount"><bdi>' . wc_price( $partner_price ) . '</bdi></span>';
        $price_html .= ' <span class="partner-badge" style="font-size:0.8em; color:#d62828;">(همکار)</span>';
    }

    return $price_html;
}

