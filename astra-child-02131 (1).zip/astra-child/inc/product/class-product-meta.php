<?php
/**
 * Product Meta Handler
 * 
 * @package Astra_Child
 */

if (!defined('ABSPATH')) {
    exit;
}

class Astra_Child_Product_Meta {
    
    /**
     * Product ID
     * 
     * @var int
     */
    private $product_id;
    
    /**
     * Constructor
     * 
     * @param int $product_id Product ID
     */
    public function __construct($product_id) {
        $this->product_id = $product_id;
    }
    
    /**
     * دریافت URL سئو شده محصول
     * 
     * @return string|false
     */
    public function get_seo_url() {
        $custom_url = get_post_meta($this->product_id, '_seo_url', true);
        
        if (!empty($custom_url)) {
            return home_url($custom_url);
        }
        
        return false;
    }
    
    /**
     * دریافت قیمت همکار
     * 
     * @return string|false
     */
    public function get_partner_price() {
        return get_post_meta($this->product_id, '_partner_price', true);
    }
    
    /**
     * بررسی وجود قیمت همکار
     * 
     * @return bool
     */
    public function has_partner_price() {
        $price = $this->get_partner_price();
        return !empty($price) && $price > 0;
    }
    
    /**
     * دریافت تمام متاهای سفارشی محصول
     * 
     * @return array
     */
    public function get_all_meta() {
        return get_post_meta($this->product_id);
    }
    
    /**
     * دریافت یک متای خاص
     * 
     * @param string $key Meta key
     * @param bool $single Return single value
     * @return mixed
     */
    public function get_meta($key, $single = true) {
        return get_post_meta($this->product_id, $key, $single);
    }

    /**
     * ساخت URL فیلتر برای یک ویژگی/متا در صفحه فروشگاه
     *
     * @param string $meta_key Meta key
     * @param string $value Attribute value
     * @return string
     */
    public static function get_attribute_url($meta_key, $value) {
        $shop_url = wc_get_page_permalink('shop');

        if (empty($shop_url) || empty($meta_key) || empty($value)) {
            return '';
        }

        $query_key_map = [
            '_oem_code'          => 'oem',
            '_part_brand'        => 'brand',
            '_car_brand'         => 'car_brand',
            '_car_model'         => 'car_model',
            '_car_system'        => 'system',
            '_install_position'  => 'position',
            '_quality_grade'     => 'quality',
            '_country_of_origin' => 'country',
        ];

        $query_key = isset($query_key_map[$meta_key]) ? $query_key_map[$meta_key] : sanitize_key(ltrim($meta_key, '_'));
        $query_val = sanitize_title($value);

        return add_query_arg($query_key, $query_val, $shop_url);
    }
}

// Backward-compatibility for older template references.
if (!class_exists('AP_Product_Meta')) {
    class AP_Product_Meta extends Astra_Child_Product_Meta {}
}
