<?php
/**
 * Partner Price Handler
 */

defined('ABSPATH') || exit;

class AP_Product_Partner {

    /**
     * بررسی دسترسی به قیمت همکار
     */
    public static function can_see_partner_price() {
        
        if (!is_user_logged_in()) {
            return false;
        }

        $user = wp_get_current_user();

        return in_array('partner', $user->roles) || 
               in_array('wholesale_customer', $user->roles);
    }

    /**
     * دریافت قیمت همکار
     */
    public static function get_partner_price($product_id) {
        
        if (!self::can_see_partner_price()) {
            return false;
        }

        $partner_price = get_post_meta($product_id, '_partner_price', true);

        return $partner_price ? floatval($partner_price) : false;
    }

    /**
     * محاسبه درصد سود
     */
    public static function calculate_profit_percent($regular_price, $partner_price) {
        
        if ($regular_price <= 0) {
            return 0;
        }

        return (($regular_price - $partner_price) / $regular_price) * 100;
    }
}

add_action( 'woocommerce_before_calculate_totals', 'apply_partner_price_in_cart', 99, 1 );

function apply_partner_price_in_cart( $cart ) {
    // جلوگیری از اجرای کد در پنل ادمین (به جز درخواست‌های ایجکس)
    if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
        return;
    }

    if ( did_action( 'woocommerce_before_calculate_totals' ) >= 2 ) {
        return;
    }

    // بررسی اینکه آیا کاربر فعلی مجاز به استفاده از مزایای همکار است یا خیر
    if ( ! AP_Product_Partner::can_see_partner_price() ) {
        return;
    }

    foreach ( $cart->get_cart() as $cart_item ) {
        $product_id = $cart_item['product_id'];
        
        // دریافت قیمت‌های همکار مستقیم از متادیتای محصول
        $partner_price      = get_post_meta( $product_id, '_partner_price', true );
        $partner_sale_price = get_post_meta( $product_id, '_partner_sale_price', true ); // کلید متای تخفیف همکار
        
        $final_price = '';

        // منطق بررسی: اولویت با قیمت تخفیف‌دار همکار است
        if ( ! empty( $partner_sale_price ) && is_numeric( $partner_sale_price ) ) {
            $final_price = $partner_sale_price;
        } elseif ( ! empty( $partner_price ) && is_numeric( $partner_price ) ) {
            $final_price = $partner_price;
        }

        // اگر قیمتی برای همکار ثبت شده بود، جایگزین قیمت اصلی سبد خرید کن
        if ( $final_price !== '' ) {
            $cart_item['data']->set_price( $final_price );
        }
    }
}

