<?php
/**
 * Single Product Template
 * 
 * Override: woocommerce/templates/single-product.php
 */

defined('ABSPATH') || exit;

get_header('shop');

do_action('woocommerce_before_main_content');
?>

<div class="ap-single-wrapper">
    
    <?php
    while (have_posts()) :
        the_post();
        wc_get_template_part('content', 'single-product');
    endwhile;
    ?>
    
</div>

<?php
do_action('woocommerce_after_main_content');

get_footer('shop');
