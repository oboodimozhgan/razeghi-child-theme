<?php
/**
 * Content Single Product
 */

defined('ABSPATH') || exit;

global $product;

if (!$product) {
    return;
}
?>

<div id="product-<?php the_ID(); ?>" <?php wc_product_class('ap-product', $product); ?>>

    <?php do_action('woocommerce_before_single_product'); ?>

    <!-- Breadcrumb -->
    <div class="ap-breadcrumb">
        <?php
        if (function_exists('yoast_breadcrumb')) {
            yoast_breadcrumb('<nav class="breadcrumb-nav">', '</nav>');
        } else {
            woocommerce_breadcrumb();
        }
        ?>
    </div>

    <!-- بخش بالا: گالری + اطلاعات -->
    <div class="ap-product-top">

        <div class="ap-product-gallery-wrapper">
            <?php get_template_part('template-parts/product/gallery'); ?>
        </div>

        <div class="ap-product-summary-wrapper">
            <?php get_template_part('template-parts/product/header'); ?>
            <?php get_template_part('template-parts/product/price'); ?>
            <?php get_template_part('template-parts/product/stock'); ?>
            <?php get_template_part('template-parts/product/attributes'); ?>
            <?php get_template_part('template-parts/product/actions'); ?>
        </div>

    </div>

    <!-- بخش پایین: محتوا -->
    <div class="ap-product-content">
        
        <?php
        /**
         * Hook: woocommerce_after_single_product_summary
         * 
         * @hooked woocommerce_output_product_data_tabs - 10
         * @hooked woocommerce_upsell_display - 15
         * @hooked woocommerce_output_related_products - 20
         */
        do_action('woocommerce_after_single_product_summary');
        ?>

        <?php get_template_part('template-parts/product/specs'); ?>
        <?php get_template_part('template-parts/product/meta-fields'); ?>
        <?php get_template_part('template-parts/product/tags'); ?>
        <?php get_template_part('template-parts/product/related'); ?>

    </div>

    <?php do_action('woocommerce_after_single_product'); ?>

</div>
