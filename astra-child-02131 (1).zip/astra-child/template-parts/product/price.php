<?php
/**
 * Product Price
 */

defined('ABSPATH') || exit;

global $product;

$product_id = get_the_ID();
$partner_price = AP_Product_Partner::get_partner_price($product_id);
$show_partner = AP_Product_Partner::can_see_partner_price();

// تشخیص نقش کاربر
$current_user = wp_get_current_user();
$is_partner = in_array('partner', $current_user->roles) || in_array('wholesale_customer', $current_user->roles);
$is_admin_editor = in_array('administrator', $current_user->roles) || in_array('editor', $current_user->roles) || in_array('shop_manager', $current_user->roles);
?>

<div class="ap-price-section">

    <?php if (!$is_partner || $is_admin_editor) : ?>
        <!-- قیمت عادی - برای غیر همکار یا ادمین/ویرایشگر -->
        <div class="ap-regular-price">
            <?php woocommerce_template_single_price(); ?>
        </div>
    <?php endif; ?>

    <?php if ($show_partner && $partner_price) : ?>
        
        <div class="ap-partner-price">
            
            <div class="ap-partner-label">قیمت همکار</div>
            
            <div class="ap-partner-amount">
                <?php 
                // قیمت همکار با تخفیف (اگر وجود دارد)
                $partner_sale_price = get_post_meta($product_id, '_partner_sale_price', true);
                
                if ($partner_sale_price && $partner_sale_price < $partner_price) : ?>
                    <del><?php echo wc_price($partner_price); ?></del>
                    <ins><?php echo wc_price($partner_sale_price); ?></ins>
                <?php else : ?>
                    <?php echo wc_price($partner_price); ?>
                <?php endif; ?>
            </div>

        </div>

    <?php endif; ?>

</div>
