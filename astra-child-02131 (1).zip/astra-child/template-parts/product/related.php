<?php
/**
 * Related & Complementary Products
 */

defined('ABSPATH') || exit;

$product_id = get_the_ID();
?>

<div class="ap-related-section">

    <!-- محصولات مرتبط -->
    <div class="ap-related-products">
        <h3>محصولات مشابه</h3>
        <?php woocommerce_output_related_products(); ?>
    </div>

    <!-- محصولات مکمل -->
    <?php
    $recommended = get_post_meta($product_id, '_recommended_products', true);
    
    if ($recommended) :
        
        $product_ids = array_map('intval', explode(',', $recommended));
        
        $args = [
            'post_type' => 'product',
            'post__in' => $product_ids,
            'posts_per_page' => 4,
            'orderby' => 'post__in'
        ];
        
        $complementary = new WP_Query($args);
        
        if ($complementary->have_posts()) :
        ?>

            <div class="ap-complementary-products">
                
                <h3>محصولات مکمل پیشنهادی</h3>

                <div class="ap-products-grid">
                    <?php
                    while ($complementary->have_posts()) {
                        $complementary->the_post();
                        wc_get_template_part('content', 'product');
                    }
                    wp_reset_postdata();
                    ?>
                </div>

            </div>

        <?php
        endif;
    endif;
    ?>

</div>
