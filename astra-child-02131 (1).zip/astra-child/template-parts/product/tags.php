<?php
/**
 * Product Tags (Auto-generated & Linkable)
 */

defined('ABSPATH') || exit;

$product_id = get_the_ID();

$car_brand = get_post_meta($product_id, '_car_brand', true);
$car_model = get_post_meta($product_id, '_car_model', true);
$part_brand = get_post_meta($product_id, '_part_brand', true);
$car_system = get_post_meta($product_id, '_car_system', true);

$tags = [];

if ($car_brand && $car_model) {
    $tags[] = [
        'text' => "قطعات {$car_brand} {$car_model}",
        'url' => home_url("/parts/{$car_brand}/{$car_model}/")
    ];
}

if ($part_brand) {
    $tags[] = [
        'text' => "قطعات {$part_brand}",
        'url' => add_query_arg('brand', sanitize_title($part_brand), wc_get_page_permalink('shop'))
    ];
}

if ($car_system) {
    $tags[] = [
        'text' => $car_system,
        'url' => add_query_arg('system', sanitize_title($car_system), wc_get_page_permalink('shop'))
    ];
}

if (empty($tags)) {
    return;
}
?>

<div class="ap-tags-section">

    <h4 class="ap-tags-title">برچسب‌های مرتبط</h4>

    <div class="ap-tags-list">
        <?php foreach ($tags as $tag) : ?>
            <a href="<?php echo esc_url($tag['url']); ?>" class="ap-tag">
                <?php echo esc_html($tag['text']); ?>
            </a>
        <?php endforeach; ?>
    </div>

</div>

