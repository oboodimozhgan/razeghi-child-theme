<?php
/**
 * Product Stock
 */

defined('ABSPATH') || exit;

global $product;

$product_id = get_the_ID();
$stock_status = $product->get_stock_status();
$stock_quantity = $product->get_stock_quantity();
?>

<div class="ap-stock-section">

    <div class="ap-stock-status status-<?php echo esc_attr($stock_status); ?>">
        <?php echo wc_get_stock_html($product); ?>
    </div>

    <?php if ($stock_quantity && $stock_quantity > 0) : ?>
        <div class="ap-stock-quantity">
            <?php echo sprintf('%d عدد موجود', $stock_quantity); ?>
        </div>
    <?php endif; ?>

    <?php if (!$product->is_in_stock()) : ?>
        <button class="ap-notify-btn" data-product-id="<?php echo esc_attr($product_id); ?>">
            موجود شد به من خبر بده
        </button>
    <?php endif; ?>

</div>
