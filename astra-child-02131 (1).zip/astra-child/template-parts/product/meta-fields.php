<?php
/**
 * Product Custom Meta Fields
 */

defined('ABSPATH') || exit;

$product_id = get_the_ID();

$meta_fields = [
    '_oem_code'                 => 'کد OEM',
    '_part_number'              => 'شماره قطعه',
    '_barcode'                  => 'بارکد',
    '_internal_code'            => 'کد داخلی',
    '_manufacturer'             => 'تولیدکننده',
    '_country_of_origin'        => 'کشور سازنده',
    '_quality_grade'            => 'درجه کیفیت',
    '_material'                 => 'جنس',
    '_warranty_period'          => 'گارانتی',
    '_engine_type'              => 'نوع موتور',
    '_engine_code'              => 'کد موتور',
    '_year_from'                => 'سال شروع',
    '_year_to'                  => 'سال پایان',
    '_installation_time'        => 'زمان نصب',
    '_difficulty_level'         => 'سختی نصب',
    '_replacement_interval'     => 'زمان تعویض',
    '_stock_source'             => 'منبع موجودی',
    '_availability_type'        => 'نوع موجودی',
    '_restock_date'             => 'تاریخ تامین مجدد',
    '_alternate_part_numbers'   => 'شماره‌های جایگزین',
    '_short_features'           => 'ویژگی‌های کوتاه',
    '_installation_guide'       => 'راهنمای نصب',
    '_maintenance_tips'         => 'نکات نگهداری',
    '_common_failures'          => 'علائم خرابی',
];

$rows = [];

foreach ($meta_fields as $meta_key => $label) {
    $value = get_post_meta($product_id, $meta_key, true);

    if ($value === '' || $value === null) {
        continue;
    }

    $rows[$label] = $value;
}

if (empty($rows)) {
    return;
}
?>

<div class="ap-meta-fields-section">
    <h3 class="ap-meta-fields-title">اطلاعات تکمیلی محصول</h3>

    <table class="ap-meta-fields-table">
        <tbody>
            <?php foreach ($rows as $label => $value) : ?>
                <tr>
                    <th><?php echo esc_html($label); ?></th>
                    <td><?php echo esc_html($value); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
