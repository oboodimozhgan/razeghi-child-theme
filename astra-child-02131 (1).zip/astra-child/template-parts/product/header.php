<?php
/**
 * Product Header
 */

defined('ABSPATH') || exit;

global $product;

$product_id = get_the_ID();
$oem_code = get_post_meta($product_id, '_oem_code', true);
$part_brand = get_post_meta($product_id, '_part_brand', true);
?>

<div class="ap-product-header">

    <h1 class="ap-product-title"><?php the_title(); ?></h1>

    <div class="ap-product-meta">
        
        <?php if ($oem_code) : ?>
            <span class="ap-meta-item">
                <strong>کد فنی:</strong>
                <a href="<?php echo esc_url(add_query_arg('oem', $oem_code, wc_get_page_permalink('shop'))); ?>">
                    <?php echo esc_html($oem_code); ?>
                </a>
            </span>
        <?php endif; ?>

        <?php if ($product->get_sku()) : ?>
            <span class="ap-meta-item">
                <strong>SKU:</strong>
                <span><?php echo esc_html($product->get_sku()); ?></span>
            </span>
        <?php endif; ?>

        <?php if ($part_brand) : ?>
            <span class="ap-meta-item">
                <strong>برند:</strong>
                <a href="<?php echo esc_url(add_query_arg('brand', sanitize_title($part_brand), wc_get_page_permalink('shop'))); ?>">
                    <?php echo esc_html($part_brand); ?>
                </a>
            </span>
        <?php endif; ?>

    </div>

    <?php if (wc_review_ratings_enabled()) : ?>
        <div class="ap-rating">
            <?php woocommerce_template_single_rating(); ?>
        </div>
    <?php endif; ?>

</div>
