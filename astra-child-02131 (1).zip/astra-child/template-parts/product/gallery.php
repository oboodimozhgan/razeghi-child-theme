<?php
/**
 * Product Gallery
 */

defined('ABSPATH') || exit;

global $product;

$product_id      = get_the_ID();
$attachment_ids  = $product->get_gallery_image_ids();
$main_image_id   = $product->get_image_id();
$columns         = apply_filters('woocommerce_product_thumbnails_columns', 4);
$post_thumbnail  = $main_image_id ? wc_get_gallery_image_html($main_image_id, true) : '<div class="woocommerce-product-gallery__image--placeholder">' . wc_placeholder_img('woocommerce_single') . '</div>';
?>

<div class="ap-gallery woocommerce-product-gallery woocommerce-product-gallery--with-images woocommerce-product-gallery--columns-<?php echo esc_attr($columns); ?>" data-columns="<?php echo esc_attr($columns); ?>" style="opacity: 0; transition: opacity .25s ease-in-out;">
    <figure class="woocommerce-product-gallery__wrapper">
        <?php
        echo $post_thumbnail; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

        if ($attachment_ids) {
            foreach ($attachment_ids as $attachment_id) {
                echo wc_get_gallery_image_html($attachment_id); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            }
        }
        ?>
    </figure>

    <!-- بج‌ها -->
    <div class="ap-badges">
        <?php if ($product->is_on_sale()) : ?>
            <span class="badge badge-sale">تخفیف</span>
        <?php endif; ?>
        
        <?php if ($product->is_featured()) : ?>
            <span class="badge badge-featured">ویژه</span>
        <?php endif; ?>
        
        <?php
        $quality = get_post_meta($product_id, '_quality_grade', true);
        if ($quality === 'original') :
        ?>
            <span class="badge badge-original">اصلی</span>
        <?php endif; ?>
    </div>
</div>
