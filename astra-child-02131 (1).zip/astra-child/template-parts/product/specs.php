<?php
/**
 * Technical Specifications Table
 */

defined('ABSPATH') || exit;

$product_id = get_the_ID();

$specs = [
    '_oem_code' => 'کد OEM',
    '_part_number' => 'شماره قطعه',
    '_part_brand' => 'برند قطعه',
    '_manufacturer' => 'تولیدکننده',
    '_country_of_origin' => 'کشور سازنده',
    '_quality_grade' => 'درجه کیفیت',
    '_material' => 'جنس',
    '_weight' => 'وزن',
    '_dimensions' => 'ابعاد',
    '_warranty_period' => 'گارانتی',
    '_car_brand' => 'برند خودرو',
    '_car_model' => 'مدل خودرو',
    '_year_from' => 'سال شروع',
    '_year_to' => 'سال پایان',
    '_engine_type' => 'نوع موتور',
    '_install_position' => 'محل نصب',
];

$has_specs = false;
foreach ($specs as $key => $label) {
    if (get_post_meta($product_id, $key, true)) {
        $has_specs = true;
        break;
    }
}

if (!$has_specs) {
    return;
}
?>

<div class="ap-specs-section">

    <h3 class="ap-specs-title">مشخصات فنی</h3>

    <table class="ap-specs-table">
        <tbody>
            <?php foreach ($specs as $meta_key => $label) :
                
                $value = get_post_meta($product_id, $meta_key, true);
                
                if (!$value) {
                    continue;
                }
                ?>

                <tr>
                    <th><?php echo esc_html($label); ?></th>
                    <td><?php echo esc_html($value); ?></td>
                </tr>

            <?php endforeach; ?>
        </tbody>
    </table>

</div>
