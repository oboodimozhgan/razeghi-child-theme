<?php
/**
 * Product Attributes (Linkable)
 */

defined('ABSPATH') || exit;

$product_id = get_the_ID();

$attributes = [
    '_car_brand' => 'برند خودرو',
    '_car_model' => 'مدل خودرو',
    '_car_system' => 'سیستم',
    '_install_position' => 'موقعیت نصب',
    '_part_brand' => 'برند قطعه',
    '_quality_grade' => 'کیفیت',
    '_country_of_origin' => 'کشور سازنده',
];

$has_attributes = false;
foreach ($attributes as $key => $label) {
    if (get_post_meta($product_id, $key, true)) {
        $has_attributes = true;
        break;
    }
}

if (!$has_attributes) {
    return;
}
?>

<div class="ap-attributes">

    <h4 class="ap-attributes-title">مشخصات کلیدی</h4>

    <div class="ap-attributes-list">
        
        <?php foreach ($attributes as $meta_key => $label) :
            
            $value = get_post_meta($product_id, $meta_key, true);
            
            if (!$value) {
                continue;
            }

            // ساخت URL
            $url = AP_Product_Meta::get_attribute_url($meta_key, $value);
            ?>

            <div class="ap-attr-item">
                <span class="ap-attr-label"><?php echo esc_html($label); ?>:</span>
                <span class="ap-attr-value">
                    <?php if ($url) : ?>
                        <a href="<?php echo esc_url($url); ?>">
                            <?php echo esc_html($value); ?>
                        </a>
                    <?php else : ?>
                        <?php echo esc_html($value); ?>
                    <?php endif; ?>
                </span>
            </div>

        <?php endforeach; ?>

    </div>

</div>
