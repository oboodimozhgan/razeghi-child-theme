<?php
/**
 * Product Actions
 */

defined('ABSPATH') || exit;

global $product;
?>

<div class="ap-actions">

    <!-- افزودن به سبد -->
    <div class="ap-add-to-cart">
        <?php woocommerce_template_single_add_to_cart(); ?>
    </div>

    <!-- اکشن‌های ثانویه -->
    <div class="ap-secondary-actions">
        
        <!-- علاقه‌مندی -->
        <?php if (function_exists('YITH_WCWL')) : ?>
            <div class="ap-wishlist">
                <?php echo do_shortcode('[yith_wcwl_add_to_wishlist]'); ?>
            </div>
        <?php endif; ?>

        <!-- اشتراک‌گذاری -->
        <button class="ap-share-btn" data-url="<?php echo esc_url(get_permalink()); ?>" data-title="<?php echo esc_attr(get_the_title()); ?>">
            <svg width="20" height="20"><use xlink:href="#icon-share"></use></svg>
            اشتراک‌گذاری
        </button>

    </div>

    <!-- اطلاعات اضافی -->
    <div class="ap-extra-info">
        
        <?php
        $warranty = get_post_meta(get_the_ID(), '_warranty_period', true);
        if ($warranty) :
        ?>
            <div class="ap-info-item">
                <svg width="18" height="18"><use xlink:href="#icon-warranty"></use></svg>
                <span>گارانتی <?php echo esc_html($warranty); ?></span>
            </div>
        <?php endif; ?>

        <div class="ap-info-item">
            <svg width="18" height="18"><use xlink:href="#icon-delivery"></use></svg>
            <span>ارسال سریع</span>
        </div>

        <div class="ap-info-item">
            <svg width="18" height="18"><use xlink:href="#icon-support"></use></svg>
            <span>پشتیبانی ۲۴ ساعته</span>
        </div>

    </div>

</div>
